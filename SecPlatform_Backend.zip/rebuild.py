#!/usr/bin/env python3
"""
rebuild.py - 合并所有 JS 文件到 index.html
每次修改 JS 文件后运行此脚本（或由 start.bat 自动运行）
源文件保持独立，不受影响
"""
import re
from pathlib import Path

BASE = Path(__file__).parent
STATIC = BASE / "static"
INDEX_SRC  = STATIC / "index.html"   # 模板文件（含 src= 标签）
INDEX_OUT  = STATIC / "index.html"   # 覆盖同一文件

src = INDEX_SRC.read_text(encoding="utf-8")

# 收集所有外部 babel 文件的路径（保持顺序）
srcs = re.findall(r'<script type="text/babel" src="([^"]+)"></script>', src)
if not srcs:
    print("没有找到外部 babel 标签，index.html 已是合并版，无需处理。")
    exit(0)

print(f"找到 {len(srcs)} 个 JS 文件，开始合并...")

# 读取所有文件内容
parts = []
for url_path in srcs:
    # 把 /static/js/foo.js → static/js/foo.js → 找本地文件
    rel = url_path.lstrip("/")         # static/js/api.js
    rel = re.sub(r'^static/', '', rel) # js/api.js
    local = STATIC / rel
    if not local.exists():
        print(f"  ✗ 找不到文件: {local}")
        continue
    print(f"  ✓ {local.name}")
    parts.append(f"// ════ {local.name} ════\n" + local.read_text(encoding="utf-8"))

merged_js = "\n\n".join(parts)

# 移除所有外部 babel src 标签
out = re.sub(r'<script type="text/babel" src="[^"]+"></script>\n?', '', src)

# 注入一个合并后的内联 babel 标签，放在 </body> 前
inline_tag = f'<script type="text/babel">\n{merged_js}\n</script>\n'
out = out.replace('</body>', inline_tag + '</body>')

INDEX_OUT.write_text(out, encoding="utf-8")
print(f"\n✅ 合并完成 → {INDEX_OUT}")
print(f"   共 {len(parts)} 个文件，{out.count(chr(10))} 行")
