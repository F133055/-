"""数据库模型定义 - SecPlatform v4.0"""
import sys
import logging
from pathlib import Path
from datetime import datetime

PROJECT_ROOT = Path(__file__).parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from sqlalchemy import (
    create_engine, Column, Integer, String, DateTime,
    Text, Float, Boolean, JSON, func, text, ForeignKey
)
from sqlalchemy.orm import declarative_base, sessionmaker, relationship
from core.config import settings

logger = logging.getLogger(__name__)

engine = None
Base = declarative_base()
SessionLocal = None


# ==================== 数据模型 ====================

class Asset(Base):
    """资产信息表"""
    __tablename__ = "assets"

    id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    ip_address = Column(String(255), unique=True, index=True, nullable=False)
    hostname = Column(String(255), nullable=True)
    open_ports = Column(String(2048), default="", nullable=True)
    services = Column(Text, nullable=True)          # JSON: {port: service_name}
    os_info = Column(String(512), nullable=True)
    status = Column(String(20), default="ONLINE", nullable=False)
    source = Column(String(50), default="scan", nullable=True)  # scan/fofa/manual
    tags = Column(String(512), nullable=True)
    vuln_info = Column(String(2048), default="未检测", nullable=True)
    risk_level = Column(String(20), default="未知", nullable=True)  # 高/中/低/无
    first_seen = Column(DateTime, server_default=func.now())
    last_seen = Column(DateTime, server_default=func.now(), onupdate=func.now())
    created_at = Column(DateTime, server_default=func.now())
    updated_at = Column(DateTime, server_default=func.now(), onupdate=func.now())

    vulnerabilities = relationship("Vulnerability", back_populates="asset", cascade="all, delete-orphan")

    def __repr__(self):
        return f"<Asset(ip={self.ip_address}, status={self.status})>"


class Vulnerability(Base):
    """漏洞信息表"""
    __tablename__ = "vulnerabilities"

    id = Column(Integer, primary_key=True, autoincrement=True)
    asset_id = Column(Integer, ForeignKey("assets.id"), nullable=True)
    ip_address = Column(String(255), index=True, nullable=False)
    vuln_type = Column(String(100), nullable=False)   # nacos/swagger/minio/weakpass
    severity = Column(String(20), default="中", nullable=False)  # 高/中/低/信息
    title = Column(String(512), nullable=False)
    description = Column(Text, nullable=True)
    evidence = Column(Text, nullable=True)
    cvss_score = Column(Float, nullable=True)
    status = Column(String(20), default="未处理")  # 未处理/处理中/已修复/误报
    discovered_at = Column(DateTime, server_default=func.now())
    updated_at = Column(DateTime, server_default=func.now(), onupdate=func.now())

    asset = relationship("Asset", back_populates="vulnerabilities")


class ScanTask(Base):
    """扫描任务记录表"""
    __tablename__ = "scan_tasks"

    id = Column(Integer, primary_key=True, autoincrement=True)
    task_id = Column(String(255), unique=True, index=True, nullable=False)
    task_type = Column(String(50), nullable=False)  # asset/vuln/weakpass/fofa
    targets = Column(Text, nullable=True)           # JSON list
    params = Column(Text, nullable=True)            # JSON params
    status = Column(String(20), default="PENDING")  # PENDING/RUNNING/SUCCESS/FAILED
    result_summary = Column(Text, nullable=True)    # JSON summary
    operator = Column(String(100), nullable=True)
    created_at = Column(DateTime, server_default=func.now())
    started_at = Column(DateTime, nullable=True)
    finished_at = Column(DateTime, nullable=True)


class Report(Base):
    """安全报告表"""
    __tablename__ = "reports"

    id = Column(Integer, primary_key=True, autoincrement=True)
    title = Column(String(512), nullable=False)
    report_type = Column(String(50), nullable=False)  # daily/weekly/custom
    content = Column(Text, nullable=True)             # HTML content
    summary = Column(Text, nullable=True)             # JSON summary data
    created_by = Column(String(100), nullable=True)
    created_at = Column(DateTime, server_default=func.now())


class NotifyConfig(Base):
    """通知配置表"""
    __tablename__ = "notify_configs"

    id = Column(Integer, primary_key=True, autoincrement=True)
    channel = Column(String(50), nullable=False)  # wechat/feishu/dingtalk/bark
    name = Column(String(100), nullable=False)
    webhook_url = Column(String(1024), nullable=True)
    api_key = Column(String(512), nullable=True)
    enabled = Column(Boolean, default=True)
    created_at = Column(DateTime, server_default=func.now())


class FOFAResult(Base):
    """FOFA探测结果表"""
    __tablename__ = "fofa_results"

    id = Column(Integer, primary_key=True, autoincrement=True)
    query = Column(String(512), nullable=False)
    ip = Column(String(255), nullable=True)
    port = Column(String(20), nullable=True)
    protocol = Column(String(50), nullable=True)
    title = Column(String(512), nullable=True)
    country = Column(String(100), nullable=True)
    city = Column(String(100), nullable=True)
    org = Column(String(255), nullable=True)
    domain = Column(String(255), nullable=True)
    raw_data = Column(Text, nullable=True)  # JSON
    created_at = Column(DateTime, server_default=func.now())



class AssetSnapshot(Base):
    """资产快照表 —— 每次扫描完成后自动保存当前资产状态"""
    __tablename__ = "asset_snapshots"

    id          = Column(Integer, primary_key=True, autoincrement=True)
    snapshot_at = Column(DateTime, server_default=func.now(), index=True)
    ip_address  = Column(String(255), nullable=False, index=True)
    open_ports  = Column(String(2048), default="")
    services    = Column(Text, nullable=True)   # JSON
    status      = Column(String(20), default="ONLINE")
    source      = Column(String(50), default="scan")

    def __repr__(self):
        return f"<AssetSnapshot(ip={self.ip_address}, at={self.snapshot_at})>"


class AssetHistory(Base):
    """资产变化历史表 —— 记录每次资产状态与上次快照的差异"""
    __tablename__ = "asset_history"

    id           = Column(Integer, primary_key=True, autoincrement=True)
    ip_address   = Column(String(255), nullable=False, index=True)
    change_type  = Column(String(20), nullable=False)   # new_asset / offline / port_added / port_removed / service_changed
    old_value    = Column(Text, nullable=True)
    new_value    = Column(Text, nullable=True)
    detected_at  = Column(DateTime, server_default=func.now(), index=True)


class ThreatIntelResult(Base):
    """威胁情报关联结果表"""
    __tablename__ = "threat_intel_results"

    id           = Column(Integer, primary_key=True, autoincrement=True)
    ip_address   = Column(String(255), nullable=True, index=True)
    cve_id       = Column(String(50),  nullable=True, index=True)
    cvss_score   = Column(Float, nullable=True)
    severity     = Column(String(20), default="未知")
    title        = Column(String(512), nullable=True)
    description  = Column(Text, nullable=True)
    published_at = Column(String(30), nullable=True)
    source       = Column(String(50), default="nvd")   # nvd / manual
    status       = Column(String(20), default="未处理") # 未处理 / 已确认 / 误报
    created_at   = Column(DateTime, server_default=func.now())


class GithubLeakResult(Base):
    """GitHub/Gitee 信息泄露扫描结果表"""
    __tablename__ = "github_leak_results"

    id           = Column(Integer, primary_key=True, autoincrement=True)
    keyword      = Column(String(256), nullable=False, index=True)
    platform     = Column(String(20), default="github")  # github / gitee
    repo_name    = Column(String(512), nullable=True)
    repo_url     = Column(String(1024), nullable=True)
    file_path    = Column(String(512), nullable=True)
    leak_type    = Column(String(50),  nullable=True)    # api_key / password / token / secret
    matched_text = Column(Text, nullable=True)
    severity     = Column(String(20), default="高")
    status       = Column(String(20), default="未处理")
    discovered_at = Column(DateTime, server_default=func.now())


class AnomalyEvent(Base):
    """异常检测事件表"""
    __tablename__ = "anomaly_events"

    id           = Column(Integer, primary_key=True, autoincrement=True)
    ip_address   = Column(String(255), nullable=False, index=True)
    anomaly_type = Column(String(50),  nullable=False)   # new_high_risk_port / asset_offline / service_change / new_asset
    severity     = Column(String(20), default="中")      # 高/中/低
    description  = Column(Text, nullable=True)
    old_value    = Column(Text, nullable=True)
    new_value    = Column(Text, nullable=True)
    status       = Column(String(20), default="未处理")  # 未处理 / 已确认 / 忽略
    detected_at  = Column(DateTime, server_default=func.now(), index=True)


class ScheduledTask(Base):
    """定时任务表（v4.1 新增）"""
    __tablename__ = "scheduled_tasks"

    id             = Column(Integer, primary_key=True, autoincrement=True)
    name           = Column(String(128), nullable=False)
    task_type      = Column(String(32), nullable=False)   # asset / vuln / weakpass / quickscan
    targets        = Column(Text, nullable=True)           # JSON 列表
    params         = Column(Text, nullable=True)           # JSON 参数
    enabled        = Column(Boolean, default=True)

    # 调度策略
    schedule_type  = Column(String(16), default="interval")  # interval / daily / weekly
    interval_hours = Column(Integer, default=24)
    run_at_time    = Column(String(8),  nullable=True)       # "HH:MM"
    run_on_days    = Column(Text, nullable=True)             # JSON [0,1,...] 0=周一

    # 运行状态
    next_run       = Column(DateTime, nullable=True)
    last_run       = Column(DateTime, nullable=True)
    last_status    = Column(String(16), default="pending")   # pending / ok / error
    run_count      = Column(Integer, default=0)

    created_at     = Column(DateTime, server_default=func.now())
    updated_at     = Column(DateTime, server_default=func.now(), onupdate=func.now())

# ==================== 初始化函数 ====================

def init_db():
    global engine, SessionLocal
    if not settings.DB_URL:
        raise ValueError("❌ 数据库连接字符串(DB_URL)未配置！")
    try:
        engine = create_engine(
            settings.DB_URL,
            pool_pre_ping=True,
            pool_recycle=3600,
            echo=False
        )
        Base.metadata.create_all(bind=engine)
        logger.info("✅ 数据库初始化成功，所有表已创建")
        SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
        logger.info("✅ 数据库会话工厂创建成功")
    except Exception as e:
        logger.error(f"❌ 数据库初始化失败: {e}")
        raise


def get_db():
    if SessionLocal is None:
        raise RuntimeError("❌ 数据库会话工厂未初始化！")
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def check_db_connection():
    if engine is None:
        return False, "引擎未初始化"
    try:
        with engine.connect() as conn:
            conn.execute(text("SELECT 1"))
        return True, "连接正常"
    except Exception as e:
        return False, str(e)


class KnowledgeDoc(Base):
    """安全知识库文档表"""
    __tablename__ = "knowledge_docs"

    id         = Column(Integer, primary_key=True, autoincrement=True)
    title      = Column(String(512), nullable=False)
    category   = Column(String(64), default="安全文档")
    content    = Column(Text, nullable=False)
    tags       = Column(String(512), nullable=True)
    created_by = Column(String(100), nullable=True)
    created_at = Column(DateTime, server_default=func.now())
    updated_at = Column(DateTime, server_default=func.now(), onupdate=func.now())


class SecurityDevice(Base):
    """安全设备监控表"""
    __tablename__ = "security_devices"

    id          = Column(Integer, primary_key=True, autoincrement=True)
    name        = Column(String(128), nullable=False)
    device_type = Column(String(64), default="防火墙")
    ip_address  = Column(String(255), nullable=False)
    port        = Column(Integer, default=22)
    protocol    = Column(String(20), default="SSH")
    username    = Column(String(128), nullable=True)
    password    = Column(String(256), nullable=True)
    description = Column(Text, nullable=True)
    status       = Column(String(20), default="unknown")
    cpu_usage    = Column(Float, nullable=True)
    mem_usage    = Column(Float, nullable=True)
    disk_usage   = Column(Float, nullable=True)
    last_checked = Column(DateTime, nullable=True)
    last_error   = Column(Text, nullable=True)
    created_at  = Column(DateTime, server_default=func.now())
    updated_at  = Column(DateTime, server_default=func.now(), onupdate=func.now())


class FirewallPolicy(Base):
    """防火墙策略表"""
    __tablename__ = "firewall_policies"

    id          = Column(Integer, primary_key=True, autoincrement=True)
    name        = Column(String(256), nullable=False)
    device_name = Column(String(128), nullable=True)
    src_ip      = Column(String(256), nullable=True)
    dst_ip      = Column(String(256), nullable=True)
    dst_port    = Column(String(256), nullable=True)
    protocol    = Column(String(20), default="TCP")
    action      = Column(String(10), default="ALLOW")
    description = Column(Text, nullable=True)
    created_by  = Column(String(100), nullable=True)
    created_at  = Column(DateTime, server_default=func.now())


class PolicyAuditResult(Base):
    """防火墙策略审核结果表"""
    __tablename__ = "policy_audit_results"

    id          = Column(Integer, primary_key=True, autoincrement=True)
    policy_id   = Column(Integer, nullable=False)
    policy_name = Column(String(256), nullable=False)
    risk_id     = Column(String(16), nullable=False)
    risk_name   = Column(String(128), nullable=False)
    severity    = Column(String(10), nullable=False)
    description = Column(Text, nullable=True)
    suggestion  = Column(Text, nullable=True)
    created_at  = Column(DateTime, server_default=func.now())


class AppSetting(Base):
    """应用配置表 — 存储可在线修改的系统配置（如 LLM API Key）"""
    __tablename__ = "app_settings"

    id         = Column(Integer, primary_key=True, autoincrement=True)
    key        = Column(String(128), nullable=False, unique=True)
    value      = Column(Text, nullable=True)
    desc       = Column(String(256), nullable=True)
    updated_at = Column(DateTime, server_default=func.now(), onupdate=func.now())
