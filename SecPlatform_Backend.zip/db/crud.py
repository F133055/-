"""数据库 CRUD 操作 - SecPlatform v4.0"""
import json
import logging
from datetime import datetime, timedelta
from typing import List, Optional, Dict

from sqlalchemy.orm import Session
from sqlalchemy import func, desc

from db.models import (Asset, Vulnerability, ScanTask, Report, NotifyConfig, FOFAResult,
                       AssetSnapshot, AssetHistory, ThreatIntelResult, GithubLeakResult, AnomalyEvent)

logger = logging.getLogger(__name__)


# ==================== 资产 ====================

def save_scan_results(db: Session, scan_results_dict: dict):
    """批量 Upsert 资产扫描结果"""
    saved, updated = 0, 0
    for ip, ports_list in scan_results_dict.items():
        try:
            ports_str = ",".join(map(str, ports_list))
            existing = db.query(Asset).filter(Asset.ip_address == ip).first()
            if existing:
                existing.open_ports = ports_str
                existing.status = "ONLINE"
                existing.last_seen = datetime.utcnow()
                updated += 1
            else:
                db.add(Asset(ip_address=ip, open_ports=ports_str, status="ONLINE"))
                saved += 1
            db.commit()
        except Exception as e:
            db.rollback()
            logger.error(f"写入资产 {ip} 失败: {e}")
    logger.info(f"资产入库完成：新增 {saved}，更新 {updated}")


def get_all_assets(db: Session, skip: int = 0, limit: int = 100, status_filter: str = None):
    q = db.query(Asset)
    if status_filter:
        q = q.filter(Asset.status == status_filter)
    return q.offset(skip).limit(limit).all()


def get_asset_stats(db: Session) -> dict:
    total = db.query(func.count(Asset.id)).scalar() or 0
    online = db.query(func.count(Asset.id)).filter(Asset.status == "ONLINE").scalar() or 0
    offline = db.query(func.count(Asset.id)).filter(Asset.status == "OFFLINE").scalar() or 0
    high_risk = db.query(func.count(Asset.id)).filter(Asset.risk_level == "高").scalar() or 0
    vuln_count = db.query(func.count(Vulnerability.id)).scalar() or 0
    high_vuln = db.query(func.count(Vulnerability.id)).filter(Vulnerability.severity == "高").scalar() or 0
    return {
        "total_assets": total,
        "online_assets": online,
        "offline_assets": offline,
        "high_risk_assets": high_risk,
        "total_vulnerabilities": vuln_count,
        "high_vulnerabilities": high_vuln,
    }


def delete_asset(db: Session, asset_id: int) -> bool:
    asset = db.query(Asset).filter(Asset.id == asset_id).first()
    if asset:
        db.delete(asset)
        db.commit()
        return True
    return False


def batch_delete_assets(db: Session, asset_ids: list) -> int:
    count = db.query(Asset).filter(Asset.id.in_(asset_ids)).delete(synchronize_session=False)
    db.commit()
    return count


def update_asset_vuln(db: Session, ip: str, info: str):
    """更新资产漏洞信息和风险等级
    
    风险判定规则：
    - ⚠️ 开头 = 发现漏洞 → 高危
    - ✅ 开头（含"未发现"/"端口不可达"）= 安全 → 不降低已有风险
    - 无标记但含"存在"字样 = 高危（兜底兼容旧格式）
    注意：绝不能因"未发现"中含"发现"两字就判高危！
    """
    asset = db.query(Asset).filter(Asset.ip_address == ip).first()
    if asset:
        asset.vuln_info = info
        if "⚠️" in info:
            asset.risk_level = "高"
        elif info.startswith("✅"):
            # 明确安全结果（未发现/端口不可达），不改变已有风险等级，由其他扫描决定
            pass
        elif "存在" in info:  # 兜底：兼容旧版漏洞扫描结果格式
            asset.risk_level = "高"
        # 其他情况不修改 risk_level
        db.commit()


# ==================== 漏洞 ====================

def save_vulnerability(db: Session, ip: str, vuln_type: str, title: str,
                       severity: str = "中", description: str = "", evidence: str = "") -> Vulnerability:
    """保存漏洞，同IP+同类型已存在则更新，不重复写入"""
    asset = db.query(Asset).filter(Asset.ip_address == ip).first()
    # 去重检查：同IP + 同vuln_type + 同title 只保留一条（不同 service 的弱密码独立存储）
    existing = db.query(Vulnerability).filter(
        Vulnerability.ip_address == ip,
        Vulnerability.vuln_type == vuln_type,
        Vulnerability.title == title
    ).first()
    if existing:
        existing.title = title
        existing.severity = severity
        existing.description = description
        existing.evidence = evidence
        existing.status = "未处理"
        db.commit()
        db.refresh(existing)
        logger.debug(f"漏洞已存在，更新: {ip} - {vuln_type}")
        return existing
    vuln = Vulnerability(
        asset_id=asset.id if asset else None,
        ip_address=ip,
        vuln_type=vuln_type,
        title=title,
        severity=severity,
        description=description,
        evidence=evidence,
    )
    db.add(vuln)
    db.commit()
    db.refresh(vuln)
    return vuln


def get_vulnerabilities(db: Session, severity: str = None, status: str = None,
                        skip: int = 0, limit: int = 100) -> List[Vulnerability]:
    q = db.query(Vulnerability)
    if severity:
        q = q.filter(Vulnerability.severity == severity)
    if status:
        q = q.filter(Vulnerability.status == status)
    return q.order_by(desc(Vulnerability.discovered_at)).offset(skip).limit(limit).all()


def update_vuln_status(db: Session, vuln_id: int, status: str) -> bool:
    vuln = db.query(Vulnerability).filter(Vulnerability.id == vuln_id).first()
    if vuln:
        vuln.status = status
        db.commit()
        return True
    return False


# ==================== 扫描任务 ====================

def create_scan_task(db: Session, task_id: str, task_type: str,
                     targets: list, params: dict = None, operator: str = None) -> ScanTask:
    task = ScanTask(
        task_id=task_id,
        task_type=task_type,
        targets=json.dumps(targets, ensure_ascii=False),
        params=json.dumps(params or {}, ensure_ascii=False),
        operator=operator,
        status="PENDING",
    )
    db.add(task)
    db.commit()
    db.refresh(task)
    return task


def update_scan_task(db: Session, task_id: str, status: str, result_summary: dict = None):
    task = db.query(ScanTask).filter(ScanTask.task_id == task_id).first()
    if task:
        task.status = status
        if status == "RUNNING" and not task.started_at:
            task.started_at = datetime.utcnow()
        if status in ("SUCCESS", "FAILED"):
            task.finished_at = datetime.utcnow()
        if result_summary:
            task.result_summary = json.dumps(result_summary, ensure_ascii=False)
        db.commit()


def get_scan_tasks(db: Session, task_type: str = None, limit: int = 50) -> List[ScanTask]:
    q = db.query(ScanTask)
    if task_type:
        q = q.filter(ScanTask.task_type == task_type)
    return q.order_by(desc(ScanTask.created_at)).limit(limit).all()


# ==================== 报告 ====================

def create_report(db: Session, title: str, report_type: str,
                  content: str, summary: dict, created_by: str = None) -> Report:
    report = Report(
        title=title,
        report_type=report_type,
        content=content,
        summary=json.dumps(summary, ensure_ascii=False),
        created_by=created_by,
    )
    db.add(report)
    db.commit()
    db.refresh(report)
    return report


def get_reports(db: Session, limit: int = 20) -> List[Report]:
    return db.query(Report).order_by(desc(Report.created_at)).limit(limit).all()


# ==================== 通知配置 ====================

def get_notify_configs(db: Session) -> List[NotifyConfig]:
    return db.query(NotifyConfig).all()


def save_notify_config(db: Session, channel: str, name: str,
                       webhook_url: str = None, api_key: str = None) -> NotifyConfig:
    existing = db.query(NotifyConfig).filter(NotifyConfig.channel == channel).first()
    if existing:
        existing.webhook_url = webhook_url
        existing.api_key = api_key
        existing.name = name
        db.commit()
        return existing
    config = NotifyConfig(channel=channel, name=name, webhook_url=webhook_url, api_key=api_key)
    db.add(config)
    db.commit()
    db.refresh(config)
    return config


# ==================== FOFA ====================

def save_fofa_results(db: Session, query: str, results: list) -> int:
    saved = 0
    for r in results:
        try:
            item = FOFAResult(
                query=query,
                ip=r.get("ip"),
                port=str(r.get("port", "")),
                protocol=r.get("protocol"),
                title=r.get("title"),
                country=r.get("country"),
                city=r.get("city"),
                org=r.get("org"),
                domain=r.get("domain"),
                raw_data=json.dumps(r, ensure_ascii=False),
            )
            db.add(item)
            db.commit()
            saved += 1
        except Exception as e:
            db.rollback()
            logger.error(f"FOFA结果写入失败: {e}")
    return saved


def get_fofa_results(db: Session, query: str = None, limit: int = 100) -> List[FOFAResult]:
    q = db.query(FOFAResult)
    if query:
        q = q.filter(FOFAResult.query == query)
    return q.order_by(desc(FOFAResult.created_at)).limit(limit).all()


# ==================== 资产快照 ====================

def save_asset_snapshot(db: Session) -> int:
    """将当前所有 ONLINE 资产保存为一份快照，返回快照条数"""
    assets = db.query(Asset).filter(Asset.status == "ONLINE").all()
    now = datetime.utcnow()
    count = 0
    for a in assets:
        try:
            snap = AssetSnapshot(
                snapshot_at=now,
                ip_address=a.ip_address,
                open_ports=a.open_ports or "",
                services=a.services,
                status=a.status,
                source=a.source or "scan",
            )
            db.add(snap)
            count += 1
        except Exception as e:
            logger.error(f"保存快照失败 {a.ip_address}: {e}")
    try:
        db.commit()
    except Exception as e:
        db.rollback()
        logger.error(f"快照提交失败: {e}")
    logger.info(f"资产快照已保存：{count} 条")
    return count


def get_snapshot_times(db: Session, limit: int = 30) -> list:
    """获取历史快照时间点列表"""
    from sqlalchemy import distinct
    rows = (db.query(AssetSnapshot.snapshot_at)
              .distinct()
              .order_by(desc(AssetSnapshot.snapshot_at))
              .limit(limit)
              .all())
    return [r[0].strftime("%Y-%m-%d %H:%M:%S") for r in rows]


def compare_snapshots(db: Session, time_a: str, time_b: str) -> dict:
    """
    比较两个时间点的资产快照，返回差异分析。
    time_a = 较早时间，time_b = 较新时间（字符串 YYYY-MM-DD HH:MM:SS）
    """
    def _parse(t: str):
        try:
            return datetime.strptime(t, "%Y-%m-%d %H:%M:%S")
        except Exception:
            return None

    dt_a, dt_b = _parse(time_a), _parse(time_b)
    if not dt_a or not dt_b:
        return {"error": "时间格式错误，请使用 YYYY-MM-DD HH:MM:SS"}

    # 查找最接近的快照时间（精确到分钟）
    def _nearest_snap(target_dt):
        snaps = (db.query(AssetSnapshot)
                   .filter(AssetSnapshot.snapshot_at.between(
                       target_dt - timedelta(minutes=30),
                       target_dt + timedelta(minutes=30)))
                   .all())
        return {s.ip_address: s for s in snaps}

    snap_a = _nearest_snap(dt_a)
    snap_b = _nearest_snap(dt_b)

    ips_a = set(snap_a.keys())
    ips_b = set(snap_b.keys())

    new_assets = []
    disappeared = []
    port_changed = []

    for ip in ips_b - ips_a:
        new_assets.append({"ip": ip, "ports": snap_b[ip].open_ports})

    for ip in ips_a - ips_b:
        disappeared.append({"ip": ip, "ports": snap_a[ip].open_ports})

    for ip in ips_a & ips_b:
        old_ports = set(filter(None, snap_a[ip].open_ports.split(","))) if snap_a[ip].open_ports else set()
        new_ports = set(filter(None, snap_b[ip].open_ports.split(","))) if snap_b[ip].open_ports else set()
        added = new_ports - old_ports
        removed = old_ports - new_ports
        if added or removed:
            port_changed.append({
                "ip": ip,
                "added_ports": list(added),
                "removed_ports": list(removed),
            })

    return {
        "time_a": time_a,
        "time_b": time_b,
        "snapshot_a_count": len(snap_a),
        "snapshot_b_count": len(snap_b),
        "new_assets": new_assets,
        "disappeared_assets": disappeared,
        "port_changed": port_changed,
        "summary": {
            "new": len(new_assets),
            "disappeared": len(disappeared),
            "changed": len(port_changed),
        }
    }


# ==================== 威胁情报 ====================

def save_threat_intel(db: Session, ip: str, cve_id: str, title: str,
                      cvss_score: float = None, severity: str = "未知",
                      description: str = "", published_at: str = None,
                      source: str = "nvd") -> ThreatIntelResult:
    existing = (db.query(ThreatIntelResult)
                  .filter(ThreatIntelResult.ip_address == ip,
                          ThreatIntelResult.cve_id == cve_id)
                  .first())
    if existing:
        existing.cvss_score = cvss_score
        existing.severity = severity
        existing.description = description
        db.commit()
        return existing
    item = ThreatIntelResult(
        ip_address=ip, cve_id=cve_id, cvss_score=cvss_score,
        severity=severity, title=title, description=description,
        published_at=published_at, source=source,
    )
    db.add(item)
    db.commit()
    db.refresh(item)
    return item


def get_threat_intel_list(db: Session, ip: str = None, severity: str = None,
                           status: str = None, limit: int = 100) -> list:
    q = db.query(ThreatIntelResult)
    if ip:
        q = q.filter(ThreatIntelResult.ip_address == ip)
    if severity:
        q = q.filter(ThreatIntelResult.severity == severity)
    if status:
        q = q.filter(ThreatIntelResult.status == status)
    return q.order_by(desc(ThreatIntelResult.created_at)).limit(limit).all()


# ==================== GitHub 信息泄露 ====================

def save_github_leak(db: Session, keyword: str, platform: str, repo_name: str,
                     repo_url: str, file_path: str, leak_type: str,
                     matched_text: str, severity: str = "高") -> GithubLeakResult:
    existing = (db.query(GithubLeakResult)
                  .filter(GithubLeakResult.keyword == keyword,
                          GithubLeakResult.repo_url == repo_url,
                          GithubLeakResult.file_path == file_path)
                  .first())
    if existing:
        return existing
    item = GithubLeakResult(
        keyword=keyword, platform=platform, repo_name=repo_name,
        repo_url=repo_url, file_path=file_path, leak_type=leak_type,
        matched_text=matched_text[:500] if matched_text else "",
        severity=severity,
    )
    db.add(item)
    db.commit()
    db.refresh(item)
    return item


def get_github_leaks(db: Session, keyword: str = None, platform: str = None,
                     status: str = None, limit: int = 100) -> list:
    q = db.query(GithubLeakResult)
    if keyword:
        q = q.filter(GithubLeakResult.keyword.contains(keyword))
    if platform:
        q = q.filter(GithubLeakResult.platform == platform)
    if status:
        q = q.filter(GithubLeakResult.status == status)
    return q.order_by(desc(GithubLeakResult.discovered_at)).limit(limit).all()


# ==================== 异常检测 ====================

def save_anomaly_event(db: Session, ip: str, anomaly_type: str, severity: str,
                       description: str, old_value: str = None,
                       new_value: str = None) -> AnomalyEvent:
    event = AnomalyEvent(
        ip_address=ip, anomaly_type=anomaly_type, severity=severity,
        description=description, old_value=old_value, new_value=new_value,
    )
    db.add(event)
    db.commit()
    db.refresh(event)
    return event


def get_anomaly_events(db: Session, ip: str = None, status: str = None,
                        severity: str = None, limit: int = 100) -> list:
    q = db.query(AnomalyEvent)
    if ip:
        q = q.filter(AnomalyEvent.ip_address == ip)
    if status:
        q = q.filter(AnomalyEvent.status == status)
    if severity:
        q = q.filter(AnomalyEvent.severity == severity)
    return q.order_by(desc(AnomalyEvent.detected_at)).limit(limit).all()


def update_anomaly_status(db: Session, event_id: int, status: str) -> bool:
    event = db.query(AnomalyEvent).filter(AnomalyEvent.id == event_id).first()
    if event:
        event.status = status
        db.commit()
        return True
    return False
