"""
资产异常检测模块 - SecPlatform v4.1
=====================================
功能：
  1. 对比最近两次资产快照，检测变化
  2. 识别高危端口新增、资产异常上下线、服务变化
  3. 将发现的异常事件写入 anomaly_events 表
  4. 支持触发告警通知
"""

import json
import logging
from datetime import datetime, timedelta
from sqlalchemy.orm import Session

logger = logging.getLogger(__name__)

# 高危端口定义（端口号 → 服务名）
HIGH_RISK_PORTS = {
    "22": "SSH", "23": "Telnet", "3389": "RDP",
    "6379": "Redis", "27017": "MongoDB", "9200": "Elasticsearch",
    "2375": "Docker API（未授权）", "4848": "GlassFish",
    "11211": "Memcached", "50070": "Hadoop NameNode",
    "8888": "Jupyter Notebook", "1433": "MSSQL",
    "5432": "PostgreSQL", "3306": "MySQL",
    "445": "SMB", "135": "RPC",
    "8161": "ActiveMQ Console", "61616": "ActiveMQ Broker",
    "8848": "Nacos", "8069": "Odoo", "9000": "Portainer/PHP-FPM",
    "4443": "管理接口", "9090": "Prometheus/管理接口",
}


def run_anomaly_detection(db: Session) -> dict:
    """
    执行一次完整的异常检测，返回检测摘要。
    检测逻辑：取最近两次快照时间做对比，并与当前在线资产比对。
    """
    from db.models import AssetSnapshot, Asset
    from db import crud
    from sqlalchemy import desc, func

    # 获取最近两次快照时间
    snap_times = (
        db.query(AssetSnapshot.snapshot_at)
          .distinct()
          .order_by(desc(AssetSnapshot.snapshot_at))
          .limit(2)
          .all()
    )

    if len(snap_times) < 2:
        logger.info("[异常检测] 快照数量不足，跳过（需要至少两次扫描记录）")
        return {"status": "skipped", "reason": "快照数量不足（需至少两次资产扫描）"}

    time_new = snap_times[0][0]
    time_old = snap_times[1][0]

    logger.info(f"[异常检测] 对比快照: {time_old} → {time_new}")

    # 获取两次快照数据
    snaps_new = {s.ip_address: s for s in
                 db.query(AssetSnapshot).filter(AssetSnapshot.snapshot_at == time_new).all()}
    snaps_old = {s.ip_address: s for s in
                 db.query(AssetSnapshot).filter(AssetSnapshot.snapshot_at == time_old).all()}

    ips_new = set(snaps_new.keys())
    ips_old = set(snaps_old.keys())

    events_created = 0
    summary = {
        "new_assets": [], "disappeared": [],
        "new_high_risk_ports": [], "port_changes": [],
    }

    # 1. 检测新增资产
    for ip in ips_new - ips_old:
        ports = snaps_new[ip].open_ports or ""
        risk_ports = _get_high_risk_in_ports(ports)
        severity = "高" if risk_ports else "中"
        desc = f"发现新资产 {ip}，开放端口: {ports}"
        if risk_ports:
            desc += f"，其中高危端口: {', '.join(risk_ports)}"

        crud.save_anomaly_event(
            db, ip, anomaly_type="new_asset", severity=severity,
            description=desc, new_value=ports,
        )
        summary["new_assets"].append({"ip": ip, "ports": ports})
        events_created += 1

    # 2. 检测消失资产
    for ip in ips_old - ips_new:
        old_ports = snaps_old[ip].open_ports or ""
        crud.save_anomaly_event(
            db, ip, anomaly_type="asset_offline", severity="低",
            description=f"资产 {ip} 离线，上次开放端口: {old_ports}",
            old_value=old_ports,
        )
        summary["disappeared"].append({"ip": ip, "old_ports": old_ports})
        events_created += 1

    # 3. 检测端口变化（含高危端口新增）
    for ip in ips_new & ips_old:
        old_ports = set(p.strip() for p in (snaps_old[ip].open_ports or "").split(",") if p.strip())
        new_ports = set(p.strip() for p in (snaps_new[ip].open_ports or "").split(",") if p.strip())

        added = new_ports - old_ports
        removed = old_ports - new_ports

        if not added and not removed:
            continue

        # 新增高危端口
        new_risky = [p for p in added if p in HIGH_RISK_PORTS]
        if new_risky:
            for p in new_risky:
                service = HIGH_RISK_PORTS[p]
                crud.save_anomaly_event(
                    db, ip,
                    anomaly_type="new_high_risk_port",
                    severity="高",
                    description=f"资产 {ip} 新增高危端口 {p}({service})",
                    old_value=",".join(old_ports),
                    new_value=",".join(new_ports),
                )
                summary["new_high_risk_ports"].append({"ip": ip, "port": p, "service": service})
                events_created += 1

        # 普通端口变化
        normal_added = added - set(HIGH_RISK_PORTS.keys())
        if normal_added or removed:
            change_desc_parts = []
            if normal_added:
                change_desc_parts.append(f"新增端口: {', '.join(normal_added)}")
            if removed:
                change_desc_parts.append(f"关闭端口: {', '.join(removed)}")
            crud.save_anomaly_event(
                db, ip,
                anomaly_type="port_change",
                severity="低",
                description=f"资产 {ip} 端口变化：{'; '.join(change_desc_parts)}",
                old_value=",".join(old_ports),
                new_value=",".join(new_ports),
            )
            summary["port_changes"].append({
                "ip": ip, "added": list(normal_added), "removed": list(removed)
            })
            events_created += 1

    # 4. 检测当前资产中已有的高危端口（独立告警）
    _check_current_high_risk_ports(db, summary)

    logger.info(f"[异常检测] 完成，生成事件 {events_created} 条")

    return {
        "status": "ok",
        "snapshot_old": time_old.strftime("%Y-%m-%d %H:%M:%S"),
        "snapshot_new": time_new.strftime("%Y-%m-%d %H:%M:%S"),
        "events_created": events_created,
        "summary": {
            "new_assets": len(summary["new_assets"]),
            "disappeared": len(summary["disappeared"]),
            "new_high_risk_ports": len(summary["new_high_risk_ports"]),
            "port_changes": len(summary["port_changes"]),
        },
        "detail": summary,
    }


def get_high_risk_port_assets(db: Session) -> list[dict]:
    """
    查询当前所有在线资产中存在高危端口的资产列表。
    """
    from db.models import Asset
    assets = db.query(Asset).filter(Asset.status == "ONLINE").all()
    result = []
    for asset in assets:
        ports = set(p.strip() for p in (asset.open_ports or "").split(",") if p.strip())
        risky = [(p, HIGH_RISK_PORTS[p]) for p in ports if p in HIGH_RISK_PORTS]
        if risky:
            result.append({
                "id": asset.id,
                "ip_address": asset.ip_address,
                "risk_level": asset.risk_level or "未知",
                "high_risk_ports": [{"port": p, "service": s} for p, s in risky],
                "all_ports": asset.open_ports or "",
                "last_seen": asset.last_seen.strftime("%Y-%m-%d %H:%M:%S") if asset.last_seen else "",
            })
    result.sort(key=lambda x: len(x["high_risk_ports"]), reverse=True)
    return result


def get_anomaly_stats(db: Session) -> dict:
    """获取异常事件统计"""
    from db.models import AnomalyEvent
    from sqlalchemy import func
    total = db.query(func.count(AnomalyEvent.id)).scalar() or 0
    unhandled = db.query(func.count(AnomalyEvent.id)).filter(
        AnomalyEvent.status == "未处理").scalar() or 0
    high_sev = db.query(func.count(AnomalyEvent.id)).filter(
        AnomalyEvent.severity == "高", AnomalyEvent.status == "未处理").scalar() or 0
    today = datetime.utcnow().date()
    today_count = db.query(func.count(AnomalyEvent.id)).filter(
        AnomalyEvent.detected_at >= datetime.combine(today, datetime.min.time())).scalar() or 0
    return {
        "total": total,
        "unhandled": unhandled,
        "high_severity_unhandled": high_sev,
        "today": today_count,
    }


# ── 私有辅助 ──────────────────────────────────────────────────

def _get_high_risk_in_ports(ports_str: str) -> list[str]:
    """从端口字符串中提取高危端口"""
    ports = set(p.strip() for p in ports_str.split(",") if p.strip())
    return [p for p in ports if p in HIGH_RISK_PORTS]


def _check_current_high_risk_ports(db: Session, summary: dict):
    """
    检查当前所有资产是否有未被告警过的高危端口（防止首次扫描漏报）。
    """
    from db.models import Asset, AnomalyEvent
    assets = db.query(Asset).filter(Asset.status == "ONLINE").all()
    for asset in assets:
        risky = _get_high_risk_in_ports(asset.open_ports or "")
        for p in risky:
            # 检查是否已有未处理的告警
            exists = db.query(AnomalyEvent).filter(
                AnomalyEvent.ip_address == asset.ip_address,
                AnomalyEvent.anomaly_type == "high_risk_port_exists",
                AnomalyEvent.status == "未处理",
            ).first()
            if not exists:
                from db import crud
                service = HIGH_RISK_PORTS[p]
                crud.save_anomaly_event(
                    db, asset.ip_address,
                    anomaly_type="high_risk_port_exists",
                    severity="高",
                    description=f"资产 {asset.ip_address} 存在高危端口 {p}({service})",
                    new_value=p,
                )
