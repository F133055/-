"""消息推送通知模块 - 支持企业微信/飞书/钉钉/Bark"""
import logging
import requests
from typing import Optional, Dict
from enum import Enum

logger = logging.getLogger(__name__)


class NotifyChannel(str, Enum):
    WECHAT = "wechat"
    FEISHU = "feishu"
    DINGTALK = "dingtalk"
    BARK = "bark"


def send_wechat(webhook_url: str, title: str, content: str) -> bool:
    """企业微信机器人推送"""
    payload = {
        "msgtype": "markdown",
        "markdown": {
            "content": f"## {title}\n\n{content}"
        }
    }
    try:
        r = requests.post(webhook_url, json=payload, timeout=10)
        result = r.json()
        if result.get("errcode") == 0:
            logger.info(f"企业微信推送成功: {title}")
            return True
        else:
            logger.error(f"企业微信推送失败: {result}")
            return False
    except Exception as e:
        logger.error(f"企业微信推送异常: {e}")
        return False


def send_feishu(webhook_url: str, title: str, content: str) -> bool:
    """飞书机器人推送"""
    payload = {
        "msg_type": "post",
        "content": {
            "post": {
                "zh_cn": {
                    "title": title,
                    "content": [[{"tag": "text", "text": content}]]
                }
            }
        }
    }
    try:
        r = requests.post(webhook_url, json=payload, timeout=10)
        result = r.json()
        if result.get("StatusCode") == 0 or result.get("code") == 0:
            logger.info(f"飞书推送成功: {title}")
            return True
        else:
            logger.error(f"飞书推送失败: {result}")
            return False
    except Exception as e:
        logger.error(f"飞书推送异常: {e}")
        return False


def send_dingtalk(webhook_url: str, title: str, content: str) -> bool:
    """钉钉机器人推送"""
    payload = {
        "msgtype": "markdown",
        "markdown": {
            "title": title,
            "text": f"### {title}\n\n{content}"
        }
    }
    try:
        r = requests.post(webhook_url, json=payload, timeout=10)
        result = r.json()
        if result.get("errcode") == 0:
            logger.info(f"钉钉推送成功: {title}")
            return True
        else:
            logger.error(f"钉钉推送失败: {result}")
            return False
    except Exception as e:
        logger.error(f"钉钉推送异常: {e}")
        return False


def send_bark(api_key: str, title: str, content: str) -> bool:
    """Bark iOS 推送"""
    url = f"https://api.day.app/{api_key}/{title}/{content}"
    try:
        r = requests.get(url, timeout=10)
        result = r.json()
        if result.get("code") == 200:
            logger.info(f"Bark推送成功: {title}")
            return True
        else:
            logger.error(f"Bark推送失败: {result}")
            return False
    except Exception as e:
        logger.error(f"Bark推送异常: {e}")
        return False


def send_notification(channel: str, webhook_url: str = None, api_key: str = None,
                      title: str = "", content: str = "") -> bool:
    """统一推送入口"""
    if channel == NotifyChannel.WECHAT:
        return send_wechat(webhook_url, title, content)
    elif channel == NotifyChannel.FEISHU:
        return send_feishu(webhook_url, title, content)
    elif channel == NotifyChannel.DINGTALK:
        return send_dingtalk(webhook_url, title, content)
    elif channel == NotifyChannel.BARK:
        return send_bark(api_key, title, content)
    else:
        logger.warning(f"未知通知渠道: {channel}")
        return False


def notify_scan_complete(db, scan_type: str, result_summary: dict):
    """扫描完成后向所有启用渠道推送通知"""
    try:
        from db.models import NotifyConfig
        configs = db.query(NotifyConfig).filter(NotifyConfig.enabled == True).all()
        if not configs:
            return

        title = f"🔍 SecPlatform | {scan_type}扫描完成"
        lines = [f"**扫描类型**: {scan_type}"]
        for k, v in result_summary.items():
            lines.append(f"**{k}**: {v}")
        content = "\n".join(lines)

        for cfg in configs:
            send_notification(cfg.channel, cfg.webhook_url, cfg.api_key, title, content)

    except Exception as e:
        logger.error(f"推送通知失败: {e}")


def notify_high_risk(db, ip: str, vuln_title: str):
    """高危漏洞告警推送"""
    try:
        from db.models import NotifyConfig
        configs = db.query(NotifyConfig).filter(NotifyConfig.enabled == True).all()
        if not configs:
            return

        title = "🚨 SecPlatform | 高危漏洞告警"
        content = f"**目标IP**: {ip}\n**漏洞**: {vuln_title}\n**等级**: 高危\n请立即处理！"

        for cfg in configs:
            send_notification(cfg.channel, cfg.webhook_url, cfg.api_key, title, content)

    except Exception as e:
        logger.error(f"高危告警推送失败: {e}")


def send_notification_all(db, title: str, content: str) -> int:
    """向所有已启用的通知渠道发送消息，返回成功发送数量"""
    from db.crud import get_notify_configs
    configs = get_notify_configs(db)
    sent = 0
    for cfg in configs:
        if not getattr(cfg, 'enabled', True):
            continue
        try:
            ok = send_notification(
                channel=cfg.channel,
                webhook_url=cfg.webhook_url,
                api_key=cfg.api_key,
                title=title,
                content=content,
            )
            if ok:
                sent += 1
        except Exception as e:
            logger.warning(f"推送渠道 {cfg.channel} 失败: {e}")
    return sent
