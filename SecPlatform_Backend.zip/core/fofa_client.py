"""FOFA 互联网资产探测客户端"""
import base64
import logging
import requests
from typing import List, Dict, Optional

logger = logging.getLogger(__name__)

FOFA_API_URL = "https://fofa.info/api/v1/search/all"


class FOFAClient:
    def __init__(self, email: str, api_key: str):
        self.email = email
        self.api_key = api_key

    def search(self, query: str, size: int = 100, fields: str = None) -> Dict:
        """执行 FOFA 搜索"""
        if not fields:
            fields = "ip,port,protocol,title,country,city,org,domain,host"

        query_b64 = base64.b64encode(query.encode()).decode()
        params = {
            "email": self.email,
            "key": self.api_key,
            "qbase64": query_b64,
            "size": size,
            "fields": fields,
            "full": "false",
        }

        try:
            resp = requests.get(FOFA_API_URL, params=params, timeout=15)
            resp.raise_for_status()
            data = resp.json()

            if data.get("error"):
                logger.error(f"FOFA API 错误: {data.get('errmsg')}")
                return {"success": False, "error": data.get("errmsg"), "results": []}

            field_list = fields.split(",")
            results = []
            for row in data.get("results", []):
                item = {}
                for i, field in enumerate(field_list):
                    item[field] = row[i] if i < len(row) else ""
                results.append(item)

            logger.info(f"FOFA 查询 '{query}' 返回 {len(results)} 条结果")
            return {
                "success": True,
                "query": query,
                "total": data.get("size", 0),
                "results": results,
            }

        except requests.RequestException as e:
            logger.error(f"FOFA 请求失败: {e}")
            return {"success": False, "error": str(e), "results": []}
        except Exception as e:
            logger.error(f"FOFA 解析失败: {e}")
            return {"success": False, "error": str(e), "results": []}

    def search_by_domain(self, domain: str, size: int = 50) -> Dict:
        return self.search(f'domain="{domain}"', size=size)

    def search_by_keyword(self, keyword: str, size: int = 50) -> Dict:
        return self.search(f'"{keyword}"', size=size)

    def search_high_risk_ports(self, size: int = 100) -> Dict:
        """查找暴露高危端口的资产"""
        query = 'port="6379" || port="27017" || port="9200" || port="3306" || port="22"'
        return self.search(query, size=size)


def get_fofa_client(email: str = None, api_key: str = None) -> Optional[FOFAClient]:
    """从配置创建 FOFA 客户端"""
    try:
        from core.config import settings
        _email = email or getattr(settings, "FOFA_EMAIL", None)
        _key = api_key or getattr(settings, "FOFA_API_KEY", None)
        if not _email or not _key:
            logger.warning("FOFA 邮箱或 API Key 未配置")
            return None
        return FOFAClient(_email, _key)
    except Exception as e:
        logger.error(f"创建 FOFA 客户端失败: {e}")
        return None
