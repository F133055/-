"""后台定时任务调度器 v4.1 — 支持 interval/daily/weekly 三种模式"""
import json
import logging
import threading
import time
from datetime import datetime, timedelta

logger = logging.getLogger(__name__)

_thread: threading.Thread | None = None
_stop   = threading.Event()


# ── 公共 API ──────────────────────────────────────────────────
def start():
    global _thread
    _stop.clear()
    _thread = threading.Thread(target=_loop, daemon=True, name="TaskScheduler")
    _thread.start()
    logger.info("⏰ 定时任务调度器已启动")


def stop():
    _stop.set()
    if _thread:
        _thread.join(timeout=5)
    logger.info("⏰ 定时任务调度器已停止")


def dispatch_task(t) -> bool:
    """派发单条定时任务到 Celery（供路由层立即触发调用）"""
    return _dispatch(t)


def calc_next_run(t, from_dt: datetime = None) -> datetime:
    """
    根据调度类型计算下次运行时间
    schedule_type:
      interval  → from_dt + interval_hours
      daily     → 今天 run_at_time（如已过则明天）
      weekly    → 下一个 run_on_days 匹配的 run_at_time
    """
    now = from_dt or datetime.utcnow()
    stype = getattr(t, "schedule_type", "interval") or "interval"

    if stype == "interval":
        hours = getattr(t, "interval_hours", 24) or 24
        return now + timedelta(hours=hours)

    run_at = getattr(t, "run_at_time", None) or "08:00"
    try:
        h, m = map(int, run_at.split(":"))
    except Exception:
        h, m = 8, 0

    if stype == "daily":
        candidate = now.replace(hour=h, minute=m, second=0, microsecond=0)
        if candidate <= now:
            candidate += timedelta(days=1)
        return candidate

    if stype == "weekly":
        days_raw = getattr(t, "run_on_days", None) or "[0]"
        try:
            days = json.loads(days_raw) if isinstance(days_raw, str) else days_raw
            days = [int(d) for d in days]
        except Exception:
            days = [0]
        if not days:
            days = [0]
        # 找最近的匹配 weekday
        for offset in range(8):
            candidate = (now + timedelta(days=offset)).replace(
                hour=h, minute=m, second=0, microsecond=0
            )
            if candidate.weekday() in days and candidate > now:
                return candidate
        # fallback
        return now + timedelta(days=7)

    # 兜底
    return now + timedelta(hours=24)


# ── 内部实现 ───────────────────────────────────────────────────
def _loop():
    logger.info("⏰ 调度循环启动")
    while not _stop.wait(30):   # 每30秒检查一次（精度更高）
        try:
            _tick()
        except Exception as exc:
            logger.error(f"调度器 tick 异常: {exc}", exc_info=True)


def _tick():
    try:
        from db.models import ScheduledTask, get_db
        db = next(get_db())
        now = datetime.utcnow()
        try:
            due = db.query(ScheduledTask).filter(
                ScheduledTask.enabled == True,      # noqa
                ScheduledTask.next_run != None,     # noqa
                ScheduledTask.next_run <= now,
            ).all()

            for t in due:
                logger.info(f"⏰ 触发到期任务 [{t.name}] type={t.task_type}")
                ok           = _dispatch(t)
                t.last_run   = now
                t.last_status = "ok" if ok else "error"
                t.run_count  = (t.run_count or 0) + 1
                t.next_run   = calc_next_run(t, now)
                db.commit()
                logger.info(f"⏰ [{t.name}] {'成功' if ok else '失败'}，下次: {t.next_run}")
        finally:
            db.close()
    except Exception as exc:
        logger.error(f"_tick 异常: {exc}")


def _dispatch(t) -> bool:
    try:
        targets = json.loads(t.targets or "[]")
        params  = json.loads(t.params  or "{}")
        if not targets:
            logger.warning(f"定时任务 [{t.name}] targets 为空，跳过")
            return False

        from celery_app import (
            async_asset_scan_task,
            async_vuln_scan_task,
            async_weakpass_task,
        )

        if t.task_type == "asset":
            ports = params.get("ports", [22, 53, 80, 443, 3306, 6379, 8080, 8848])
            async_asset_scan_task.delay(target_ips=targets, target_ports=ports)

        elif t.task_type == "vuln":
            vuln_type = params.get("vuln_type", "nacos")
            port      = params.get("port", None)
            async_vuln_scan_task.delay(target_ips=targets, vuln_type=vuln_type, port=port)

        elif t.task_type == "weakpass":
            service = params.get("service", "ssh")
            port    = params.get("port", None)
            for ip in targets:
                async_weakpass_task.delay(ip=ip, service=service, port=port)

        elif t.task_type == "quickscan":
            # 综合扫描：派发全部选中的检查
            checks  = params.get("checks", ["port_scan", "nacos", "ssh", "mysql", "redis"])
            qs_ports = [21,22,23,25,53,80,443,445,1433,3306,3389,5432,5900,
                        6379,7001,8000,8080,8443,8848,9090,9200,27017]
            WEAK_SERVICES = {"ssh","mysql","redis","ftp","postgresql","telnet","mongodb","mssql"}
            VULN_TYPES    = {"nacos","swagger","minio","actuator","druid","redis_unauth","docker"}
            for chk in checks:
                if chk == "port_scan":
                    async_asset_scan_task.delay(target_ips=targets, target_ports=qs_ports)
                elif chk in WEAK_SERVICES:
                    for ip in targets:
                        async_weakpass_task.delay(ip=ip, service=chk)
                elif chk in VULN_TYPES:
                    async_vuln_scan_task.delay(target_ips=targets, vuln_type=chk)
        elif t.task_type in ("report_daily", "report_weekly"):
            # 自动生成报告并推送
            _auto_generate_and_push_report(t, params)

        else:
            logger.warning(f"未知 task_type: {t.task_type}")
            return False

        return True
    except Exception as exc:
        logger.error(f"_dispatch [{t.name}] 失败: {exc}")
        return False


def _auto_generate_and_push_report(task, params: dict):
    """生成报告并推送通知"""
    try:
        from db.database import SessionLocal
        from core.report_generator import generate_daily_report, generate_weekly_report
        from core import notifier
        from db import crud

        db = SessionLocal()
        try:
            rtype = task.task_type  # report_daily / report_weekly
            if rtype == "report_daily":
                data  = generate_daily_report(db)
                title = "📊 SecPlatform 安全日报"
            else:
                data  = generate_weekly_report(db)
                title = "📅 SecPlatform 安全周报"

            summary = data.get("summary", {})
            body = (
                f"资产总数: {summary.get('total_assets', '-')}\n"
                f"在线资产: {summary.get('online_assets', '-')}\n"
                f"漏洞总数: {summary.get('total_vulns', '-')}\n"
                f"高危漏洞: {summary.get('high_vulns', '-')}\n"
                f"弱密码: {summary.get('weak_passwords', '-')}\n"
            )
            # 保存报告记录
            crud.create_report(
                db, title=title,
                report_type="daily" if rtype == "report_daily" else "weekly",
                content=data.get("html", ""),
                summary=summary,
                created_by="scheduler",
            )
            # 推送通知
            push_enabled = params.get("push_notify", True)
            if push_enabled:
                notifier.send_notification_all(db, title=title, content=body)
            logger.info(f"[定时报告] {title} 生成完成，推送={'是' if push_enabled else '否'}")
        finally:
            db.close()
    except Exception as e:
        logger.error(f"[定时报告] 生成失败: {e}", exc_info=True)
