"""应用配置模块"""
import os
import logging
import logging.handlers
from pathlib import Path
from typing import Optional
from pydantic_settings import BaseSettings, SettingsConfigDict

logger = logging.getLogger(__name__)

CORE_DIR    = Path(__file__).parent.resolve()
PROJECT_ROOT = CORE_DIR.parent.resolve()
ENV_FILE    = PROJECT_ROOT / ".env"
LOG_DIR     = PROJECT_ROOT / "logs"


class Settings(BaseSettings):
    PROJECT_NAME:    str = "SecPlatform"
    PROJECT_VERSION: str = "4.0.0"
    PROJECT_DESC:    str = "安全专项扫描与智能分析平台"

    DB_URL:     Optional[str] = None
    SECRET_KEY: Optional[str] = None

    LOG_LEVEL:  str = "DEBUG"
    LOG_FORMAT: str = "%(asctime)s [%(levelname)s] %(name)s - %(message)s"

    # ── 登录账号（从 .env 读取）────────────────────────────
    ADMIN_USERNAME: str = "admin"
    ADMIN_PASSWORD: str = "admin@2025"
    TEST_USERNAME:  Optional[str] = None
    TEST_PASSWORD:  Optional[str] = None

    # ── FOFA ───────────────────────────────────────────────
    FOFA_EMAIL:   Optional[str] = None
    FOFA_API_KEY: Optional[str] = None

    # ── GitHub / Gitee 信息收集 ─────────────────────────────
    GITHUB_TOKEN: Optional[str] = None   # GitHub Personal Access Token (ghp_xxx)
    GITEE_TOKEN:  Optional[str] = None   # Gitee 私人令牌（可选）

    # ── LLM 智能分析（OpenAI 兼容接口）──────────────────────────────────
    LLM_API_URL:  Optional[str] = None   # 如: https://api.openai.com/v1
    LLM_API_KEY:  Optional[str] = None   # API Key
    LLM_MODEL:    Optional[str] = None   # 如: gpt-4o-mini / qwen2.5

    DICT_DIR: Optional[str] = None

    CELERY_BROKER:  str  = "redis://127.0.0.1:6379/0"
    CELERY_BACKEND: str  = "redis://127.0.0.1:6379/1"
    REDIS_HOST:     str  = "127.0.0.1"
    REDIS_PORT:     int  = 6379
    REDIS_DB:       int  = 0

    CORS_ORIGINS:         list = ["*"]
    API_PREFIX:           str  = "/api"
    SCAN_TIMEOUT:         int  = 300
    CONCURRENT_WORKERS:   int  = 50
    MAX_TARGETS_PER_SCAN: int  = 1000

    model_config = SettingsConfigDict(
        env_file=str(ENV_FILE),
        env_file_encoding="utf-8",
        extra="ignore",
        case_sensitive=True
    )

    def __init__(self, **values):
        super().__init__(**values)
        if not self.DICT_DIR:
            self.DICT_DIR = str(PROJECT_ROOT / "dicts")
        Path(self.DICT_DIR).mkdir(parents=True, exist_ok=True)


try:
    settings = Settings()
except Exception as e:
    logger.error(f"❌ 配置加载失败: {e}")
    raise


def setup_logging():
    """配置日志：同时输出到控制台和文件"""
    LOG_DIR.mkdir(exist_ok=True)
    log_file = LOG_DIR / "secplatform.log"

    root = logging.getLogger()
    root.setLevel(getattr(logging, settings.LOG_LEVEL, logging.DEBUG))

    fmt = logging.Formatter(settings.LOG_FORMAT)

    # 控制台
    ch = logging.StreamHandler()
    ch.setFormatter(fmt)
    ch.setLevel(logging.DEBUG)

    # 文件（按天切割，保留 7 天）
    fh = logging.handlers.TimedRotatingFileHandler(
        log_file, when="midnight", backupCount=7, encoding="utf-8"
    )
    fh.setFormatter(fmt)
    fh.setLevel(logging.DEBUG)

    # 避免重复添加
    if not root.handlers:
        root.addHandler(ch)
        root.addHandler(fh)
    else:
        root.handlers.clear()
        root.addHandler(ch)
        root.addHandler(fh)

    logger.info(f"✅ 日志系统初始化完成，日志文件: {log_file}")
    return log_file


def validate_required_settings() -> tuple[bool, list[str]]:
    missing = []
    for field, desc in {"DB_URL": "数据库连接字符串", "SECRET_KEY": "JWT 签名密钥"}.items():
        if not getattr(settings, field, None):
            missing.append(f"{field}: {desc}")
    return len(missing) == 0, missing


def show_config_summary():
    lines = [
        "=" * 60,
        f"  SecPlatform v{settings.PROJECT_VERSION}",
        "=" * 60,
        f"  数据库  : {(settings.DB_URL or '')[:45]}...",
        f"  管理员  : {settings.ADMIN_USERNAME}",
        f"  日志级别: {settings.LOG_LEVEL}",
        f"  日志目录: {LOG_DIR}",
        "=" * 60,
    ]
    for l in lines:
        logger.info(l)
