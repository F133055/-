"""
弱密码扫描器 - core/weakpass_scanner.py  v4.1
========================================
新增：
  - 所有服务支持自定义端口（port 参数）
  - 端口预检失败时提示具体使用的端口
"""

import logging
import socket
import time
import os
from core.config import settings

logger = logging.getLogger(__name__)

TIMEOUT = 2
DELAY   = 0.05


def load_dictionary(filename: str) -> list:
    filepath = os.path.join(settings.DICT_DIR, filename)
    if not os.path.exists(filepath):
        logger.warning(f"字典文件不存在: {filepath}")
        return []
    try:
        with open(filepath, "r", encoding="utf-8") as f:
            return [line.strip() for line in f if line.strip()]
    except Exception as e:
        logger.error(f"读取字典 {filename} 失败: {e}")
        return []


# ─────────────────────────────────────────────────────────────
# SSH
# ─────────────────────────────────────────────────────────────
def ssh_test_login(ip: str, username: str, password: str, port: int = 22) -> bool:
    try:
        import paramiko
        client = paramiko.SSHClient()
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        client.connect(hostname=ip, port=port, username=username,
                       password=password, timeout=TIMEOUT,
                       allow_agent=False, look_for_keys=False)
        client.close()
        return True
    except Exception:
        return False


# ─────────────────────────────────────────────────────────────
# MySQL
# ─────────────────────────────────────────────────────────────
def mysql_test_login(ip: str, username: str, password: str, port: int = 3306) -> bool:
    try:
        import pymysql
        conn = pymysql.connect(host=ip, port=port, user=username,
                               password=password, connect_timeout=TIMEOUT)
        conn.close()
        return True
    except Exception:
        return False


# ─────────────────────────────────────────────────────────────
# Redis
# ─────────────────────────────────────────────────────────────
def redis_test_login(ip: str, username: str, password: str, port: int = 6379) -> bool:
    """Redis 弱密码检测，支持自定义端口"""
    try:
        with socket.create_connection((ip, port), timeout=TIMEOUT) as sock:
            if password == "":
                sock.sendall(b"PING\r\n")
                resp = sock.recv(64).decode("utf-8", errors="ignore")
                if "+PONG" in resp:
                    return True
            else:
                cmd = f"AUTH {password}\r\n".encode()
                sock.sendall(cmd)
                resp = sock.recv(64).decode("utf-8", errors="ignore")
                if "+OK" in resp:
                    return True
    except Exception:
        pass
    return False


# ─────────────────────────────────────────────────────────────
# MongoDB
# ─────────────────────────────────────────────────────────────
def mongodb_test_login(ip: str, username: str, password: str, port: int = 27017) -> bool:
    try:
        import pymongo
        if username == "" or password == "":
            client = pymongo.MongoClient(
                host=ip, port=port,
                serverSelectionTimeoutMS=TIMEOUT * 1000,
                connectTimeoutMS=TIMEOUT * 1000,
            )
            client.server_info()
            client.close()
            return True
        uri = f"mongodb://{username}:{password}@{ip}:{port}/"
        client = pymongo.MongoClient(uri,
            serverSelectionTimeoutMS=TIMEOUT * 1000,
            connectTimeoutMS=TIMEOUT * 1000,
        )
        client.server_info()
        client.close()
        return True
    except Exception:
        return False


# ─────────────────────────────────────────────────────────────
# PostgreSQL
# ─────────────────────────────────────────────────────────────
def postgresql_test_login(ip: str, username: str, password: str, port: int = 5432) -> bool:
    try:
        import psycopg2
        conn = psycopg2.connect(
            host=ip, port=port,
            user=username, password=password,
            connect_timeout=TIMEOUT, database="postgres"
        )
        conn.close()
        return True
    except Exception:
        return False


# ─────────────────────────────────────────────────────────────
# FTP
# ─────────────────────────────────────────────────────────────
def ftp_test_login(ip: str, username: str, password: str, port: int = 21) -> bool:
    try:
        import ftplib
        ftp = ftplib.FTP()
        ftp.connect(host=ip, port=port, timeout=TIMEOUT)
        ftp.login(user=username, passwd=password)
        ftp.quit()
        return True
    except Exception:
        return False


# ─────────────────────────────────────────────────────────────
# Telnet
# ─────────────────────────────────────────────────────────────
def telnet_test_login(ip: str, username: str, password: str, port: int = 23) -> bool:
    try:
        with socket.create_connection((ip, port), timeout=TIMEOUT) as sock:
            time.sleep(0.5)
            banner = sock.recv(256).decode("utf-8", errors="ignore")
            if "login" in banner.lower() or "username" in banner.lower():
                sock.sendall((username + "\r\n").encode())
                time.sleep(0.5)
                resp = sock.recv(256).decode("utf-8", errors="ignore")
                if "password" in resp.lower():
                    sock.sendall((password + "\r\n").encode())
                    time.sleep(0.5)
                    final = sock.recv(256).decode("utf-8", errors="ignore")
                    if any(c in final for c in ["$", "#", ">"]):
                        return True
        return False
    except Exception:
        return False


# ─────────────────────────────────────────────────────────────
# MSSQL
# ─────────────────────────────────────────────────────────────
def mssql_test_login(ip: str, username: str, password: str, port: int = 1433) -> bool:
    try:
        import pymssql
        conn = pymssql.connect(
            server=ip, port=port,
            user=username, password=password,
            timeout=TIMEOUT, login_timeout=TIMEOUT
        )
        conn.close()
        return True
    except Exception:
        return False


# ─────────────────────────────────────────────────────────────
# 服务注册表
# ─────────────────────────────────────────────────────────────
SUPPORTED_SERVICES = {
    "ssh":        ssh_test_login,
    "mysql":      mysql_test_login,
    "redis":      redis_test_login,
    "mongodb":    mongodb_test_login,
    "postgresql": postgresql_test_login,
    "ftp":        ftp_test_login,
    "telnet":     telnet_test_login,
    "mssql":      mssql_test_login,
    "oracle":     oracle_test_login,
    "dm":         dm_test_login,
    "web":        web_test_login,
}

# 默认端口
SERVICE_DEFAULT_PORTS = {
    "ssh": 22, "mysql": 3306, "redis": 6379,
    "ftp": 21, "mongodb": 27017, "postgresql": 5432,
    "telnet": 23, "mssql": 1433, "oracle": 1521,
    "dm": 5236, "web": 80,
}


def start_brute_force(ip: str, service: str = "ssh", port: int = None) -> str:
    """
    对指定 IP 和服务进行弱密码爆破
    port: 自定义端口（None=使用默认端口）
    """
    service = service.lower()

    if service not in SUPPORTED_SERVICES:
        return f"❌ 不支持的协议类型: {service}，支持: {list(SUPPORTED_SERVICES.keys())}"

    # 确定实际使用的端口
    actual_port = port if port else SERVICE_DEFAULT_PORTS.get(service, 0)

    # 端口可达性预检
    if actual_port:
        try:
            with socket.create_connection((ip, actual_port), timeout=1):
                pass
        except Exception:
            msg = f"✅ {service.upper()} 端口 {actual_port} 不可达，跳过爆破"
            logger.info(f"[弱密码] {ip} {msg}")
            return msg

    usernames = load_dictionary("users.txt") or ["root", "admin", "test", "guest"]
    passwords = load_dictionary("pass.txt")  or ["123456", "password", "admin123", "root", ""]

    if service == "redis":
        usernames = [""]
    if service == "mongodb":
        usernames = [""] + usernames
        passwords = [""] + passwords

    attack_fn = SUPPORTED_SERVICES[service]
    logger.info(f"[弱密码] 目标:{ip}:{actual_port} 服务:{service.upper()} "
                f"用户:{len(usernames)} 密码:{len(passwords)}")

    tried = 0
    for u in usernames:
        for p in passwords:
            try:
                # 统一传入 port 参数
                if actual_port:
                    success = attack_fn(ip, u, p, port=actual_port)
                else:
                    success = attack_fn(ip, u, p)

                if success:
                    cred = f"{u}:{p}" if u else p
                    msg  = f"⚠️ 发现 {service.upper()} 弱口令: {cred}"
                    logger.warning(f"[弱密码] {ip}:{actual_port} {msg}")
                    return msg
            except Exception as e:
                logger.debug(f"[弱密码] {ip} {u}:{p} 异常: {e}")
            tried += 1
            time.sleep(DELAY)

    msg = f"✅ 未发现 {service.upper()} 弱口令（共测试 {tried} 个组合，端口 {actual_port}）"
    logger.info(f"[弱密码] {ip} {msg}")
    return msg


def get_supported_services() -> list:
    return list(SUPPORTED_SERVICES.keys())


# ─────────────────────────────────────────────────────────────
# Oracle 弱密码检测
# ─────────────────────────────────────────────────────────────
def oracle_test_login(ip: str, username: str, password: str, port: int = 1521) -> bool:
    """Oracle 弱密码检测（需要 cx_Oracle 或 oracledb）"""
    try:
        import oracledb  # pip install oracledb
        conn = oracledb.connect(
            user=username, password=password,
            dsn=f"{ip}:{port}/orcl",
            disable_oob=True
        )
        conn.close()
        return True
    except ImportError:
        pass
    try:
        import cx_Oracle  # fallback
        conn = cx_Oracle.connect(username, password, f"{ip}:{port}/orcl")
        conn.close()
        return True
    except Exception:
        return False
    except Exception:
        return False


# ─────────────────────────────────────────────────────────────
# 达梦数据库 (DM) 弱密码检测
# ─────────────────────────────────────────────────────────────
def dm_test_login(ip: str, username: str, password: str, port: int = 5236) -> bool:
    """达梦数据库弱密码检测（需要 dmPython）"""
    try:
        import dmPython  # pip install dmPython (达梦官方驱动)
        conn = dmPython.connect(
            user=username, password=password,
            server=ip, port=port
        )
        conn.close()
        return True
    except ImportError:
        # 没有驱动时用 TCP 连通性探测代替
        return _check_tcp_port(ip, port)
    except Exception:
        return False


def _check_tcp_port(ip: str, port: int, timeout: float = 3.0) -> bool:
    import socket
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.settimeout(timeout)
        r = s.connect_ex((ip, port))
        s.close()
        return r == 0
    except Exception:
        return False


# ─────────────────────────────────────────────────────────────
# Web 系统弱密码检测（HTTP 表单登录爆破）
# ─────────────────────────────────────────────────────────────
import re as _re

# 常见 Web 系统登录接口特征
WEB_LOGIN_FINGERPRINTS = [
    # (path, method, user_field, pass_field, success_indicator, fail_indicator)
    ("/login",            "POST", "username", "password", None, ["invalid","error","incorrect","失败","错误","密码错误","用户名或密码"]),
    ("/api/login",        "POST", "username", "password", None, ["invalid","error","incorrect","失败","错误"]),
    ("/api/auth/login",   "POST", "username", "password", None, ["invalid","error","incorrect","失败","错误"]),
    ("/admin/login",      "POST", "username", "password", None, ["invalid","error","incorrect","失败","错误"]),
    ("/user/login",       "POST", "username", "password", None, ["invalid","error","incorrect","失败","错误"]),
    ("/auth/login",       "POST", "username", "password", None, ["invalid","error","incorrect","失败","错误"]),
    ("/system/login",     "POST", "username", "password", None, ["invalid","error","incorrect","失败","错误"]),
]

def web_test_login(ip: str, username: str, password: str, port: int = 80) -> bool:
    """Web 系统弱密码检测：自动探测登录接口并尝试登录"""
    import requests
    session = requests.Session()
    session.verify = False
    session.timeout = 5

    schemes = ["https"] if port in (443, 8443) else ["http", "https"]

    for scheme in schemes:
        base = f"{scheme}://{ip}:{port}"
        for fp in WEB_LOGIN_FINGERPRINTS:
            path, method, uf, pf, success_ind, fail_inds = fp
            url = f"{base}{path}"
            try:
                r = session.request(
                    method, url,
                    json={uf: username, pf: password},
                    headers={"Content-Type": "application/json"},
                    timeout=4, allow_redirects=True
                )
                body = r.text.lower()
                # 成功判断: 状态码200且无失败特征
                if r.status_code == 200:
                    if not any(ind in body for ind in fail_inds):
                        # 进一步检测：含 token/session 等关键字
                        if any(k in body for k in ["token","session","user","success","redirect","dashboard","home"]):
                            return True
                # 302跳转通常也是成功
                if r.status_code in (301, 302):
                    loc = r.headers.get("location","")
                    if not any(ind in loc for ind in ["login","signin","error"]):
                        return True
            except Exception:
                continue
    return False
