"""
资产端口扫描模块 - core/core_scanner.py  v4.2
优化：
  - 使用 with 管理 socket，防止资源泄漏
  - DNS 预解析（带超时），避免域名导致的长时间阻塞
  - 批量 IP 并发扫描（IP 级别并发 + 端口级别并发），大幅提升多目标速度
  - 返回结构与原版完全兼容
"""
import logging
import socket
import threading
import concurrent.futures

logger = logging.getLogger(__name__)


def _resolve_ip(host: str, timeout: float = 1.5) -> str | None:
    """带超时的 DNS 预解析，纯 IP 直接返回"""
    try:
        socket.inet_aton(host)
        return host
    except socket.error:
        pass
    result = [None]
    def _do():
        try:
            info = socket.getaddrinfo(host, None, socket.AF_INET)
            if info:
                result[0] = info[0][4][0]
        except Exception:
            pass
    t = threading.Thread(target=_do, daemon=True)
    t.start()
    t.join(timeout)
    return result[0]


def check_port(ip: str, port: int, timeout: float = 1.0) -> int | None:
    """检测单端口，开放返回端口号，否则 None"""
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
            sock.settimeout(timeout)
            if sock.connect_ex((ip, port)) == 0:
                logger.debug(f"  [+] {ip}:{port} 开放")
                return port
    except Exception:
        pass
    return None


def _scan_single_ip(ip: str, ports: list) -> list:
    """扫描单个 IP 的所有端口，返回开放端口列表"""
    resolved = _resolve_ip(ip)
    if not resolved:
        logger.warning(f"[scan] {ip}: DNS 解析失败，跳过")
        return []

    open_ports = []
    with concurrent.futures.ThreadPoolExecutor(max_workers=50) as executor:
        futs = {executor.submit(check_port, resolved, p): p for p in ports}
        for fut in concurrent.futures.as_completed(futs):
            try:
                r = fut.result()
                if r is not None:
                    open_ports.append(r)
            except Exception:
                pass
    return sorted(open_ports)


def scan_ports(ip_list: list, ports: list) -> dict:
    """
    批量端口扫描。
    v4.2 新增：多 IP 并发（最多 10 个 IP 同时扫），单 IP 内 50 线程并发端口。
    返回格式与原版兼容：{ip: [open_ports...]}
    """
    logger.info(f"[scan] 🚀 启动，{len(ip_list)} 个目标，{len(list(ports))} 个端口")

    # 单个目标时直接扫，不额外起线程
    if len(ip_list) == 1:
        ip = ip_list[0]
        open_ports = _scan_single_ip(ip, list(ports))
        logger.info(f"[scan] {ip} 完成，发现 {len(open_ports)} 个开放端口")
        return {ip: open_ports}

    # 多目标：最多 10 个 IP 并发（每 IP 内已有 50 线程，避免线程爆炸）
    results = {}
    with concurrent.futures.ThreadPoolExecutor(max_workers=min(10, len(ip_list))) as executor:
        fut_map = {executor.submit(_scan_single_ip, ip, list(ports)): ip for ip in ip_list}
        for fut in concurrent.futures.as_completed(fut_map):
            ip = fut_map[fut]
            try:
                open_ports = fut.result()
                results[ip] = open_ports
                logger.info(f"[scan] {ip} 完成，发现 {len(open_ports)} 个开放端口")
            except Exception as e:
                logger.error(f"[scan] {ip} 扫描异常: {e}")
                results[ip] = []

    return results
