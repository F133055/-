"""安全报告自动生成模块 - SecPlatform v4"""
import logging
from datetime import datetime, timedelta
from typing import Dict, List

logger = logging.getLogger(__name__)

# 高危端口定义
DANGEROUS_PORTS = {
    "22": "SSH", "23": "Telnet", "3389": "RDP",
    "6379": "Redis", "27017": "MongoDB", "9200": "Elasticsearch",
    "2375": "Docker API", "4848": "GlassFish", "11211": "Memcached",
    "50070": "Hadoop NameNode", "8888": "Jupyter Notebook",
    "1433": "MSSQL", "5432": "PostgreSQL", "3306": "MySQL暴露",
}


def _extract_error(result_summary: str) -> str:
    """从 result_summary JSON 中提取错误信息"""
    if not result_summary:
        return "未知错误"
    try:
        import json
        d = json.loads(result_summary)
        return d.get("error", "任务执行失败")[:100]
    except Exception:
        return str(result_summary)[:100]


def _format_description(desc: str) -> tuple:
    """美化漏洞描述，提取关键信息，返回 (显示文本, 颜色)"""
    if not desc:
        return "—", "#94a3b8"
    # 弱口令：⚠️ 发现 SSH 弱口令: root:123456
    if desc.startswith("⚠️"):
        clean = desc.replace("⚠️", "").strip()
        return clean, "#ef4444"
    # 已修复/最新未发现
    if "[重新扫描]" in desc:
        return "最新扫描未复现（建议确认已修复）", "#22c55e"
    if desc.startswith("✅"):
        return desc.replace("✅", "").strip(), "#94a3b8"
    # 其他漏洞描述（nacos/redis/swagger 等）
    return desc[:120] + ("..." if len(desc) > 120 else ""), "#64748b"


def _vuln_rows_html(vulns: list) -> str:
    rows = ""
    for v in vulns:
        c = {"高": "#ef4444", "中": "#f59e0b", "低": "#22c55e"}.get(v["severity"], "#6b7280")
        desc_text, desc_color = _format_description(v.get("description", ""))
        evidence = v.get("evidence", "")
        # 若有 evidence（原始请求/响应），在描述后追加简短摘要
        if evidence and "弱口令" not in (v.get("description", "")):
            ev_short = evidence[:80].replace("<", "&lt;").replace(">", "&gt;")
            evidence_td = f'<td style="font-size:11px;color:#64748b;max-width:250px;word-break:break-all">{ev_short}{"..." if len(evidence)>80 else ""}</td>'
        else:
            evidence_td = ""
        rows += (
            f'<tr>'
            f'<td>{v["ip"]}</td>'
            f'<td>{v["type"]}</td>'
            f'<td>{v["title"]}</td>'
            f'<td style="color:{c};font-weight:bold">{v["severity"]}</td>'
            f'<td style="color:{desc_color};font-size:12px;max-width:300px;word-break:break-all;line-height:1.5">{desc_text}</td>'
            f'<td>{v["time"]}</td>'
            f'</tr>'
        )
    return rows or '<tr><td colspan="6" style="text-align:center;color:#94a3b8">暂无漏洞记录</td></tr>'


def _port_rows_html(assets: list) -> str:
    rows = ""
    for a in assets[:30]:
        ports = ", ".join(a.get("risky_ports", a.get("ports", [])))
        rows += f'<tr><td>{a["ip"]}</td><td style="color:#ef4444">{ports}</td></tr>'
    return rows


def _render_html(data: dict, report_type: str) -> str:
    """通用 HTML 渲染"""
    date_str = data.get("date", datetime.utcnow().strftime("%Y-%m-%d"))
    subtitle = data.get("subtitle", f"报告日期：{date_str}")

    cards_html = "".join(f'''
    <div class="stat-card">
      <div class="label">{label}</div>
      <div class="number {cls}">{value}</div>
    </div>''' for label, value, cls in data.get("cards", []))

    extra_sections = data.get("extra_sections", "")

    vuln_rows = _vuln_rows_html(data.get("recent_vulnerabilities", []))
    vuln_title = data.get("vuln_section_title", "最新漏洞")

    port_section = ""
    if data.get("high_risk_port_assets"):
        port_rows = _port_rows_html(data["high_risk_port_assets"])
        port_section = f'''
        <div class="section">
          <h2>🔴 高危端口暴露资产</h2>
          <table><thead><tr><th>IP地址</th><th>高危端口（服务）</th></tr></thead>
          <tbody>{port_rows}</tbody></table>
        </div>'''

    return f"""<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<title>SecPlatform 安全{report_type} - {date_str}</title>
<style>
  body{{font-family:'Helvetica Neue',Arial,sans-serif;background:#f8fafc;color:#1e293b;margin:0;padding:20px}}
  .header{{background:linear-gradient(135deg,#0f172a,#1e3a5f);color:white;padding:30px;border-radius:12px;margin-bottom:24px}}
  .header h1{{margin:0 0 8px;font-size:28px}}.header p{{margin:0;opacity:.7}}
  .stats-grid{{display:grid;grid-template-columns:repeat(auto-fit,minmax(140px,1fr));gap:14px;margin-bottom:24px}}
  .stat-card{{background:white;border-radius:10px;padding:18px;box-shadow:0 1px 3px rgba(0,0,0,.1);text-align:center}}
  .stat-card .number{{font-size:32px;font-weight:bold;margin:8px 0}}
  .stat-card .label{{color:#64748b;font-size:12px}}
  .danger{{color:#ef4444}}.warning{{color:#f59e0b}}.success{{color:#22c55e}}.info{{color:#3b82f6}}
  .section{{background:white;border-radius:10px;padding:24px;margin-bottom:20px;box-shadow:0 1px 3px rgba(0,0,0,.1)}}
  .section h2{{margin-top:0;color:#0f172a;border-bottom:2px solid #e2e8f0;padding-bottom:12px}}
  table{{width:100%;border-collapse:collapse}}
  th{{background:#f1f5f9;padding:10px;text-align:left;font-size:13px;color:#475569}}
  td{{padding:10px;border-bottom:1px solid #f1f5f9;font-size:14px}}
  tr:last-child td{{border-bottom:none}}
  .footer{{text-align:center;color:#94a3b8;font-size:12px;margin-top:24px}}
</style>
</head>
<body>
<div class="header">
  <h1>🛡️ SecPlatform 安全{report_type}</h1>
  <p>{subtitle} | 自动化安全扫描与智能分析平台</p>
</div>
<div class="stats-grid">{cards_html}</div>
{port_section}
{extra_sections}
<div class="section">
  <h2>🔍 {vuln_title}</h2>
  <table><thead><tr><th>IP地址</th><th>漏洞类型</th><th>漏洞标题</th><th>严重程度</th><th>凭据 / 检测详情</th><th>发现时间</th></tr></thead>
  <tbody>{vuln_rows}</tbody></table>
</div>
<div class="footer"><p>本报告由 SecPlatform 自动生成 | © 2025 SecPlatform</p></div>
</body>
</html>"""


def generate_daily_report(db) -> Dict:
    """生成日报"""
    from db.models import Asset, Vulnerability, ScanTask
    from sqlalchemy import func

    today = datetime.utcnow().date()

    total_assets     = db.query(func.count(Asset.id)).scalar() or 0
    online_assets    = db.query(func.count(Asset.id)).filter(Asset.status == "ONLINE").scalar() or 0
    new_assets       = db.query(func.count(Asset.id)).filter(func.date(Asset.created_at) == today).scalar() or 0
    high_risk_assets = db.query(func.count(Asset.id)).filter(Asset.risk_level == "高").scalar() or 0

    total_vulns    = db.query(func.count(Vulnerability.id)).scalar() or 0
    high_vulns     = db.query(func.count(Vulnerability.id)).filter(Vulnerability.severity == "高").scalar() or 0
    new_vulns      = db.query(func.count(Vulnerability.id)).filter(func.date(Vulnerability.discovered_at) == today).scalar() or 0
    unhandled      = db.query(func.count(Vulnerability.id)).filter(Vulnerability.status == "未处理").scalar() or 0
    tasks_today    = db.query(func.count(ScanTask.id)).filter(func.date(ScanTask.created_at) == today).scalar() or 0
    tasks_failed   = db.query(func.count(ScanTask.id)).filter(
        func.date(ScanTask.created_at) == today,
        ScanTask.status.in_(["FAILED", "FAILURE"])
    ).scalar() or 0

    # 获取今日失败任务详情
    failed_tasks = db.query(ScanTask).filter(
        func.date(ScanTask.created_at) == today,
        ScanTask.status.in_(["FAILED", "FAILURE"])
    ).order_by(ScanTask.created_at.desc()).limit(10).all()

    # 高危端口资产
    high_port_assets = []
    for a in db.query(Asset).filter(Asset.status == "ONLINE").all():
        ports = [p.strip() for p in (a.open_ports or "").split(",") if p.strip()]
        risky = [f"{p}({DANGEROUS_PORTS[p]})" for p in ports if p in DANGEROUS_PORTS]
        if risky:
            high_port_assets.append({"ip": a.ip_address, "risky_ports": risky})

    recent_vulns = db.query(Vulnerability).order_by(Vulnerability.discovered_at.desc()).limit(15).all()

    summary = {
        "date": today.strftime("%Y-%m-%d"),
        "total_assets": total_assets, "online_assets": online_assets,
        "new_assets_today": new_assets, "high_risk_assets": high_risk_assets,
        "total_vulnerabilities": total_vulns, "high_vulnerabilities": high_vulns,
        "new_vulnerabilities_today": new_vulns, "unhandled_vulnerabilities": unhandled,
        "tasks_today": tasks_today,
        "tasks_failed": tasks_failed,
        "failed_tasks_detail": [
            {
                "task_id": t.task_id[:8] + "...",
                "task_type": t.task_type,
                "operator": t.operator or "系统",
                "created_at": t.created_at.strftime("%Y-%m-%d %H:%M") if t.created_at else "",
                "error": _extract_error(t.result_summary),
            }
            for t in failed_tasks
        ],
        "high_risk_port_assets": high_port_assets,
        "recent_vulnerabilities": [
            {"ip": v.ip_address, "type": v.vuln_type, "title": v.title,
             "severity": v.severity,
             "description": v.description or "",
             "evidence": v.evidence or "",
             "time": v.discovered_at.strftime("%Y-%m-%d %H:%M") if v.discovered_at else ""}
            for v in recent_vulns
        ],
    }

    html_data = {
        "date": today.strftime("%Y-%m-%d"),
        "subtitle": f"报告日期：{today.strftime('%Y-%m-%d')} | 今日新增任务：{tasks_today}",
        "cards": [
            ("资产总数",    total_assets,  "info"),
            ("在线资产",    online_assets,  "success"),
            ("今日新增资产", new_assets,   "info"),
            ("高危资产",    high_risk_assets, "danger"),
            ("漏洞总数",    total_vulns,   "warning"),
            ("高危漏洞",    high_vulns,    "danger"),
            ("今日新增漏洞", new_vulns,    "warning"),
            ("待处理漏洞",  unhandled,     "danger"),
            ("今日失败任务", tasks_failed,  "danger" if tasks_failed else "info"),
        ],
        "high_risk_port_assets": high_port_assets,
        "recent_vulnerabilities": summary["recent_vulnerabilities"],
        "vuln_section_title": "最新漏洞",
        "failed_tasks": summary.get("failed_tasks_detail", []),
    }
    return {"summary": summary, "html": _render_html(html_data, "日报")}


def generate_weekly_report(db) -> Dict:
    """生成周报"""
    from db.models import Asset, Vulnerability, ScanTask
    from sqlalchemy import func

    today      = datetime.utcnow().date()
    week_start = today - timedelta(days=7)
    week_start_dt = datetime.combine(week_start, datetime.min.time())

    total_assets    = db.query(func.count(Asset.id)).scalar() or 0
    online_assets   = db.query(func.count(Asset.id)).filter(Asset.status == "ONLINE").scalar() or 0
    new_assets_week = db.query(func.count(Asset.id)).filter(Asset.created_at >= week_start_dt).scalar() or 0
    high_risk       = db.query(func.count(Asset.id)).filter(Asset.risk_level == "高").scalar() or 0

    total_vulns     = db.query(func.count(Vulnerability.id)).scalar() or 0
    high_vulns      = db.query(func.count(Vulnerability.id)).filter(Vulnerability.severity == "高").scalar() or 0
    new_vulns_week  = db.query(func.count(Vulnerability.id)).filter(Vulnerability.discovered_at >= week_start_dt).scalar() or 0
    fixed_vulns     = db.query(func.count(Vulnerability.id)).filter(Vulnerability.status == "已修复").scalar() or 0
    tasks_week      = db.query(func.count(ScanTask.id)).filter(ScanTask.created_at >= week_start_dt).scalar() or 0

    # 漏洞类型分布
    type_stats = db.query(Vulnerability.vuln_type, func.count(Vulnerability.id).label("cnt"))\
        .group_by(Vulnerability.vuln_type).order_by(func.count(Vulnerability.id).desc()).all()

    type_rows = "".join(f'<tr><td>{r.vuln_type}</td><td style="font-weight:bold">{r.cnt}</td></tr>' for r in type_stats)
    type_section = f'''
    <div class="section">
      <h2>📊 漏洞类型分布</h2>
      <table><thead><tr><th>漏洞类型</th><th>数量</th></tr></thead>
      <tbody>{type_rows or "<tr><td colspan=2 style=text-align:center>暂无数据</td></tr>"}</tbody></table>
    </div>''' if type_stats else ""

    # 高危端口资产
    high_port_assets = []
    for a in db.query(Asset).filter(Asset.status == "ONLINE").all():
        ports = [p.strip() for p in (a.open_ports or "").split(",") if p.strip()]
        risky = [f"{p}({DANGEROUS_PORTS[p]})" for p in ports if p in DANGEROUS_PORTS]
        if risky:
            high_port_assets.append({"ip": a.ip_address, "risky_ports": risky})

    recent_vulns = db.query(Vulnerability).filter(Vulnerability.discovered_at >= week_start_dt)\
        .order_by(Vulnerability.discovered_at.desc()).limit(20).all()

    summary = {
        "date": today.strftime("%Y-%m-%d"),
        "week_start": week_start.strftime("%Y-%m-%d"),
        "week_end": today.strftime("%Y-%m-%d"),
        "total_assets": total_assets, "online_assets": online_assets,
        "new_assets_week": new_assets_week, "high_risk_assets": high_risk,
        "total_vulnerabilities": total_vulns, "high_vulnerabilities": high_vulns,
        "new_vulnerabilities_week": new_vulns_week, "fixed_vulnerabilities": fixed_vulns,
        "tasks_week": tasks_week,
        "vuln_type_stats": [{"type": r.vuln_type, "count": r.cnt} for r in type_stats],
        "high_risk_port_assets": high_port_assets,
        "recent_vulnerabilities": [
            {"ip": v.ip_address, "type": v.vuln_type, "title": v.title,
             "severity": v.severity,
             "description": v.description or "",
             "evidence": v.evidence or "",
             "time": v.discovered_at.strftime("%Y-%m-%d %H:%M") if v.discovered_at else ""}
            for v in recent_vulns
        ],
    }

    html_data = {
        "date": today.strftime("%Y-%m-%d"),
        "subtitle": f"统计周期：{week_start.strftime('%Y-%m-%d')} ~ {today.strftime('%Y-%m-%d')} | 本周扫描任务：{tasks_week}",
        "cards": [
            ("资产总数",    total_assets,    "info"),
            ("在线资产",    online_assets,   "success"),
            ("本周新增资产", new_assets_week, "info"),
            ("高危资产",    high_risk,       "danger"),
            ("漏洞总数",    total_vulns,     "warning"),
            ("高危漏洞",    high_vulns,      "danger"),
            ("本周新增漏洞", new_vulns_week, "warning"),
            ("本周已修复",  fixed_vulns,     "success"),
        ],
        "high_risk_port_assets": high_port_assets,
        "extra_sections": type_section,
        "recent_vulnerabilities": summary["recent_vulnerabilities"],
        "vuln_section_title": "本周漏洞",
    }
    return {"summary": summary, "html": _render_html(html_data, "周报")}


def generate_asset_comparison(db, days: int = 1) -> Dict:
    """资产变化对比分析"""
    from db.models import Asset
    cutoff = datetime.utcnow() - timedelta(days=days)

    all_assets = db.query(Asset).all()
    new_assets   = [a for a in all_assets if a.created_at and a.created_at >= cutoff]
    went_offline = [a for a in all_assets if a.status == "OFFLINE" and a.last_seen and a.last_seen >= cutoff]
    online       = [a for a in all_assets if a.status == "ONLINE"]

    high_port = []
    for a in online:
        ports = [p.strip() for p in (a.open_ports or "").split(",") if p.strip()]
        risky = [f"{p}({DANGEROUS_PORTS[p]})" for p in ports if p in DANGEROUS_PORTS]
        if risky:
            high_port.append({"ip": a.ip_address, "ports": risky})

    return {
        "period_days": days,
        "cutoff": cutoff.strftime("%Y-%m-%d %H:%M"),
        "total_online": len(online),
        "total_new": len(new_assets),
        "total_offline": len(went_offline),
        "new_assets": [
            {"ip": a.ip_address, "ports": a.open_ports or "—",
             "first_seen": a.first_seen.strftime("%Y-%m-%d %H:%M") if a.first_seen else ""}
            for a in new_assets
        ],
        "went_offline": [
            {"ip": a.ip_address,
             "last_seen": a.last_seen.strftime("%Y-%m-%d %H:%M") if a.last_seen else ""}
            for a in went_offline
        ],
        "high_risk_port_assets": high_port[:50],
    }
