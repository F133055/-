"""
漏洞扫描器 - core/vuln_scanner.py  v4.2
==================================
性能优化（v4.2）：
  - 修复根本原因：requests 的 timeout 参数不包含 DNS 解析时间！
    当目标是域名时（如 www.baidu.com），DNS 解析可能阻塞几分钟。
    → 通过 _resolve_host() 在独立线程中预解析域名（最多等1.5s），
      解析失败直接跳过，彻底消除 DNS 导致的卡死问题。
  - 全局禁用 urllib3 SSL 警告，避免每次 HTTPS 请求都打印警告
    （每条警告都会触发 I/O，严重拖慢并发扫描）
  - 使用线程本地 requests.Session，复用 TCP 连接池
  - Swagger 总超时从 8s 缩短到 6s
  - 所有检测使用 (connect, read) 元组超时，避免 read 阶段卡住
"""

import logging
import socket
import threading
import requests
import urllib3
from concurrent.futures import ThreadPoolExecutor, as_completed, TimeoutError as FuturesTimeout

# ── 全局禁用 SSL 不安全警告 ───────────────────────────────────
# 重要：不禁用的话每次 HTTPS 请求都会打印一行警告，在并发场景下
# 大量 I/O 会严重拖慢整体速度
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

logger = logging.getLogger(__name__)

# 全局超时：(connect_timeout, read_timeout)
TIMEOUT = (1, 2)
MAX_WORKERS = 16

# ── 线程本地 Session（每线程复用，减少握手开销）────────────────
_tls = threading.local()

def _session() -> requests.Session:
    if not hasattr(_tls, 's'):
        s = requests.Session()
        s.verify = False
        s.max_redirects = 3
        a = requests.adapters.HTTPAdapter(
            pool_connections=8, pool_maxsize=16, max_retries=0)
        s.mount('http://', a)
        s.mount('https://', a)
        _tls.s = s
    return _tls.s


def _resolve_host(host: str, timeout: float = 1.5) -> str | None:
    """
    带超时的 DNS 预解析 —— 修复 requests timeout 不含 DNS 的核心问题。

    requests.get(url, timeout=N) 的 timeout 只控制 connect/read，
    不包含 DNS 解析。如果 DNS 慢（或域名不可达），会阻塞几分钟。
    本函数在独立线程中解析，超时立即返回 None，调用方跳过该目标。
    """
    # 已经是 IPv4 地址，无需解析
    try:
        socket.inet_aton(host)
        return host
    except socket.error:
        pass
    # 域名解析（独立线程 + join 超时）
    result = [None]
    def _do():
        try:
            infos = socket.getaddrinfo(host, None, socket.AF_INET)
            if infos:
                result[0] = infos[0][4][0]
        except Exception:
            pass
    t = threading.Thread(target=_do, daemon=True)
    t.start()
    t.join(timeout)
    if t.is_alive():
        logger.debug(f"[DNS] {host} 解析超时({timeout}s)，跳过")
        return None
    if not result[0]:
        logger.debug(f"[DNS] {host} 解析失败，跳过")
        return None
    return result[0]


def _get(url: str, timeout=TIMEOUT, **kwargs) -> requests.Response | None:
    """线程安全 GET，异常返回 None"""
    try:
        return _session().get(url, timeout=timeout, allow_redirects=True, **kwargs)
    except Exception as e:
        logger.debug(f"GET {url} → {type(e).__name__}: {e}")
        return None


def _tcp_connect(ip: str, port: int, timeout: float = 0.8) -> bool:
    try:
        with socket.create_connection((ip, port), timeout=timeout):
            return True
    except Exception:
        return False


# ─────────────────────────────────────────────────────────────
# Nacos 未授权访问
# ─────────────────────────────────────────────────────────────
def check_nacos_vuln(ip: str, port: int = None) -> bool:
    if not _resolve_host(ip):
        return False
    ports = [port] if port else [8848, 9848]
    for p in ports:
        if not _tcp_connect(ip, p):
            continue
        for url in [
            f"http://{ip}:{p}/nacos/v1/auth/users?pageNo=1&pageSize=9",
            f"http://{ip}:{p}/nacos/v1/auth/users",
        ]:
            r = _get(url)
            if r and r.status_code == 200:
                text = r.text.lower()
                if any(k in text for k in ["user", "pageitems", "totalcount"]):
                    logger.warning(f"[Nacos] 未授权访问: {url}")
                    return True
    return False


# ─────────────────────────────────────────────────────────────
# Swagger UI 暴露
# ─────────────────────────────────────────────────────────────
SWAGGER_PATHS = [
    "/swagger-ui.html", "/swagger-ui/index.html",
    "/v2/api-docs", "/v3/api-docs", "/api/docs",
    "/swagger/index.html", "/swagger/v1/swagger.json",
    "/openapi.json", "/api/swagger-ui.html",
]
SWAGGER_KEYWORDS = ["swagger", "openapi", "swaggerui", "api-docs", "\"swagger\""]
SWAGGER_PORTS    = [80, 8080, 8000, 8443, 443, 8888, 9090, 3000]


def _check_swagger_url(url: str) -> str | None:
    r = _get(url, timeout=(1, 1))
    if not r or r.status_code != 200:
        return None
    body = r.text.lower()
    ct   = r.headers.get("content-type", "").lower()
    if any(kw in body for kw in SWAGGER_KEYWORDS) or (
        "application/json" in ct and ("swagger" in body or "openapi" in body)
    ):
        return url
    return None


def check_swagger_vuln(ip: str, port: int = None) -> dict:
    """
    并发检测 Swagger/OpenAPI 暴露。
    v4.2 关键修复：先做 DNS 预解析（1.5s 超时），失败立即返回。
    """
    # DNS 预解析，失败直接跳过（这是之前 5-6 分钟卡死的根本原因）
    resolved = _resolve_host(ip, timeout=1.5)
    if not resolved:
        return {"found": False, "url": ""}

    check_ports = [port] if port else SWAGGER_PORTS

    # 并发 TCP 预检（用解析后的 IP，更快）
    with ThreadPoolExecutor(max_workers=len(check_ports)) as ex:
        tcp_futs = {ex.submit(_tcp_connect, resolved, p, 0.5): p for p in check_ports}
        open_ports = []
        try:
            for fut in as_completed(tcp_futs, timeout=1.5):
                p = tcp_futs[fut]
                try:
                    if fut.result(timeout=0.3):
                        open_ports.append(p)
                except Exception:
                    pass
        except FuturesTimeout:
            pass

    if not open_ports:
        logger.debug(f"[Swagger] {ip}: 所有端口不可达")
        return {"found": False, "url": ""}

    # 构造 URL（用原始 ip/域名，Host 头正确）
    candidates = []
    for p in open_ports:
        scheme = "https" if p in (443, 8443) else "http"
        for path in SWAGGER_PATHS:
            candidates.append(f"{scheme}://{ip}:{p}{path}")

    # 并发 HTTP 检测，6s 总超时，发现即返回
    with ThreadPoolExecutor(max_workers=min(MAX_WORKERS, len(candidates))) as executor:
        futures = {executor.submit(_check_swagger_url, url): url for url in candidates}
        try:
            for fut in as_completed(futures, timeout=6):
                try:
                    result = fut.result(timeout=0.3)
                    if result:
                        logger.warning(f"[Swagger] 文档暴露: {result}")
                        for f in futures:
                            f.cancel()
                        return {"found": True, "url": result}
                except Exception:
                    pass
        except FuturesTimeout:
            logger.debug(f"[Swagger] {ip}: 并发检测超时(6s)")

    return {"found": False, "url": ""}


def check_swagger_bool(ip: str, port: int = None) -> bool:
    return check_swagger_vuln(ip, port)["found"]


# ─────────────────────────────────────────────────────────────
# MinIO 未授权访问
# ─────────────────────────────────────────────────────────────
MINIO_PORTS = [9000, 9001]


def check_minio_vuln(ip: str, port: int = None) -> bool:
    if not _resolve_host(ip):
        return False
    for p in ([port] if port else MINIO_PORTS):
        if not _tcp_connect(ip, p):
            continue
        for path in ["/minio/health/live", "/health/live", "/"]:
            url = f"http://{ip}:{p}{path}"
            r   = _get(url)
            if r and r.status_code in (200, 403):
                body = r.text.lower()
                hdrs = str(r.headers).lower()
                if "minio" in body or "minio" in hdrs or "x-minio" in hdrs:
                    logger.warning(f"[MinIO] 服务暴露: {url}")
                    return True
    return False


# ─────────────────────────────────────────────────────────────
# Spring Boot Actuator
# ─────────────────────────────────────────────────────────────
ACTUATOR_DANGEROUS = ["/actuator/env", "/actuator/heapdump",
                      "/actuator/mappings", "/actuator/beans", "/actuator/configprops"]
ACTUATOR_PORTS     = [8080, 8000, 8888, 9090, 80, 443, 8443]


def check_actuator_vuln(ip: str, port: int = None) -> dict:
    if not _resolve_host(ip):
        return {"found": False, "endpoints": []}
    found = []
    for p in ([port] if port else ACTUATOR_PORTS):
        if not _tcp_connect(ip, p, 0.8):
            continue
        scheme = "https" if p in (443, 8443) else "http"
        r = _get(f"{scheme}://{ip}:{p}/actuator")
        if not r or r.status_code not in (200, 401):
            continue
        for path in ACTUATOR_DANGEROUS:
            url = f"{scheme}://{ip}:{p}{path}"
            r2  = _get(url)
            if r2 and r2.status_code == 200:
                ct = r2.headers.get("content-type", "")
                if "json" in ct or len(r2.content) > 100:
                    found.append(url)
                    logger.warning(f"[Actuator] 高危端点暴露: {url}")
    return {"found": len(found) > 0, "endpoints": found}


def check_actuator_bool(ip: str, port: int = None) -> bool:
    return check_actuator_vuln(ip, port)["found"]


# ─────────────────────────────────────────────────────────────
# Druid 监控页
# ─────────────────────────────────────────────────────────────
DRUID_PORTS = [8080, 8000, 9090, 80]


def check_druid_vuln(ip: str, port: int = None) -> bool:
    if not _resolve_host(ip):
        return False
    for p in ([port] if port else DRUID_PORTS):
        if not _tcp_connect(ip, p, 0.8):
            continue
        scheme = "https" if p in (443, 8443) else "http"
        for path in ["/druid/index.html", "/druid/", "/druid/login.html"]:
            url = f"{scheme}://{ip}:{p}{path}"
            r   = _get(url)
            if r and r.status_code == 200:
                body = r.text.lower()
                if "druid" in body and any(k in body for k in ["monitor", "sql", "wall"]):
                    logger.warning(f"[Druid] 监控页暴露: {url}")
                    return True
    return False


# ─────────────────────────────────────────────────────────────
# Redis 未授权访问
# ─────────────────────────────────────────────────────────────
def check_redis_unauth(ip: str, port: int = None) -> bool:
    if not _resolve_host(ip):
        return False
    for p in ([port] if port else [6379, 6380, 6381]):
        if not _tcp_connect(ip, p, 1.0):
            continue
        try:
            with socket.create_connection((ip, p), timeout=3) as sock:
                sock.sendall(b"PING\r\n")
                resp = sock.recv(64).decode("utf-8", errors="ignore")
                if "+PONG" in resp:
                    logger.warning(f"[Redis] 未授权访问: {ip}:{p}")
                    return True
        except Exception:
            pass
    return False


# ─────────────────────────────────────────────────────────────
# Docker Remote API
# ─────────────────────────────────────────────────────────────
DOCKER_PORTS = [2375, 2376, 2377]


def check_docker_vuln(ip: str, port: int = None) -> bool:
    if not _resolve_host(ip):
        return False
    for p in ([port] if port else DOCKER_PORTS):
        if not _tcp_connect(ip, p, 1.0):
            continue
        url = f"http://{ip}:{p}/version"
        r   = _get(url)
        if r and r.status_code == 200:
            body = r.text.lower()
            if any(k in body for k in ["apiversion", "dockerversion", "docker"]):
                logger.warning(f"[Docker] Remote API 未授权: {url}")
                return True
    return False


# ─────────────────────────────────────────────────────────────
# 统一入口
# ─────────────────────────────────────────────────────────────
VULN_CHECKERS = {
    "nacos":        (check_nacos_vuln,    "Nacos 未授权访问",        "高",   "Nacos /nacos/v1/auth/users 接口可未授权访问"),
    "swagger":      (check_swagger_bool,  "Swagger 文档暴露",         "中",   "Swagger/OpenAPI 文档对外暴露，可能泄露接口信息"),
    "minio":        (check_minio_vuln,    "MinIO 未授权访问",         "高",   "MinIO 对象存储服务未授权可访问"),
    "actuator":     (check_actuator_bool, "Spring Actuator 端点暴露", "高",   "Spring Boot Actuator 高危端点未授权访问"),
    "druid":        (check_druid_vuln,    "Druid 监控页暴露",         "中",   "Druid 监控页面未授权可访问"),
    "redis_unauth": (check_redis_unauth,  "Redis 未授权访问",         "高",   "Redis 服务无密码保护，可直接连接"),
    "docker":       (check_docker_vuln,   "Docker API 未授权",        "严重", "Docker Remote API 未授权，可控制宿主机容器"),
}


def check_vuln(ip: str, vuln_type: str, port: int = None) -> dict:
    if vuln_type not in VULN_CHECKERS:
        return {"ip": ip, "vuln_type": vuln_type, "is_vuln": False,
                "title": "未知类型", "severity": "",
                "description": f"不支持的漏洞类型: {vuln_type}"}
    checker_fn, title, severity, description = VULN_CHECKERS[vuln_type]
    try:
        try:
            is_vuln = checker_fn(ip, port=port) if port else checker_fn(ip)
        except TypeError:
            is_vuln = checker_fn(ip)
        return {"ip": ip, "vuln_type": vuln_type, "is_vuln": is_vuln,
                "title": title, "severity": severity, "description": description}
    except Exception as e:
        logger.error(f"[{vuln_type}] 检测 {ip} 异常: {e}", exc_info=True)
        return {"ip": ip, "vuln_type": vuln_type, "is_vuln": False,
                "title": title, "severity": severity,
                "description": description, "error": str(e)}


def get_supported_types() -> list:
    return [{"type": k, "title": v[1], "severity": v[2]} for k, v in VULN_CHECKERS.items()]
