"""
威胁情报集成模块 - SecPlatform v4.1
=====================================
功能：
  1. 查询 NVD (NIST) CVE 数据库获取漏洞情报
  2. 根据资产开放服务关键字自动关联 CVE
  3. 离线常见高危 CVE 列表（网络不通时兜底使用）
  4. 支持手动输入 CVE 查询
"""

import logging
import time
import requests
from typing import Optional

logger = logging.getLogger(__name__)

# ── 离线常见高危 CVE 列表（兜底，不依赖网络）────────────────────
OFFLINE_CVE_DB = [
    {
        "cve_id": "CVE-2021-44228",
        "title": "Apache Log4j2 远程代码执行（Log4Shell）",
        "cvss_score": 10.0,
        "severity": "高",
        "description": "Apache Log4j2 存在 JNDI 注入漏洞，攻击者可通过构造特殊请求实现远程代码执行。",
        "published_at": "2021-12-10",
        "keywords": ["java", "log4j", "tomcat", "spring", "elasticsearch", "8983", "9200"],
    },
    {
        "cve_id": "CVE-2022-22965",
        "title": "Spring Framework 远程代码执行（Spring4Shell）",
        "cvss_score": 9.8,
        "severity": "高",
        "description": "Spring MVC 或 Spring WebFlux 应用在 JDK9+ 环境下存在 RCE 漏洞。",
        "published_at": "2022-04-01",
        "keywords": ["spring", "8080", "8443", "tomcat"],
    },
    {
        "cve_id": "CVE-2021-26084",
        "title": "Confluence Server OGNL 注入远程代码执行",
        "cvss_score": 9.8,
        "severity": "高",
        "description": "Atlassian Confluence Server/Data Center 存在 OGNL 注入，可未授权 RCE。",
        "published_at": "2021-08-25",
        "keywords": ["confluence", "8090", "8091"],
    },
    {
        "cve_id": "CVE-2022-1388",
        "title": "F5 BIG-IP iControl REST 未授权 RCE",
        "cvss_score": 9.8,
        "severity": "高",
        "description": "F5 BIG-IP 管理接口存在身份验证绕过，可导致 RCE。",
        "published_at": "2022-05-04",
        "keywords": ["bigip", "f5", "443", "icontrol"],
    },
    {
        "cve_id": "CVE-2021-21985",
        "title": "VMware vCenter Server 远程代码执行",
        "cvss_score": 9.8,
        "severity": "高",
        "description": "VMware vCenter Server 插件端点存在 RCE 漏洞，无需身份验证。",
        "published_at": "2021-05-25",
        "keywords": ["vcenter", "vsphere", "443", "9443"],
    },
    {
        "cve_id": "CVE-2020-1472",
        "title": "Netlogon 权限提升（ZeroLogon）",
        "cvss_score": 10.0,
        "severity": "高",
        "description": "Windows Netlogon 协议实现缺陷，攻击者可重置域控密码，完全控制域。",
        "published_at": "2020-08-11",
        "keywords": ["445", "139", "smb", "windows", "域控"],
    },
    {
        "cve_id": "CVE-2019-0708",
        "title": "Windows 远程桌面服务 RCE（BlueKeep）",
        "cvss_score": 9.8,
        "severity": "高",
        "description": "Windows RDP 服务预身份验证 RCE 漏洞，可蠕虫式传播。",
        "published_at": "2019-05-14",
        "keywords": ["3389", "rdp", "windows"],
    },
    {
        "cve_id": "CVE-2021-22205",
        "title": "GitLab CE/EE 远程代码执行",
        "cvss_score": 10.0,
        "severity": "高",
        "description": "GitLab 文件上传接口存在 RCE 漏洞，无需身份验证即可利用。",
        "published_at": "2021-04-14",
        "keywords": ["gitlab", "80", "443", "8080"],
    },
    {
        "cve_id": "CVE-2022-42889",
        "title": "Apache Commons Text RCE（Text4Shell）",
        "cvss_score": 9.8,
        "severity": "高",
        "description": "Apache Commons Text 存在变量插值 RCE 漏洞，类似 Log4Shell。",
        "published_at": "2022-10-13",
        "keywords": ["java", "spring", "8080"],
    },
    {
        "cve_id": "CVE-2023-44487",
        "title": "HTTP/2 Rapid Reset 拒绝服务攻击",
        "cvss_score": 7.5,
        "severity": "中",
        "description": "HTTP/2 协议实现缺陷，可触发大规模 DDoS（Rapid Reset 攻击）。",
        "published_at": "2023-10-10",
        "keywords": ["443", "80", "nginx", "apache", "http2"],
    },
    {
        "cve_id": "CVE-2024-3094",
        "title": "XZ Utils 后门（供应链攻击）",
        "cvss_score": 10.0,
        "severity": "高",
        "description": "XZ Utils 5.6.0/5.6.1 包含恶意后门，影响 SSH 守护进程。",
        "published_at": "2024-03-29",
        "keywords": ["22", "ssh", "linux"],
    },
    {
        "cve_id": "CVE-2023-46604",
        "title": "Apache ActiveMQ 远程代码执行",
        "cvss_score": 10.0,
        "severity": "高",
        "description": "Apache ActiveMQ 5.x 存在 ClassInfo OpenWire 反序列化 RCE。",
        "published_at": "2023-10-27",
        "keywords": ["61616", "activemq", "8161"],
    },
    {
        "cve_id": "CVE-2023-20198",
        "title": "Cisco IOS XE Web UI 权限提升",
        "cvss_score": 10.0,
        "severity": "高",
        "description": "Cisco IOS XE Web 管理界面存在 0day，可创建高权限账户。",
        "published_at": "2023-10-16",
        "keywords": ["443", "80", "cisco"],
    },
    {
        "cve_id": "CVE-2021-34527",
        "title": "Windows Print Spooler RCE（PrintNightmare）",
        "cvss_score": 8.8,
        "severity": "高",
        "description": "Windows 打印后台程序存在 RCE 漏洞，可实现权限提升与远程代码执行。",
        "published_at": "2021-07-01",
        "keywords": ["445", "139", "windows", "135"],
    },
    {
        "cve_id": "CVE-2022-26134",
        "title": "Atlassian Confluence OGNL 注入 RCE",
        "cvss_score": 9.8,
        "severity": "高",
        "description": "Confluence Server 和 Data Center 存在 OGNL 注入，可实现未授权 RCE。",
        "published_at": "2022-06-02",
        "keywords": ["confluence", "8090", "8091", "443"],
    },
    {
        "cve_id": "CVE-2017-0144",
        "title": "Windows SMB 远程代码执行（EternalBlue）",
        "cvss_score": 9.3,
        "severity": "高",
        "description": "SMBv1 实现缺陷，被 WannaCry/NotPetya 等勒索软件广泛利用。",
        "published_at": "2017-03-14",
        "keywords": ["445", "smb", "windows"],
    },
]

# 服务特征关键字 → 可能关联的 CVE 列表
SERVICE_CVE_MAP: dict[str, list[str]] = {
    "6379":  ["redis 未授权访问"],
    "27017": ["mongodb 未授权访问"],
    "9200":  ["CVE-2021-44228", "elasticsearch 未授权"],
    "8983":  ["CVE-2021-44228", "solr rce"],
    "8848":  ["CVE-2021-29441"],  # nacos
    "3389":  ["CVE-2019-0708", "CVE-2021-34527"],
    "445":   ["CVE-2017-0144", "CVE-2020-1472", "CVE-2021-34527"],
    "22":    ["CVE-2024-3094"],
    "61616": ["CVE-2023-46604"],
    "8161":  ["CVE-2023-46604"],
    "8090":  ["CVE-2021-26084", "CVE-2022-26134"],
    "8080":  ["CVE-2022-22965", "CVE-2022-42889"],
}

NVD_API_URL = "https://services.nvd.nist.gov/rest/json/cves/2.0"
REQUEST_TIMEOUT = 10


# ── 公开 API ──────────────────────────────────────────────────

def query_cve_online(cve_id: str) -> Optional[dict]:
    """
    在线查询 NVD API 获取 CVE 详情。
    返回标准化 dict，失败时返回 None。
    """
    try:
        resp = requests.get(
            NVD_API_URL,
            params={"cveId": cve_id},
            timeout=REQUEST_TIMEOUT,
            headers={"User-Agent": "SecPlatform/4.1"}
        )
        if resp.status_code != 200:
            logger.warning(f"NVD API 返回 {resp.status_code} for {cve_id}")
            return None
        data = resp.json()
        vulns = data.get("vulnerabilities", [])
        if not vulns:
            return None
        item = vulns[0].get("cve", {})
        return _parse_nvd_item(item)
    except Exception as e:
        logger.warning(f"NVD 在线查询失败 {cve_id}: {e}")
        return None


def query_cve_offline(cve_id: str) -> Optional[dict]:
    """在离线 CVE 库中查找"""
    cve_id = cve_id.upper().strip()
    for item in OFFLINE_CVE_DB:
        if item["cve_id"] == cve_id:
            return {
                "cve_id": item["cve_id"],
                "title": item["title"],
                "cvss_score": item["cvss_score"],
                "severity": item["severity"],
                "description": item["description"],
                "published_at": item["published_at"],
                "source": "offline_db",
            }
    return None


def query_cve(cve_id: str) -> dict:
    """
    查询 CVE 详情：先尝试在线，失败后使用离线库。
    """
    result = query_cve_online(cve_id)
    if result:
        result["source"] = "nvd_online"
        return result
    result = query_cve_offline(cve_id)
    if result:
        return result
    return {
        "cve_id": cve_id,
        "title": f"{cve_id}（未找到详情）",
        "cvss_score": None,
        "severity": "未知",
        "description": "未能从在线/离线库获取该 CVE 详情。",
        "published_at": None,
        "source": "not_found",
    }


def correlate_asset_cve(ip: str, open_ports: str, services: str = None) -> list[dict]:
    """
    根据资产开放端口和服务信息，关联可能存在的 CVE 情报。
    返回命中的 CVE 列表（来自离线库）。
    """
    ports = set(p.strip() for p in (open_ports or "").split(",") if p.strip())
    services_lower = (services or "").lower()
    matched = []
    seen_cve = set()

    for item in OFFLINE_CVE_DB:
        for kw in item.get("keywords", []):
            hit = False
            # 端口匹配
            if kw in ports:
                hit = True
            # 服务信息文本匹配
            elif kw.lower() in services_lower:
                hit = True
            if hit and item["cve_id"] not in seen_cve:
                seen_cve.add(item["cve_id"])
                matched.append({
                    "cve_id": item["cve_id"],
                    "title": item["title"],
                    "cvss_score": item["cvss_score"],
                    "severity": item["severity"],
                    "description": item["description"],
                    "published_at": item["published_at"],
                    "matched_by": kw,
                    "source": "offline_db",
                })
                break

    # 按 CVSS 分数降序
    matched.sort(key=lambda x: x.get("cvss_score") or 0, reverse=True)
    return matched


def batch_correlate_assets(db_assets: list) -> dict[str, list]:
    """
    批量处理资产列表，返回 {ip: [cve_list]} 映射。
    db_assets: Asset ORM 对象列表
    """
    result = {}
    for asset in db_assets:
        cves = correlate_asset_cve(
            ip=asset.ip_address,
            open_ports=asset.open_ports or "",
            services=asset.services or "",
        )
        if cves:
            result[asset.ip_address] = cves
    return result


# ── 私有辅助 ──────────────────────────────────────────────────

def _parse_nvd_item(item: dict) -> dict:
    """解析 NVD API v2 返回的 CVE 条目"""
    cve_id = item.get("id", "")
    descriptions = item.get("descriptions", [])
    desc_en = next((d["value"] for d in descriptions if d.get("lang") == "en"), "")
    desc_zh = next((d["value"] for d in descriptions if d.get("lang") == "zh"), "")

    published = item.get("published", "")[:10]

    # CVSS v3.1 → v3.0 → v2
    cvss_score, severity = None, "未知"
    metrics = item.get("metrics", {})
    for key in ("cvssMetricV31", "cvssMetricV30", "cvssMetricV2"):
        m = metrics.get(key, [])
        if m:
            cvss_data = m[0].get("cvssData", {})
            cvss_score = cvss_data.get("baseScore")
            severity = m[0].get("baseSeverity") or cvss_data.get("baseSeverity", "未知")
            break

    # 映射英文等级到中文
    severity_map = {"CRITICAL": "严重", "HIGH": "高", "MEDIUM": "中", "LOW": "低", "NONE": "无"}
    severity = severity_map.get(severity.upper(), severity)

    return {
        "cve_id": cve_id,
        "title": desc_en[:200] if desc_en else cve_id,
        "cvss_score": cvss_score,
        "severity": severity,
        "description": desc_zh or desc_en,
        "published_at": published,
    }
