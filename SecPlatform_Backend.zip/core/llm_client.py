"""
LLM 客户端 — 支持 OpenAI 兼容接口（OpenAI / Anthropic / Ollama / 本地部署）
通过系统设置动态配置 API 地址和密钥，无需重启服务。
"""
import logging
import json
from typing import Optional

logger = logging.getLogger(__name__)


def _get_llm_config(db=None) -> dict:
    """从数据库或环境变量读取 LLM 配置"""
    from core.config import settings

    cfg = {
        "api_url":  getattr(settings, "LLM_API_URL",  None) or "https://api.openai.com/v1",
        "api_key":  getattr(settings, "LLM_API_KEY",  None) or "",
        "model":    getattr(settings, "LLM_MODEL",    None) or "gpt-4o-mini",
        "enabled":  False,
    }
    # If key configured, mark as enabled
    if cfg["api_key"] and len(cfg["api_key"]) > 8:
        cfg["enabled"] = True

    # Override from DB settings table if available
    if db:
        try:
            from db.models import AppSetting
            rows = db.query(AppSetting).filter(
                AppSetting.key.in_(["llm_api_url", "llm_api_key", "llm_model"])
            ).all()
            for row in rows:
                if row.key == "llm_api_url" and row.value:
                    cfg["api_url"] = row.value
                elif row.key == "llm_api_key" and row.value:
                    cfg["api_key"] = row.value
                    cfg["enabled"] = len(row.value) > 8
                elif row.key == "llm_model" and row.value:
                    cfg["model"] = row.value
        except Exception:
            pass

    return cfg


def call_llm(prompt: str, system: str = "", db=None, max_tokens: int = 1200,
             temperature: float = 0.3) -> Optional[str]:
    """
    调用 LLM 生成回复（同步版本，适用于 FastAPI 非 async 上下文）
    返回生成文本，失败时返回 None
    """
    import requests

    cfg = _get_llm_config(db)
    if not cfg["enabled"]:
        return None

    messages = []
    if system:
        messages.append({"role": "system", "content": system})
    messages.append({"role": "user", "content": prompt})

    url = cfg["api_url"].rstrip("/") + "/chat/completions"
    headers = {
        "Authorization": f"Bearer {cfg['api_key']}",
        "Content-Type":  "application/json",
    }
    payload = {
        "model":       cfg["model"],
        "messages":    messages,
        "max_tokens":  max_tokens,
        "temperature": temperature,
    }

    try:
        resp = requests.post(url, headers=headers, json=payload, timeout=60)
        resp.raise_for_status()
        data = resp.json()
        return data["choices"][0]["message"]["content"].strip()
    except requests.exceptions.ConnectionError:
        logger.error(f"LLM 连接失败: 无法连接到 {url}")
        return None
    except requests.exceptions.Timeout:
        logger.error("LLM 请求超时 (60s)")
        return None
    except Exception as e:
        logger.error(f"LLM 调用失败: {e}")
        return None


async def call_llm_async(prompt: str, system: str = "", db=None,
                          max_tokens: int = 1200) -> Optional[str]:
    """异步版本 LLM 调用"""
    import httpx

    cfg = _get_llm_config(db)
    if not cfg["enabled"]:
        return None

    messages = []
    if system:
        messages.append({"role": "system", "content": system})
    messages.append({"role": "user", "content": prompt})

    url = cfg["api_url"].rstrip("/") + "/chat/completions"
    headers = {
        "Authorization": f"Bearer {cfg['api_key']}",
        "Content-Type":  "application/json",
    }
    payload = {
        "model":       cfg["model"],
        "messages":    messages,
        "max_tokens":  max_tokens,
        "temperature": 0.3,
    }

    try:
        async with httpx.AsyncClient(timeout=60) as client:
            resp = await client.post(url, headers=headers, json=payload)
            resp.raise_for_status()
            data = resp.json()
            return data["choices"][0]["message"]["content"].strip()
    except Exception as e:
        logger.error(f"LLM 异步调用失败: {e}")
        return None


def is_llm_configured(db=None) -> bool:
    """检查 LLM 是否已配置"""
    return _get_llm_config(db)["enabled"]
