"""
GitHub / Gitee 信息泄露扫描模块 - SecPlatform v4.1
====================================================
功能：
  1. 通过 GitHub Search API 搜索关键字，检测敏感信息
  2. 支持 Gitee Search API（需配置 Token）
  3. 内置常见泄露模式（API Key、Token、密码等）
  4. 支持自定义关键字搜索

配置说明（.env 中添加）：
  GITHUB_TOKEN=ghp_xxxxxxxxxxxx    # GitHub Personal Access Token
  GITEE_TOKEN=xxxxxxxx             # Gitee 私人令牌（可选）
"""

import re
import logging
import time
import requests
from typing import Optional

logger = logging.getLogger(__name__)

# ── 敏感信息正则模式 ──────────────────────────────────────────
LEAK_PATTERNS = [
    # API Keys / Tokens
    (r'(?i)(api[_\-]?key|apikey)\s*[=:]\s*["\']?([A-Za-z0-9\-_]{20,})',        "api_key"),
    (r'(?i)(secret[_\-]?key|secretkey)\s*[=:]\s*["\']?([A-Za-z0-9\-_]{20,})',  "secret_key"),
    (r'(?i)(access[_\-]?token|accesstoken)\s*[=:]\s*["\']?([A-Za-z0-9\-_.]{20,})', "access_token"),
    (r'(?i)(bearer\s+)([A-Za-z0-9\-_.]{20,})',                                  "bearer_token"),

    # 数据库连接字符串
    (r'(?i)(mysql|postgresql|postgres|mongodb|redis)://[^@\s]+:[^@\s]+@[^\s"\']+', "db_connection"),
    (r'(?i)(db[_\-]?password|database[_\-]?password)\s*[=:]\s*["\']?([^\s"\']{6,})', "db_password"),

    # 云服务 Key
    (r'AKIA[0-9A-Z]{16}',                         "aws_access_key"),
    (r'(?i)(aws[_\-]?secret)\s*[=:]\s*["\']?([A-Za-z0-9/+=]{40})',  "aws_secret"),
    (r'AIza[0-9A-Za-z\-_]{35}',                   "google_api_key"),
    (r'(?i)(aliyun|alicloud|oss)[_\-]?(access[_\-]?key[_\-]?id)?\s*[=:]\s*["\']?([A-Za-z0-9]{20,})', "aliyun_key"),

    # 密码
    (r'(?i)(password|passwd|pwd)\s*[=:]\s*["\']?([^\s"\'<>]{6,32})', "password"),
    (r'(?i)(private[_\-]?key)\s*[=:]\s*["\']?([A-Za-z0-9\-_+=]{20,})', "private_key"),

    # JWT
    (r'eyJ[A-Za-z0-9\-_]+\.eyJ[A-Za-z0-9\-_]+\.[A-Za-z0-9\-_]+', "jwt_token"),

    # 内网 IP 地址
    (r'(?:jdbc|mysql|redis|mongodb)://(?:10\.|172\.(?:1[6-9]|2\d|3[01])\.|192\.168\.)\d+\.\d+', "intranet_url"),
]

# 搜索关键字模板（通过公司域名/关键字扩展）
SEARCH_QUERY_TEMPLATES = [
    '"{keyword}" password',
    '"{keyword}" secret',
    '"{keyword}" api_key',
    '"{keyword}" access_token',
    '"{keyword}" db_password',
    '"{keyword}" connection_string',
    '"{keyword}" private_key',
    'filename:.env "{keyword}"',
    'filename:config.py "{keyword}"',
    'filename:application.yml "{keyword}"',
    'filename:application.properties "{keyword}"',
    'filename:.git-credentials "{keyword}"',
]

GITHUB_SEARCH_URL = "https://api.github.com/search/code"
GITEE_SEARCH_URL  = "https://gitee.com/api/v5/search/repositories"
REQUEST_TIMEOUT   = 15


# ── 公开 API ──────────────────────────────────────────────────

def scan_github(keyword: str, github_token: str, max_results: int = 30) -> list[dict]:
    """
    搜索 GitHub 上包含关键字的代码，检测敏感信息泄露。
    返回发现列表，每项包含 repo、file、leak_type、matched_text。
    """
    if not github_token:
        logger.warning("GITHUB_TOKEN 未配置，跳过 GitHub 扫描")
        return [{"error": "GITHUB_TOKEN 未配置，请在 .env 中添加 GITHUB_TOKEN=ghp_xxxx"}]

    headers = {
        "Authorization": f"token {github_token}",
        "Accept": "application/vnd.github.v3+json",
        "User-Agent": "SecPlatform/4.1",
    }
    results = []
    queries_run = 0

    for tmpl in SEARCH_QUERY_TEMPLATES[:5]:   # 限制查询数量避免 API 限流
        query = tmpl.format(keyword=keyword)
        try:
            resp = requests.get(
                GITHUB_SEARCH_URL,
                params={"q": query, "per_page": max(5, max_results // 5)},
                headers=headers,
                timeout=REQUEST_TIMEOUT,
            )
            queries_run += 1

            if resp.status_code == 403:
                remaining = resp.headers.get("X-RateLimit-Remaining", "?")
                logger.warning(f"GitHub API Rate Limit 触发，剩余配额: {remaining}")
                results.append({
                    "error": f"GitHub API Rate Limit 触发，剩余配额: {remaining}，请稍后重试或更换 Token"
                })
                break

            if resp.status_code == 422:
                logger.debug(f"GitHub 搜索语法不支持: {query}")
                continue

            if resp.status_code != 200:
                logger.warning(f"GitHub 搜索失败 {resp.status_code}: {query}")
                continue

            data = resp.json()
            items = data.get("items", [])
            logger.info(f"GitHub 搜索 '{query}' 返回 {len(items)} 条")

            for item in items[:max_results]:
                repo = item.get("repository", {})
                file_path = item.get("path", "")
                html_url = item.get("html_url", "")

                # 尝试下载文件内容进行正则匹配
                raw_content = _fetch_raw_content(item, headers)
                detected = _scan_content(raw_content) if raw_content else []

                if detected:
                    for d in detected:
                        results.append({
                            "platform": "github",
                            "repo_name": repo.get("full_name", ""),
                            "repo_url": repo.get("html_url", ""),
                            "file_path": file_path,
                            "file_url": html_url,
                            "leak_type": d["leak_type"],
                            "matched_text": d["matched_text"],
                            "severity": "高",
                        })
                else:
                    # 无法读取内容，但文件名/路径本身就可疑
                    if _is_suspicious_path(file_path):
                        results.append({
                            "platform": "github",
                            "repo_name": repo.get("full_name", ""),
                            "repo_url": repo.get("html_url", ""),
                            "file_path": file_path,
                            "file_url": html_url,
                            "leak_type": "suspicious_file",
                            "matched_text": f"可疑文件路径: {file_path}",
                            "severity": "中",
                        })

                if len(results) >= max_results:
                    break

            # GitHub Search API 限流：每次请求后短暂等待
            time.sleep(1.5)

        except requests.exceptions.Timeout:
            logger.warning(f"GitHub 搜索超时: {query}")
        except Exception as e:
            logger.error(f"GitHub 搜索异常 '{query}': {e}")

        if len(results) >= max_results:
            break

    # 去重（同 repo + 同文件 + 同 leak_type）
    seen = set()
    unique = []
    for r in results:
        if "error" in r:
            unique.append(r)
            continue
        key = (r.get("repo_name"), r.get("file_path"), r.get("leak_type"))
        if key not in seen:
            seen.add(key)
            unique.append(r)

    logger.info(f"GitHub 扫描完成，关键字 '{keyword}'，发现 {len(unique)} 条（去重后）")
    return unique


def scan_gitee(keyword: str, gitee_token: str, max_results: int = 20) -> list[dict]:
    """
    搜索 Gitee 仓库（注意：Gitee 不支持代码搜索，只能搜索仓库名/描述）
    """
    if not gitee_token:
        return [{"error": "GITEE_TOKEN 未配置，请在 .env 中添加 GITEE_TOKEN=xxxx"}]
    try:
        resp = requests.get(
            GITEE_SEARCH_URL,
            params={
                "access_token": gitee_token,
                "q": keyword,
                "per_page": max_results,
            },
            timeout=REQUEST_TIMEOUT,
        )
        if resp.status_code != 200:
            return [{"error": f"Gitee API 返回 {resp.status_code}"}]

        repos = resp.json() if isinstance(resp.json(), list) else resp.json().get("data", [])
        results = []
        for repo in repos[:max_results]:
            results.append({
                "platform": "gitee",
                "repo_name": repo.get("full_name", ""),
                "repo_url": repo.get("html_url", ""),
                "file_path": "",
                "leak_type": "repo_exposure",
                "matched_text": f"仓库名: {repo.get('name', '')} | 描述: {repo.get('description', '')[:100]}",
                "severity": "中",
            })
        return results
    except Exception as e:
        logger.error(f"Gitee 搜索异常: {e}")
        return [{"error": str(e)}]


def scan_by_keyword(keyword: str, platform: str = "github",
                    github_token: str = None, gitee_token: str = None,
                    max_results: int = 30) -> list[dict]:
    """统一入口：根据平台选择扫描方式"""
    if platform == "github":
        return scan_github(keyword, github_token or "", max_results)
    elif platform == "gitee":
        return scan_gitee(keyword, gitee_token or "", max_results)
    elif platform == "all":
        gh = scan_github(keyword, github_token or "", max_results)
        gt = scan_gitee(keyword, gitee_token or "", max_results // 2)
        return gh + gt
    return [{"error": f"不支持的平台: {platform}"}]


# ── 私有辅助 ──────────────────────────────────────────────────

def _fetch_raw_content(item: dict, headers: dict) -> Optional[str]:
    """尝试获取 GitHub 文件的 raw 内容"""
    try:
        # 从 git_url 构造 raw 下载链接
        git_url = item.get("git_url", "")
        if not git_url:
            return None
        # GitHub API: GET /repos/:owner/:repo/git/blobs/:sha
        resp = requests.get(git_url, headers={**headers, "Accept": "application/vnd.github.raw"},
                            timeout=8)
        if resp.status_code == 200:
            return resp.text[:5000]   # 最多取前 5000 字符
    except Exception:
        pass
    return None


def _scan_content(content: str) -> list[dict]:
    """对文件内容应用正则模式，返回发现的泄露列表"""
    found = []
    for pattern, leak_type in LEAK_PATTERNS:
        matches = re.findall(pattern, content)
        for m in matches:
            text = m if isinstance(m, str) else " ".join(m)
            # 过滤明显的占位符
            if any(placeholder in text.lower() for placeholder in
                   ["example", "placeholder", "your_", "xxx", "yyy", "test", "sample", "<"]):
                continue
            found.append({
                "leak_type": leak_type,
                "matched_text": text[:200],
            })
            break   # 每种类型只报告一次
    return found


def _is_suspicious_path(file_path: str) -> bool:
    """判断文件路径是否本身就是敏感文件"""
    suspicious = [
        ".env", "config.py", "settings.py", "application.yml",
        "application.properties", "database.yml", "secrets.yml",
        ".git-credentials", "id_rsa", "id_dsa", ".pem", ".key",
    ]
    fp = file_path.lower()
    return any(s in fp for s in suspicious)
