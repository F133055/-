"""SecPlatform v4.0 - 主应用入口"""
import re
import sys
import logging
import subprocess
import time
from pathlib import Path
from contextlib import asynccontextmanager
from fastapi.staticfiles import StaticFiles

PROJECT_ROOT = Path(__file__).parent.resolve()
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

# ── 最先初始化日志（其他模块 import 之前）────────────────────
from core.config import settings, validate_required_settings, show_config_summary, setup_logging
_log_file = setup_logging()

from fastapi import FastAPI, HTTPException, Depends
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.middleware.cors import CORSMiddleware
from db import models
from routers import auth, scan, assets, health

logger = logging.getLogger(__name__)

_redis_proc  = None
_celery_proc = None


def is_redis_running() -> bool:
    try:
        import redis
        redis.Redis(host="127.0.0.1", port=6379, socket_connect_timeout=2).ping()
        return True
    except Exception:
        return False


def start_redis():
    global _redis_proc
    if is_redis_running():
        logger.info("✅ Redis 已在运行")
        return True

    logger.info("🔄 Redis 未运行，尝试自动启动...")
    for cmd in ["redis-server",
                r"C:\Program Files\Redis\redis-server.exe",
                r"C:\Redis\redis-server.exe"]:
        try:
            _redis_proc = subprocess.Popen(
                [cmd], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                creationflags=subprocess.CREATE_NO_WINDOW if sys.platform == "win32" else 0
            )
            time.sleep(2)
            if is_redis_running():
                logger.info(f"✅ Redis 启动成功")
                return True
        except FileNotFoundError:
            continue
        except Exception as e:
            logger.warning(f"启动 Redis 失败 ({cmd}): {e}")

    logger.error("❌ 无法自动启动 Redis！请手动运行: redis-server")
    return False


def start_celery():
    global _celery_proc
    log_file = PROJECT_ROOT / "logs" / "celery.log"
    log_file.parent.mkdir(exist_ok=True)

    logger.info("🔄 启动 Celery Worker...")
    try:
        with open(log_file, "a", encoding="utf-8") as lf:
            _celery_proc = subprocess.Popen(
                [sys.executable, "-m", "celery", "-A", "celery_app",
                 "worker", "--loglevel=debug", "-P", "solo"],
                cwd=str(PROJECT_ROOT),
                stdout=lf,
                stderr=lf,
                creationflags=subprocess.CREATE_NO_WINDOW if sys.platform == "win32" else 0
            )
        time.sleep(4)
        if _celery_proc.poll() is None:
            logger.info(f"✅ Celery Worker 启动成功 (PID:{_celery_proc.pid}，日志:{log_file})")
            return True
        else:
            # 读取日志诊断
            try:
                err = log_file.read_text(encoding="utf-8", errors="ignore")[-800:]
            except Exception:
                err = "无法读取日志"
            logger.error(f"❌ Celery 启动失败，最后日志:\n{err}")
            return False
    except Exception as e:
        logger.error(f"❌ 启动 Celery 异常: {e}", exc_info=True)
        return False


def stop_background_services():
    global _redis_proc, _celery_proc
    for name, proc in [("Celery", _celery_proc), ("Redis", _redis_proc)]:
        if proc and proc.poll() is None:
            logger.info(f"🛑 关闭 {name}...")
            try:
                proc.terminate()
                proc.wait(timeout=5)
            except Exception:
                proc.kill()
    _celery_proc = None
    _redis_proc  = None


@asynccontextmanager
async def lifespan(app: FastAPI):
    logger.info("=" * 60)
    logger.info(f"🚀 SecPlatform v4.0 启动中...")
    logger.info(f"📄 日志文件: {_log_file}")
    logger.info("=" * 60)

    is_valid, missing = validate_required_settings()
    if not is_valid:
        logger.error(f"❌ 缺失配置: {missing}")
        raise RuntimeError("缺失必需配置")
    show_config_summary()

    logger.info("⚡ [1/3] Redis...")
    if not start_redis():
        logger.warning("⚠️  Redis 未就绪，扫描功能受限")

    logger.info("⚡ [2/3] Celery Worker...")
    if not start_celery():
        logger.warning("⚠️  Celery 未就绪，任务将停留在 PENDING")

    logger.info("🗄️ [3/3] 数据库...")
    try:
        models.init_db()
        ok, msg = models.check_db_connection()
        if not ok:
            raise Exception(msg)
        logger.info(f"✅ 数据库连接正常")
    except Exception as e:
        logger.error(f"❌ 数据库初始化失败: {e}")
        stop_background_services()
        raise

    logger.info("=" * 60)
    logger.info("✅ 所有服务就绪！访问: http://127.0.0.1:8000")
    logger.info("=" * 60)

    try:
        from core.task_scheduler import start as _sched_start
        _sched_start()
    except Exception as _e:
        logger.warning(f"⚠️  定时调度器启动失败: {_e}")

    yield

    logger.info("🛑 关闭服务...")
    try:
        from core.task_scheduler import stop as _sched_stop
        _sched_stop()
    except Exception:
        pass
    stop_background_services()
    if models.engine:
        models.engine.dispose()
    logger.info("✅ 已关闭")


app = FastAPI(
    title="SecPlatform 安全专项扫描与智能分析平台",
    version="4.0.0",
    docs_url="/api/docs",
    openapi_url="/api/openapi.json",
    lifespan=lifespan,
)

app.mount("/static", StaticFiles(directory="static"), name="static")

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(auth.router)
app.include_router(scan.router)
app.include_router(assets.router)
app.include_router(health.router)

def _try_include(module_path: str):
    try:
        import importlib
        mod = importlib.import_module(module_path)
        app.include_router(mod.router)
        logger.info(f"  ✓ {module_path}")
    except ImportError:
        pass
    except Exception as e:
        logger.warning(f"  ✗ {module_path}: {e}")

logger.info("加载扩展路由...")
for m in ["routers.vulns", "routers.reports", "routers.notify", "routers.fofa",
          "routers.scheduler", "routers.threat_intel", "routers.github_scan", "routers.anomaly",
          "routers.knowledge", "routers.devices", "routers.policy", "routers.ai_security",
          "routers.agent"]:
    _try_include(m)


@app.exception_handler(HTTPException)
async def http_exception_handler(request, exc):
    logger.warning(f"HTTP {exc.status_code}: {request.url} - {exc.detail}")
    return JSONResponse(
        status_code=exc.status_code,
        content={"code": exc.status_code, "message": exc.detail, "success": False}
    )

@app.exception_handler(Exception)
async def general_exception_handler(request, exc):
    logger.error(f"未预期异常 [{request.url}]: {exc}", exc_info=True)
    return JSONResponse(
        status_code=500,
        content={"code": 500, "message": "服务器内部错误", "success": False}
    )

@app.get("/", summary="Web 主界面")
async def root():
    """返回前端主页。JS 文件由浏览器直接按需加载，Python 无需做任何拼接。"""
    f = Path(__file__).parent / "static" / "index.html"
    if not f.exists():
        return {"message": "SecPlatform API 运行正常", "docs": "/api/docs"}
    return HTMLResponse(
        content=f.read_text(encoding="utf-8"),
        headers={"Cache-Control": "no-store"},
    )

@app.get("/health")
async def health_simple():
    return {"status": "healthy", "version": "4.0.0"}

# ── 日志查看接口（方便排查问题）────────────────────────────────
@app.get("/api/logs", summary="查看最新日志", tags=["3. 系统"])
async def get_logs(lines: int = 100, log_type: str = "app",
                   user = Depends(auth.verify_token)):
    """实时查看日志文件内容（需要登录）"""
    log_map = {
        "app":    PROJECT_ROOT / "logs" / "secplatform.log",
        "celery": PROJECT_ROOT / "logs" / "celery.log",
    }
    log_file = log_map.get(log_type, log_map["app"])
    if not log_file.exists():
        return {"lines": [], "message": "日志文件不存在"}
    try:
        all_lines = log_file.read_text(encoding="utf-8", errors="ignore").splitlines()
        return {
            "log_type": log_type,
            "total_lines": len(all_lines),
            "lines": all_lines[-lines:],
        }
    except Exception as e:
        return {"error": str(e)}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
