// pages/TaskHistory.js

const TASK_TYPE_LABEL = {
  asset:'资产扫描', vuln:'漏洞扫描', weakpass:'弱密码检测',
  fofa:'FOFA探测', comprehensive:'综合扫描',
};

function getCheckMethod(t) {
  let p = t.params;
  if (typeof p === 'string') { try { p = JSON.parse(p); } catch { p = {}; } }
  if (!p) return '—';
  if (p.vuln_type) return p.vuln_type;
  if (p.service)   return p.service.toUpperCase() + ' 弱密码';
  if (p.query)     return 'FOFA: ' + p.query;
  if (t.task_type === 'asset') return '端口扫描';
  return '—';
}

// ── 任务详情弹窗 ─────────────────────────────────────────────
function TaskDetailModal({ task, onClose }) {
  const [detail,  setDetail]  = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!task) return;
    setLoading(true); setDetail(null);
    api.get('/api/scan/task/' + task.task_id).then(r => { setDetail(r); setLoading(false); });
  }, [task]);

  if (!task) return null;

  const statusColor = {SUCCESS:'var(--green)',FAILED:'var(--red)',FAILURE:'var(--red)',RUNNING:'var(--cyan)',STARTED:'var(--cyan)',PENDING:'var(--text3)'};
  const statusLabel = {SUCCESS:'已完成',FAILED:'失败',FAILURE:'失败',RUNNING:'运行中',STARTED:'运行中',PENDING:'等待中'};

  return (
    <div style={{position:'fixed',inset:0,zIndex:500,display:'flex',alignItems:'center',justifyContent:'center'}} onClick={onClose}>
      <div style={{position:'absolute',inset:0,background:'rgba(0,0,0,.65)'}}/>
      <div style={{position:'relative',width:660,maxWidth:'96vw',maxHeight:'84vh',background:'var(--surface)',borderRadius:12,border:'1px solid var(--border)',boxShadow:'0 24px 60px rgba(0,0,0,.6)',display:'flex',flexDirection:'column',overflow:'hidden'}}
        onClick={e=>e.stopPropagation()}>
        {/* 头部 */}
        <div style={{padding:'14px 20px',borderBottom:'1px solid var(--border)',display:'flex',alignItems:'center',justifyContent:'space-between',flexShrink:0}}>
          <div>
            <div style={{fontFamily:'Rajdhani',fontSize:17,fontWeight:700,letterSpacing:1}}>任务详情</div>
            <div style={{fontSize:11,color:'var(--text3)',marginTop:2,fontFamily:'monospace',wordBreak:'break-all'}}>{task.task_id}</div>
          </div>
          <button onClick={onClose} style={{background:'none',border:'none',cursor:'pointer',color:'var(--text3)',fontSize:22,lineHeight:1,padding:'0 4px'}}>✕</button>
        </div>
        {/* 内容 */}
        <div style={{flex:1,overflowY:'auto',padding:20}}>
          {loading ? (
            <div className="empty-state"><span className="spinner"></span></div>
          ) : (
            <div>
              <div className="card" style={{marginBottom:16}}>
                {[
                  ['任务类型',  TASK_TYPE_LABEL[task.task_type]||task.task_type],
                  ['检测方式',  getCheckMethod(task)],
                  ['当前状态',  <span style={{color:statusColor[detail?.status||task.status]}}>{statusLabel[detail?.status||task.status]||task.status}</span>],
                  ['进度',      (detail?.progress ?? 0) + '%'],
                  ['操作人',    task.operator||'系统'],
                  ['创建时间',  task.created_at||'—'],
                  ['完成时间',  task.finished_at||'—'],
                ].map(([k,v])=>(
                  <div key={k} style={{display:'flex',justifyContent:'space-between',alignItems:'center',padding:'8px 0',borderBottom:'1px solid var(--border)',fontSize:13}}>
                    <span style={{color:'var(--text3)',minWidth:70}}>{k}</span>
                    <span style={{color:'var(--text2)',textAlign:'right'}}>{v}</span>
                  </div>
                ))}
              </div>
              {detail?.result && (
                <div className="card">
                  <div className="card-header"><span className="card-title">扫描结果</span></div>
                  <TaskResultBlock result={detail.result}/>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function TaskResultBlock({ result }) {
  if (!result) return <div style={{color:'var(--text3)',fontSize:13,padding:8}}>暂无结果</div>;
  if (result.discovered_assets) {
    const a = result.discovered_assets;
    const ips = Object.keys(a).filter(ip=>(a[ip]||[]).length>0);
    return (
      <div>
        <div style={{fontSize:12,color:'var(--text3)',marginBottom:8}}>发现 {ips.length} 个有开放端口的主机</div>
        {ips.map(ip=>(
          <div key={ip} style={{display:'flex',justifyContent:'space-between',padding:'5px 10px',background:'var(--card2)',borderRadius:5,marginBottom:4,fontSize:13}}>
            <span className="mono text-cyan">{ip}</span>
            <span style={{color:'var(--text3)',fontSize:11}}>{(a[ip]||[]).join(', ')}</span>
          </div>
        ))}
      </div>
    );
  }
  if (result.result !== undefined) {
    const found = String(result.result).includes('发现')||String(result.result).includes('弱口令');
    return (
      <div style={{padding:'10px 12px',background:found?'rgba(239,68,68,.08)':'var(--card2)',borderRadius:6,fontFamily:'JetBrains Mono',fontSize:12,color:found?'var(--red)':'var(--green)'}}>
        {String(result.result)||'无结果'}
      </div>
    );
  }
  return (
    <pre style={{fontSize:11,color:'var(--text2)',fontFamily:'JetBrains Mono',whiteSpace:'pre-wrap',wordBreak:'break-all',lineHeight:1.6,maxHeight:300,overflowY:'auto',margin:0}}>
      {JSON.stringify(result, null, 2)}
    </pre>
  );
}

// ── 主页面 ───────────────────────────────────────────────────
function TaskHistoryPage() {
  const [tasks,        setTasks]        = useState([]);
  const [initDone,     setInitDone]     = useState(false);
  const [refreshing,   setRefreshing]   = useState(false);
  const [selTask,      setSelTask]      = useState(null);
  const [filterType,   setFilterType]   = useState('');
  const [filterStatus, setFilterStatus] = useState('');
  const [pg,           setPg]           = useState(1);
  const [selected,     setSelected]     = useState([]);   // 多选 task_id 数组
  const [deleting,     setDeleting]     = useState({});
  const [workerStatus, setWorkerStatus] = useState(null); // null=未检测 true=在线 false=离线
  const PAGE_SIZE = 20;

  const load = useCallback(async (isManual=false) => {
    if (isManual) setRefreshing(true);
    const r = await api.get('/api/scan/tasks?limit=200');
    if (r?.data) setTasks(r.data);
    setInitDone(true);
    if (isManual) setRefreshing(false);
  }, []);

  // Worker 状态检测（页面加载时自动检查一次）
  const checkWorker = useCallback(async () => {
    try {
      const r = await api.get('/api/health/worker');
      setWorkerStatus(r?.running === true);
    } catch { setWorkerStatus(false); }
  }, []);

  useEffect(() => { load(false); checkWorker(); }, []);

  // ── 清空所有 PENDING 任务（Worker离线时卡住的任务）─────────
  const clearPending = useCallback(async () => {
    const pendingIds = tasks.filter(t => t.status === 'PENDING').map(t => t.task_id);
    if (!pendingIds.length) { alert('没有等待中的任务记录'); return; }
    if (!confirm(`确认删除全部 ${pendingIds.length} 条「等待中」任务？\n⚠️ 这不会撤销已提交到 Celery 队列的任务，仅清理数据库记录。`)) return;
    for (const id of pendingIds) {
      await api.delete('/api/scan/task/' + id);
    }
    setTasks(prev => prev.filter(t => !pendingIds.includes(t.task_id)));
    setSelected([]);
  }, [tasks]);

  // ── 删除单条 ──────────────────────────────────────────────
  const deleteOne = useCallback(async (taskId, e) => {
    e.stopPropagation();
    if (!confirm('确认删除此任务记录？')) return;
    setDeleting(prev => ({...prev, [taskId]:true}));
    const r = await api.delete('/api/scan/task/' + taskId);
    if (r?.code===200) {
      setTasks(prev => prev.filter(t => t.task_id !== taskId));
      setSelected(prev => prev.filter(id => id !== taskId));
    } else {
      alert('删除失败：' + (r?.detail||r?.message||JSON.stringify(r)));
    }
    setDeleting(prev => { const n={...prev}; delete n[taskId]; return n; });
  }, []);

  // ── 批量删除所选 ──────────────────────────────────────────
  const deleteSelected = useCallback(async () => {
    if (!selected.length) return;
    if (!confirm('确认删除所选 ' + selected.length + ' 条任务记录？')) return;
    const ids = [...selected];
    // 逐条删除（后端批量接口备用）
    for (const id of ids) {
      await api.delete('/api/scan/task/' + id);
    }
    setTasks(prev => prev.filter(t => !ids.includes(t.task_id)));
    setSelected([]);
  }, [selected]);

  // ── 一键清空所有已完成 ────────────────────────────────────
  const clearFinished = useCallback(async () => {
    const finishedIds = tasks
      .filter(t => t.status==='SUCCESS'||t.status==='FAILED'||t.status==='FAILURE')
      .map(t => t.task_id);
    if (!finishedIds.length) { alert('没有已完成/失败的任务记录'); return; }
    if (!confirm('确认删除全部 ' + finishedIds.length + ' 条已完成/失败任务？')) return;
    for (const id of finishedIds) {
      await api.delete('/api/scan/task/' + id);
    }
    setTasks(prev => prev.filter(t => !finishedIds.includes(t.task_id)));
    setSelected([]);
  }, [tasks]);

  const statusBadge = s => {
    const m={SUCCESS:'badge-green',FAILED:'badge-red',FAILURE:'badge-red',RUNNING:'badge-cyan',STARTED:'badge-cyan',PENDING:'badge-gray'};
    const l={SUCCESS:'完成',FAILED:'失败',FAILURE:'失败',RUNNING:'运行中',STARTED:'运行中',PENDING:'等待中'};
    return <span className={`badge ${m[s]||'badge-gray'}`}>{l[s]||s}</span>;
  };

  const filtered = tasks.filter(t => {
    if (filterType   && t.task_type!==filterType)   return false;
    if (filterStatus && t.status   !==filterStatus)  return false;
    return true;
  });
  const paged      = filtered.slice((pg-1)*PAGE_SIZE, pg*PAGE_SIZE);
  const totalPages = Math.ceil(filtered.length / PAGE_SIZE);

  // 当前页全选状态
  const pagedIds      = paged.map(t=>t.task_id);
  const allPageSelected = pagedIds.length>0 && pagedIds.every(id=>selected.includes(id));
  const togglePageAll = () => {
    if (allPageSelected) setSelected(prev=>prev.filter(id=>!pagedIds.includes(id)));
    else setSelected(prev=>[...new Set([...prev,...pagedIds])]);
  };

  const counts = {
    total:   tasks.length,
    running: tasks.filter(t=>['RUNNING','STARTED','PENDING'].includes(t.status)).length,
    success: tasks.filter(t=>t.status==='SUCCESS').length,
    failed:  tasks.filter(t=>['FAILED','FAILURE'].includes(t.status)).length,
  };

  return (
    <div>
      <div className="flex-between mb-16">
        <div>
          <div style={{fontSize:22,fontFamily:'Rajdhani',fontWeight:700,letterSpacing:1}}>历史任务</div>
          <div style={{fontSize:12,color:'var(--text3)',marginTop:2}}>点击行查看详情 · 勾选后批量删除 · 支持一键清空已完成</div>
        </div>
        <div style={{display:'flex',gap:8,alignItems:'center'}}>
          {/* Worker 状态指示器 */}
          <div style={{display:'flex',alignItems:'center',gap:5,fontSize:11,padding:'4px 10px',borderRadius:6,
            background: workerStatus===true?'rgba(34,197,94,.12)':workerStatus===false?'rgba(239,68,68,.12)':'var(--surface)',
            border: '1px solid '+(workerStatus===true?'rgba(34,197,94,.3)':workerStatus===false?'rgba(239,68,68,.3)':'var(--border)')
          }}>
            <span style={{width:7,height:7,borderRadius:'50%',display:'inline-block',
              background:workerStatus===true?'#22c55e':workerStatus===false?'#ef4444':'#94a3b8'}}></span>
            <span style={{color:workerStatus===true?'var(--green)':workerStatus===false?'var(--red)':'var(--text3)'}}>
              {workerStatus===null?'检测中...':workerStatus?'Worker 在线':'Worker 离线'}
            </span>
            <span style={{cursor:'pointer',color:'var(--text3)',marginLeft:2}} onClick={checkWorker} title="刷新Worker状态">↺</span>
          </div>
          {/* 清空PENDING - 仅Worker离线时才高亮提示 */}
          <button className="btn btn-ghost" style={{fontSize:12,
            color: workerStatus===false?'var(--red)':'var(--text3)',
            borderColor: workerStatus===false?'rgba(239,68,68,.4)':'var(--border)'
          }} onClick={clearPending} title="删除所有等待中的任务DB记录">⏹ 清空PENDING</button>
          <button className="btn btn-ghost" style={{fontSize:12}} onClick={clearFinished}>🗑 清空已完成</button>
          <button className="btn btn-ghost" onClick={()=>load(true)} disabled={refreshing}>
            {refreshing ? <span className="spinner" style={{width:13,height:13}}></span> : icons.refresh} 刷新
          </button>
        </div>
      </div>

      {/* 统计卡片 */}
      <div className="stats-grid section-gap" style={{gridTemplateColumns:'repeat(4,1fr)'}}>
        {[
          {l:'总任务数',v:counts.total,  c:'cyan'},
          {l:'运行中',  v:counts.running,c:'blue'},
          {l:'已完成',  v:counts.success,c:'green'},
          {l:'失败',    v:counts.failed, c:'red'},
        ].map(s=>(
          <div key={s.l} className={`stat-card ${s.c}`}>
            <div className="stat-value">{s.v}</div>
            <div className="stat-label">{s.l}</div>
          </div>
        ))}
      </div>

      <div className="card">
        {/* 过滤 + 批量操作栏 */}
        <div style={{display:'flex',gap:10,marginBottom:14,flexWrap:'wrap',alignItems:'center'}}>
          <select className="form-select" style={{width:130}} value={filterType}
            onChange={e=>{setFilterType(e.target.value);setPg(1);setSelected([]);}}>
            <option value="">全部类型</option>
            {Object.entries(TASK_TYPE_LABEL).map(([v,l])=><option key={v} value={v}>{l}</option>)}
          </select>
          <select className="form-select" style={{width:110}} value={filterStatus}
            onChange={e=>{setFilterStatus(e.target.value);setPg(1);setSelected([]);}}>
            <option value="">全部状态</option>
            <option value="SUCCESS">已完成</option>
            <option value="RUNNING">运行中</option>
            <option value="PENDING">等待中</option>
            <option value="FAILED">失败</option>
          </select>
          {(filterType||filterStatus) && (
            <button className="btn btn-ghost" style={{padding:'4px 10px',fontSize:12}}
              onClick={()=>{setFilterType('');setFilterStatus('');setPg(1);setSelected([]);}}>清除过滤</button>
          )}
          {selected.length>0 && (
            <button className="btn btn-danger" style={{padding:'4px 12px',fontSize:12}}
              onClick={deleteSelected}>
              🗑 删除所选 ({selected.length})
            </button>
          )}
          <span style={{marginLeft:'auto',fontSize:12,color:'var(--text3)'}}>共 {filtered.length} 条</span>
        </div>

        {!initDone ? (
          <div className="empty-state"><span className="spinner"></span></div>
        ) : paged.length===0 ? (
          <div className="empty-state"><div className="empty-icon">◎</div><div>暂无任务记录</div></div>
        ) : (
          <>
            <div className="table-wrap">
              <table>
                <thead>
                  <tr>
                    <th style={{width:32}}>
                      <input type="checkbox" checked={allPageSelected} onChange={togglePageAll} title="全选本页"/>
                    </th>
                    <th>类型</th><th>检测方式</th><th>操作人</th><th>状态</th>
                    <th>创建时间</th><th>完成时间</th><th>操作</th>
                  </tr>
                </thead>
                <tbody>
                  {paged.map(t => (
                    <tr key={t.task_id} style={{cursor:'pointer',background:selected.includes(t.task_id)?'rgba(0,229,255,0.04)':'undefined'}}
                      onClick={()=>setSelTask(t)}>
                      <td onClick={e=>e.stopPropagation()}>
                        <input type="checkbox" checked={selected.includes(t.task_id)}
                          onChange={e=>setSelected(s=>e.target.checked?[...s,t.task_id]:s.filter(id=>id!==t.task_id))}/>
                      </td>
                      <td><span className="badge badge-blue">{TASK_TYPE_LABEL[t.task_type]||t.task_type}</span></td>
                      <td style={{fontSize:12,color:'var(--text2)'}}>{getCheckMethod(t)}</td>
                      <td className="text-dimmer">{t.operator||'系统'}</td>
                      <td>{statusBadge(t.status)}</td>
                      <td className="text-dimmer" style={{fontSize:12}}>{t.created_at}</td>
                      <td className="text-dimmer" style={{fontSize:12}}>{t.finished_at||'—'}</td>
                      <td onClick={e=>e.stopPropagation()}>
                        <div style={{display:'flex',gap:4}}>
                          <button className="btn btn-ghost" style={{padding:'2px 8px',fontSize:11}}
                            onClick={()=>setSelTask(t)}>详情</button>
                          <button className="btn btn-danger"
                            style={{padding:'2px 8px',fontSize:11,opacity:deleting[t.task_id]?0.5:1}}
                            disabled={!!deleting[t.task_id]}
                            onClick={e=>deleteOne(t.task_id,e)}>
                            {deleting[t.task_id]?'...':'删除'}
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            {totalPages>1 && (
              <div style={{display:'flex',justifyContent:'center',gap:8,marginTop:14}}>
                <button className="btn btn-ghost" style={{padding:'4px 10px'}} disabled={pg<=1} onClick={()=>setPg(p=>p-1)}>上一页</button>
                <span style={{padding:'4px 12px',fontSize:13,color:'var(--text2)'}}>{pg} / {totalPages}</span>
                <button className="btn btn-ghost" style={{padding:'4px 10px'}} disabled={pg>=totalPages} onClick={()=>setPg(p=>p+1)}>下一页</button>
              </div>
            )}
          </>
        )}
      </div>

      {selTask && <TaskDetailModal task={selTask} onClose={()=>setSelTask(null)}/>}
    </div>
  );
}
