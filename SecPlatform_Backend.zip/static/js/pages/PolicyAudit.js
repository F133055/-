// pages/PolicyAudit.js - 防火墙策略审核页面
function PolicyAuditPage() {
  const [policies, setPolicies] = useState([]);
  const [results, setResults]   = useState([]);
  const [loading, setLoading]   = useState(false);
  const [auditing, setAuditing] = useState(false);
  const [showAdd, setShowAdd]   = useState(false);
  const [saving, setSaving]     = useState(false);
  const [msg, setMsg]           = useState('');
  const [tab, setTab]           = useState('policies'); // policies | results
  const [selected, setSelected] = useState(null);
  const [form, setForm] = useState({
    name:'', device_name:'', src_ip:'', dst_ip:'', dst_port:'',
    protocol:'TCP', action:'ALLOW', description:''
  });

  const RISK_RULES = [
    { id:'r1', name:'允许全端口访问', severity:'高', desc:'策略允许从任意源到目标的所有端口访问（any/0.0.0.0）' },
    { id:'r2', name:'高危端口对外开放', severity:'高', desc:'策略允许高危端口（22/3389/6379/27017等）面向互联网' },
    { id:'r3', name:'宽泛源地址', severity:'中', desc:'策略源地址范围过宽（/8以上大段），建议精细化' },
    { id:'r4', name:'双向ANY策略', severity:'高', desc:'策略允许双向any流量，存在绕过防火墙风险' },
    { id:'r5', name:'重复冗余策略', severity:'低', desc:'存在多条规则覆盖相同流量，建议合并精简' },
    { id:'r6', name:'过期未清理策略', severity:'中', desc:'策略长期未更新且无备注，建议审查是否仍然需要' },
  ];

  const HIGH_RISK_PORTS = [21,22,23,25,110,135,137,139,445,1433,1521,3306,3389,5432,6379,7001,8080,27017,50070];

  const load = async () => {
    setLoading(true);
    const [pr, rr] = await Promise.all([
      api.get('/api/policy/'),
      api.get('/api/policy/results'),
    ]);
    if (pr?.data) setPolicies(pr.data);
    if (rr?.data) setResults(rr.data);
    setLoading(false);
  };

  useEffect(() => { load(); }, []);

  const save = async () => {
    if (!form.name.trim()) { setMsg('✗ 策略名称不能为空'); setTimeout(()=>setMsg(''),3000); return; }
    setSaving(true);
    const r = await api.post('/api/policy/', form);
    setSaving(false);
    if (r?.code === 200) {
      setMsg('✓ 策略添加成功'); setShowAdd(false);
      setForm({ name:'', device_name:'', src_ip:'', dst_ip:'', dst_port:'', protocol:'TCP', action:'ALLOW', description:'' });
      load();
    } else { setMsg('✗ ' + (r?.detail||'失败')); }
    setTimeout(()=>setMsg(''),3000);
  };

  const audit = async (id) => {
    setAuditing(true);
    const r = id ? await api.post(`/api/policy/${id}/audit`) : await api.post('/api/policy/audit-all');
    setAuditing(false);
    if (r?.code === 200) { load(); setTab('results'); }
  };

  const del = async (id) => {
    if (!confirm('确认删除该策略？')) return;
    await api.delete(`/api/policy/${id}`);
    load();
  };

  const severityBadge = (s) => {
    const map = { '高':<span className="badge badge-red">高危</span>, '中':<span className="badge badge-orange">中危</span>, '低':<span className="badge badge-green">低危</span>, '信息':<span className="badge badge-gray">信息</span> };
    return map[s] || map['信息'];
  };

  const actionBadge = (a) => a==='ALLOW'
    ? <span className="badge badge-green">允许</span>
    : <span className="badge badge-red">拒绝</span>;

  // Local risk analysis (instant feedback without API)
  const analyzeLocal = (p) => {
    const risks = [];
    const dstPort = p.dst_port || '';
    const srcIp   = p.src_ip   || '';
    const dstIp   = p.dst_ip   || '';
    if (p.action === 'ALLOW') {
      if (dstPort === 'any' || dstPort === '' || dstPort === '0-65535') risks.push({...RISK_RULES[0]});
      const ports = dstPort.split(/[,\-\/]/).map(x=>parseInt(x.trim())).filter(n=>!isNaN(n));
      if (ports.some(pt=>HIGH_RISK_PORTS.includes(pt)) && (dstIp.includes('0.0.0.0')||dstIp==='any')) risks.push({...RISK_RULES[1]});
      if (srcIp.endsWith('/8')||srcIp.endsWith('/9')||srcIp.endsWith('/10')||srcIp==='any'||srcIp==='0.0.0.0/0') risks.push({...RISK_RULES[2]});
    }
    return risks;
  };

  const allRiskCount = results.filter(r=>r.severity==='高').length;

  return (
    <div>
      <div className="mb-16" style={{display:'flex',justifyContent:'space-between',alignItems:'flex-start'}}>
        <div>
          <div style={{fontSize:22,fontFamily:'Rajdhani',fontWeight:700,letterSpacing:1}}>策略审核</div>
          <div style={{fontSize:12,color:'var(--text3)',marginTop:2}}>防火墙策略风险分析与优化建议</div>
        </div>
        <div style={{display:'flex',gap:8}}>
          <button className="btn btn-ghost" onClick={()=>audit(null)} disabled={auditing||policies.length===0}>
            {auditing?<><span className="spinner"></span> 审核中</>:'🔍 全量审核'}
          </button>
          <button className="btn btn-primary" onClick={()=>setShowAdd(true)}>+ 导入策略</button>
        </div>
      </div>

      {/* 风险概览 */}
      <div style={{display:'grid',gridTemplateColumns:'repeat(4,1fr)',gap:12,marginBottom:16}}>
        {[
          {label:'策略总数',value:policies.length,color:'var(--cyan)',icon:'📋'},
          {label:'高危风险',value:results.filter(r=>r.severity==='高').length,color:'var(--red)',icon:'🔴'},
          {label:'中危风险',value:results.filter(r=>r.severity==='中').length,color:'var(--orange)',icon:'🟠'},
          {label:'已审核',value:results.length,color:'var(--green)',icon:'✅'},
        ].map(s=>(
          <div key={s.label} className="card" style={{textAlign:'center'}}>
            <div style={{fontSize:20,marginBottom:4}}>{s.icon}</div>
            <div style={{fontSize:26,fontFamily:'Rajdhani',fontWeight:700,color:s.color}}>{s.value}</div>
            <div style={{fontSize:12,color:'var(--text3)'}}>{s.label}</div>
          </div>
        ))}
      </div>

      {/* 风险规则说明 */}
      <div className="card section-gap">
        <div className="card-header"><span className="card-title">📏 审核规则</span></div>
        <div style={{display:'grid',gridTemplateColumns:'repeat(auto-fill,minmax(280px,1fr))',gap:8}}>
          {RISK_RULES.map(r=>(
            <div key={r.id} style={{padding:'8px 12px',background:'var(--card2)',borderRadius:6,borderLeft:`3px solid ${r.severity==='高'?'var(--red)':r.severity==='中'?'var(--orange)':'var(--green)'}`}}>
              <div style={{display:'flex',alignItems:'center',gap:6,marginBottom:4}}>
                {severityBadge(r.severity)}
                <span style={{fontSize:13,fontWeight:600}}>{r.name}</span>
              </div>
              <div style={{fontSize:11,color:'var(--text3)',lineHeight:1.6}}>{r.desc}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Tab切换 */}
      <div style={{display:'flex',gap:4,marginBottom:12,marginTop:16}}>
        {[['policies','📋 策略列表'],['results','⚠ 审核结果']].map(([id,label])=>(
          <button key={id} onClick={()=>setTab(id)}
            className={tab===id?'btn btn-primary':'btn btn-ghost'}
            style={{fontSize:13}}>
            {label}
            {id==='results'&&results.length>0&&<span style={{marginLeft:6,background:'var(--red)',color:'#fff',borderRadius:10,fontSize:10,padding:'1px 6px'}}>{allRiskCount}</span>}
          </button>
        ))}
      </div>

      {loading && <div style={{textAlign:'center',padding:40,color:'var(--text3)'}}>加载中…</div>}

      {/* 策略列表 */}
      {tab==='policies' && !loading && (
        <div>
          {policies.length===0 && (
            <div style={{textAlign:'center',padding:60,color:'var(--text3)'}}>
              <div style={{fontSize:36,marginBottom:8}}>📋</div>
              <div>暂无策略，点击「导入策略」添加防火墙规则</div>
            </div>
          )}
          {policies.length>0 && (
            <div className="card" style={{overflowX:'auto'}}>
              <table style={{width:'100%',borderCollapse:'collapse',fontSize:13}}>
                <thead>
                  <tr style={{borderBottom:'1px solid var(--border)',color:'var(--text3)',fontSize:11}}>
                    {['策略名称','设备','源地址','目标地址','目标端口','协议','动作','风险','操作'].map(h=>(
                      <th key={h} style={{padding:'8px 12px',textAlign:'left',fontWeight:500}}>{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {policies.map(p=>{
                    const localRisks = analyzeLocal(p);
                    return (
                      <tr key={p.id} style={{borderBottom:'1px solid var(--border)',transition:'background .1s'}}
                        onMouseEnter={e=>e.currentTarget.style.background='var(--card2)'}
                        onMouseLeave={e=>e.currentTarget.style.background=''}>
                        <td style={{padding:'8px 12px',fontWeight:500}}>{p.name}</td>
                        <td style={{padding:'8px 12px',color:'var(--text3)'}}>{p.device_name||'-'}</td>
                        <td style={{padding:'8px 12px',fontFamily:'JetBrains Mono',fontSize:12}}>{p.src_ip||'any'}</td>
                        <td style={{padding:'8px 12px',fontFamily:'JetBrains Mono',fontSize:12}}>{p.dst_ip||'any'}</td>
                        <td style={{padding:'8px 12px',fontFamily:'JetBrains Mono',fontSize:12}}>{p.dst_port||'any'}</td>
                        <td style={{padding:'8px 12px'}}>{p.protocol}</td>
                        <td style={{padding:'8px 12px'}}>{actionBadge(p.action)}</td>
                        <td style={{padding:'8px 12px'}}>
                          {localRisks.length>0 ? <span className="badge badge-red">{localRisks.length} 条风险</span> : <span className="badge badge-green">暂无</span>}
                        </td>
                        <td style={{padding:'8px 12px'}}>
                          <div style={{display:'flex',gap:6}}>
                            <button className="btn btn-ghost" style={{fontSize:11,padding:'3px 8px'}}
                              onClick={()=>{setSelected(p);setTab('results');}}>详情</button>
                            <button className="btn btn-ghost" style={{fontSize:11,padding:'3px 8px'}}
                              onClick={()=>audit(p.id)} disabled={auditing}>审核</button>
                            <button className="btn btn-ghost" style={{fontSize:11,padding:'3px 8px',color:'var(--red)'}}
                              onClick={()=>del(p.id)}>✕</button>
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* 审核结果 */}
      {tab==='results' && !loading && (
        <div>
          {results.length===0 && (
            <div style={{textAlign:'center',padding:60,color:'var(--text3)'}}>
              <div style={{fontSize:36,marginBottom:8}}>✅</div>
              <div>暂无审核结果，请点击「全量审核」开始分析</div>
            </div>
          )}
          <div style={{display:'flex',flexDirection:'column',gap:10}}>
            {results.map(r=>(
              <div key={r.id} className="card" style={{borderLeft:`3px solid ${r.severity==='高'?'var(--red)':r.severity==='中'?'var(--orange)':'var(--green)'}`}}>
                <div style={{display:'flex',justifyContent:'space-between',alignItems:'flex-start'}}>
                  <div>
                    <div style={{display:'flex',alignItems:'center',gap:8,marginBottom:6}}>
                      {severityBadge(r.severity)}
                      <span style={{fontWeight:600,fontSize:14}}>{r.risk_name}</span>
                      <span style={{fontSize:11,color:'var(--text3)'}}>→ {r.policy_name}</span>
                    </div>
                    <div style={{fontSize:13,color:'var(--text2)',marginBottom:6}}>{r.description}</div>
                    {r.suggestion && (
                      <div style={{fontSize:12,color:'var(--cyan)',padding:'6px 10px',background:'rgba(0,229,255,.06)',borderRadius:6}}>
                        💡 建议：{r.suggestion}
                      </div>
                    )}
                  </div>
                  <div style={{fontSize:11,color:'var(--text3)',flexShrink:0,marginLeft:16}}>
                    {r.created_at ? new Date(r.created_at).toLocaleString('zh-CN') : ''}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 新增策略弹窗 */}
      {/* 新增弹窗 - Modal Portal */}
      <Modal show={showAdd} onClose={()=>setShowAdd(false)} title="📋 导入防火墙策略" width={580}>
        <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:12}}>
              <div className="form-group" style={{gridColumn:'1/-1'}}>
                <label className="form-label">策略名称 *</label>
                <input className="form-input" value={form.name} onChange={e=>setForm(f=>({...f,name:e.target.value}))} placeholder="如：Allow-Office-RDP"/>
              </div>
              <div className="form-group">
                <label className="form-label">所属设备</label>
                <input className="form-input" value={form.device_name} onChange={e=>setForm(f=>({...f,device_name:e.target.value}))} placeholder="办公区防火墙-01"/>
              </div>
              <div className="form-group">
                <label className="form-label">协议</label>
                <select className="form-input" value={form.protocol} onChange={e=>setForm(f=>({...f,protocol:e.target.value}))}>
                  {['TCP','UDP','ICMP','ANY'].map(p=><option key={p}>{p}</option>)}
                </select>
              </div>
              <div className="form-group">
                <label className="form-label">源地址</label>
                <input className="form-input" value={form.src_ip} onChange={e=>setForm(f=>({...f,src_ip:e.target.value}))} placeholder="192.168.0.0/16 或 any"/>
              </div>
              <div className="form-group">
                <label className="form-label">目标地址</label>
                <input className="form-input" value={form.dst_ip} onChange={e=>setForm(f=>({...f,dst_ip:e.target.value}))} placeholder="10.0.0.0/8 或 any"/>
              </div>
              <div className="form-group">
                <label className="form-label">目标端口</label>
                <input className="form-input" value={form.dst_port} onChange={e=>setForm(f=>({...f,dst_port:e.target.value}))} placeholder="3389 或 80,443 或 any"/>
              </div>
              <div className="form-group">
                <label className="form-label">动作</label>
                <select className="form-input" value={form.action} onChange={e=>setForm(f=>({...f,action:e.target.value}))}>
                  <option value="ALLOW">允许</option>
                  <option value="DENY">拒绝</option>
                </select>
              </div>
              <div className="form-group" style={{gridColumn:'1/-1'}}>
                <label className="form-label">备注</label>
                <textarea className="form-input" rows={2} value={form.description} onChange={e=>setForm(f=>({...f,description:e.target.value}))} placeholder="策略用途说明、创建时间、负责人等"/>
              </div>
            </div>
            {msg && <div className={`alert ${msg.startsWith('✓')?'alert-success':'alert-error'}`}>{msg}</div>}
            <div className="flex gap-8">
              <button className="btn btn-primary" onClick={save} disabled={saving}>
                {saving?<><span className="spinner"></span> 保存中</>:'导入策略'}
              </button>
              <button className="btn btn-ghost" onClick={()=>setShowAdd(false)}>取消</button>
            </div>
      </Modal>
    </div>
  );
}
