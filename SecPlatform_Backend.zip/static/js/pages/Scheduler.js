// pages/Scheduler.js — 定时扫描任务管理 v4.1

const WEEK_DAYS = ['周一','周二','周三','周四','周五','周六','周日'];
const TYPE_LABEL = { asset:'资产扫描', vuln:'漏洞扫描', weakpass:'弱口令检测', quickscan:'综合扫描', report_daily:'日报自动推送', report_weekly:'周报自动推送' };
const TYPE_COLOR = { asset:'badge-cyan', vuln:'badge-red', weakpass:'badge-orange', quickscan:'badge-purple', report_daily:'badge-green', report_weekly:'badge-green' };
const SCHED_LABEL = { interval:'间隔', daily:'每天定时', weekly:'每周定时' };
const VULN_TYPES  = ['nacos','swagger','minio','actuator','druid','redis_unauth','docker'];
const WEAK_SVCS   = ['ssh','mysql','redis','ftp','postgresql','telnet','mongodb','mssql'];
const SCHED_CHECKS = [
  { id:'port_scan',    label:'端口扫描',     group:'资产发现'  },
  { id:'nacos',        label:'Nacos 未授权', group:'漏洞检测'  },
  { id:'swagger',      label:'Swagger 泄露', group:'漏洞检测'  },
  { id:'minio',        label:'MinIO 未授权', group:'漏洞检测'  },
  { id:'actuator',     label:'Actuator',     group:'漏洞检测'  },
  { id:'druid',        label:'Druid',        group:'漏洞检测'  },
  { id:'redis_unauth', label:'Redis 未授权', group:'漏洞检测'  },
  { id:'docker',       label:'Docker API',   group:'漏洞检测'  },
  { id:'ssh',          label:'SSH 弱密码',   group:'弱密码检测' },
  { id:'mysql',        label:'MySQL 弱密码', group:'弱密码检测' },
  { id:'redis',        label:'Redis 弱密码', group:'弱密码检测' },
  { id:'ftp',          label:'FTP 弱密码',   group:'弱密码检测' },
];

// ─────────────────────────────────────────────────────────────
// 创建/编辑弹窗
// ─────────────────────────────────────────────────────────────
function SchedulerFormModal({ task, onClose, onSaved }) {
  const isEdit = !!task;

  const [name,          setName]          = useState(task?.name           || '');
  const [taskType,      setTaskType]      = useState(task?.task_type      || 'asset');
  const [targetsStr,    setTargetsStr]    = useState((task?.targets||[]).join('\n'));
  const [schedType,     setSchedType]     = useState(task?.schedule_type  || 'interval');
  const [intervalHours, setIntervalHours] = useState(task?.interval_hours || 24);
  const [runAtTime,     setRunAtTime]     = useState(task?.run_at_time    || '09:00');
  const [runOnDays,     setRunOnDays]     = useState(task?.run_on_days    || [0]);
  const [enabled,       setEnabled]       = useState(task?.enabled        ?? true);
  // type-specific params
  const [vulnType,     setVulnType]     = useState(task?.params?.vuln_type || 'nacos');
  const [weakService,  setWeakService]  = useState(task?.params?.service   || 'ssh');
  const [customPort,   setCustomPort]   = useState(task?.params?.port      || '');
  const [qsChecks,     setQsChecks]     = useState(task?.params?.checks    || SCHED_CHECKS.map(c=>c.id));
  const [saving,       setSaving]       = useState(false);
  const [err,          setErr]          = useState('');

  const toggleDay = d => setRunOnDays(prev =>
    prev.includes(d) ? prev.filter(x=>x!==d) : [...prev, d]
  );
  const toggleCheck = id => setQsChecks(prev =>
    prev.includes(id) ? prev.filter(x=>x!==id) : [...prev, id]
  );

  const save = async () => {
    if (!name.trim()) { setErr('请填写任务名称'); return; }
    const targets = targetsStr.split(/[\n,\s]+/).filter(Boolean);
    if (!targets.length && !taskType.startsWith('report_')) { setErr('请填写至少一个目标 IP'); return; }
    if (schedType === 'daily' && !runAtTime) { setErr('请选择执行时间'); return; }
    if (schedType === 'weekly' && !runOnDays.length) { setErr('请至少选择一天'); return; }

    const params = taskType === 'vuln'      ? { vuln_type: vulnType, ...(customPort ? {port: Number(customPort)} : {}) }
                 : taskType === 'weakpass'  ? { service: weakService, ...(customPort ? {port: Number(customPort)} : {}) }
                 : taskType === 'quickscan' ? { checks: qsChecks }
                 : {};

    const body = {
      name: name.trim(), task_type: taskType, targets,
      params, schedule_type: schedType,
      interval_hours: Number(intervalHours),
      run_at_time: (schedType !== 'interval') ? runAtTime : null,
      run_on_days: schedType === 'weekly' ? runOnDays : null,
      enabled,
    };
    setSaving(true); setErr('');
    const r = isEdit
      ? await api.patch(`/api/scheduler/${task.id}`, body)
      : await api.post('/api/scheduler/', body);
    setSaving(false);
    if (r?.code === 200) { onSaved(); onClose(); }
    else setErr('保存失败：' + (r?.detail || r?.message || JSON.stringify(r)));
  };

  const sH = { padding: '14px 20px', borderBottom: '1px solid var(--border)', display:'flex', justifyContent:'space-between', alignItems:'center' };

  return (
    <div style={{position:'fixed',inset:0,zIndex:800,display:'flex',alignItems:'center',justifyContent:'center'}}
      onClick={onClose}>
      <div style={{position:'absolute',inset:0,background:'rgba(0,0,0,.65)'}}/>
      <div style={{position:'relative',width:600,maxWidth:'95vw',maxHeight:'90vh',background:'var(--surface)',borderRadius:12,border:'1px solid var(--border)',boxShadow:'0 20px 60px rgba(0,0,0,.5)',display:'flex',flexDirection:'column',overflow:'hidden'}}
        onClick={e=>e.stopPropagation()}>

        <div style={sH}>
          <div style={{fontFamily:'Rajdhani',fontSize:16,fontWeight:700}}>
            {isEdit ? '✏️ 编辑定时任务' : '⏰ 创建定时任务'}
          </div>
          <button onClick={onClose} style={{background:'none',border:'none',cursor:'pointer',color:'var(--text3)',fontSize:18}}>✕</button>
        </div>

        <div style={{flex:1,overflowY:'auto',padding:20}}>
          {/* 任务名称 */}
          <div className="form-group">
            <label className="form-label">任务名称</label>
            <input className="form-input" value={name} onChange={e=>setName(e.target.value)}
              placeholder="例：每日内网资产扫描" style={{width:'100%'}}/>
          </div>

          {/* 扫描类型 */}
          <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:12}}>
            <div className="form-group">
              <label className="form-label">扫描类型</label>
              <select className="form-select" value={taskType} onChange={e=>{setTaskType(e.target.value);setCustomPort('');}}>
                <option value="asset">🏠 资产扫描</option>
                <option value="vuln">🔍 漏洞扫描</option>
                <option value="weakpass">🔑 弱口令检测</option>
                <option value="quickscan">⚡ 综合扫描</option>
              <option value="report_daily">📊 日报自动推送</option>
              <option value="report_weekly">📅 周报自动推送</option>
              </select>
            </div>

            {taskType === 'vuln' && (
              <div className="form-group">
                <label className="form-label">漏洞类型</label>
                <select className="form-select" value={vulnType} onChange={e=>setVulnType(e.target.value)}>
                  {VULN_TYPES.map(t=><option key={t} value={t}>{t}</option>)}
                </select>
              </div>
            )}
            {taskType === 'weakpass' && (
              <div className="form-group">
                <label className="form-label">服务类型</label>
                <select className="form-select" value={weakService} onChange={e=>setWeakService(e.target.value)}>
                  {WEAK_SVCS.map(s=><option key={s} value={s}>{s.toUpperCase()}</option>)}
                </select>
              </div>
            )}
            {(taskType === 'vuln' || taskType === 'weakpass') && (
              <div className="form-group">
                <label className="form-label">
                  自定义端口
                  <span style={{fontSize:10,color:'var(--text3)',marginLeft:4}}>（留空使用默认）</span>
                </label>
                <input className="form-input" type="number" value={customPort}
                  onChange={e=>setCustomPort(e.target.value)}
                  placeholder="如: 8848 / 6380"/>
              </div>
            )}
          </div>

          {/* 综合扫描：选择检测项 */}
          {taskType === 'quickscan' && (
            <div className="form-group">
              <label className="form-label">
                检测项目
                <button className="btn btn-ghost" style={{marginLeft:8,padding:'1px 6px',fontSize:10}}
                  onClick={()=>setQsChecks(SCHED_CHECKS.map(c=>c.id))}>全选</button>
                <button className="btn btn-ghost" style={{marginLeft:4,padding:'1px 6px',fontSize:10}}
                  onClick={()=>setQsChecks([])}>清空</button>
              </label>
              <div style={{border:'1px solid var(--border)',borderRadius:8,padding:10,maxHeight:160,overflowY:'auto',display:'flex',flexWrap:'wrap',gap:6}}>
                {SCHED_CHECKS.map(c=>(
                  <label key={c.id} style={{display:'flex',alignItems:'center',gap:4,cursor:'pointer',fontSize:12,
                    padding:'3px 8px',borderRadius:6,border:'1px solid var(--border)',
                    background:qsChecks.includes(c.id)?'rgba(0,229,255,.12)':'transparent',
                    color:qsChecks.includes(c.id)?'var(--cyan)':'var(--text2)'}}>
                    <input type="checkbox" checked={qsChecks.includes(c.id)} onChange={()=>toggleCheck(c.id)} style={{width:12}}/>
                    {c.label}
                  </label>
                ))}
              </div>
              <div style={{fontSize:11,color:'var(--text3)',marginTop:4}}>已选 {qsChecks.length} / {SCHED_CHECKS.length} 项</div>
            </div>
          )}

          {/* 调度方式 */}
          <div className="form-group">
            <label className="form-label">调度方式</label>
            <div style={{display:'flex',gap:8}}>
              {[['interval','⏱ 按间隔'],['daily','📅 每天定时'],['weekly','🗓 每周定时']].map(([v,l])=>(
                <button key={v} onClick={()=>setSchedType(v)}
                  className={`btn ${schedType===v?'btn-primary':'btn-ghost'}`}
                  style={{flex:1,padding:'6px 0',fontSize:12,justifyContent:'center'}}>
                  {l}
                </button>
              ))}
            </div>
          </div>

          {/* 间隔设置 */}
          {schedType === 'interval' && (
            <div className="form-group">
              <label className="form-label">执行间隔</label>
              <select className="form-select" value={intervalHours} onChange={e=>setIntervalHours(e.target.value)}>
                <option value={1}>每 1 小时</option>
                <option value={2}>每 2 小时</option>
                <option value={4}>每 4 小时</option>
                <option value={6}>每 6 小时</option>
                <option value={12}>每 12 小时</option>
                <option value={24}>每天 (24h)</option>
                <option value={48}>每 2 天</option>
                <option value={72}>每 3 天</option>
                <option value={168}>每周 (7天)</option>
              </select>
            </div>
          )}

          {/* 每天/每周：指定时间 */}
          {(schedType === 'daily' || schedType === 'weekly') && (
            <div className="form-group">
              <label className="form-label">执行时间（24小时制）</label>
              <input type="time" className="form-input" value={runAtTime}
                onChange={e=>setRunAtTime(e.target.value)}
                style={{width:'auto',minWidth:140}}/>
            </div>
          )}

          {/* 每周：选择星期几 */}
          {schedType === 'weekly' && (
            <div className="form-group">
              <label className="form-label">执行日期</label>
              <div style={{display:'flex',gap:6,flexWrap:'wrap'}}>
                {WEEK_DAYS.map((d,i)=>(
                  <button key={i} onClick={()=>toggleDay(i)}
                    style={{padding:'5px 10px',fontSize:12,borderRadius:6,cursor:'pointer',
                      border:'1px solid var(--border)',transition:'all .15s',
                      background:runOnDays.includes(i)?'var(--cyan)':' var(--card2)',
                      color:runOnDays.includes(i)?'#000':'var(--text2)',
                      fontWeight:runOnDays.includes(i)?600:400}}>
                    {d}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* 目标 IP */}
          <div className="form-group">
            <label className="form-label">目标 IP（每行一个，支持 CIDR）</label>
            <textarea className="form-textarea" rows={4} value={targetsStr}
              onChange={e=>setTargetsStr(e.target.value)}
              placeholder={"192.168.1.1\n192.168.1.0/24\n10.0.0.0/8"}/>
          </div>

          <label style={{display:'flex',alignItems:'center',gap:8,cursor:'pointer',fontSize:13,marginBottom:8}}>
            <input type="checkbox" checked={enabled} onChange={e=>setEnabled(e.target.checked)}/>
            <span>创建后立即启用（将按设定时间自动运行）</span>
          </label>

          {err && <div className="alert alert-error" style={{marginBottom:8}}>{err}</div>}
        </div>

        <div style={{padding:'12px 20px',borderTop:'1px solid var(--border)',display:'flex',justifyContent:'flex-end',gap:8,flexShrink:0}}>
          <button className="btn btn-ghost" onClick={onClose}>取消</button>
          <button className="btn btn-primary" onClick={save} disabled={saving}>
            {saving?<><span className="spinner"></span> 保存中...</>:(isEdit?'保存修改':'创建任务')}
          </button>
        </div>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// SchedulerPage
// ─────────────────────────────────────────────────────────────
function SchedulerPage() {
  const [tasks,      setTasks]      = useState([]);
  const [initDone,   setInitDone]   = useState(false);
  const [refreshing, setRefreshing] = useState(false);
  const [showForm,   setShowForm]   = useState(false);
  const [editTask,   setEditTask]   = useState(null);
  const [running,    setRunning]    = useState({});
  const [msg,        setMsg]        = useState('');

  const load = useCallback(async (m=false) => {
    if(m) setRefreshing(true);
    const r = await api.get('/api/scheduler/');
    if(r?.data) setTasks(r.data);
    setInitDone(true);
    if(m) setRefreshing(false);
  }, []);

  useEffect(()=>{ load(false); }, []);

  const deleteTask = async (id, name) => {
    if(!confirm(`确认删除定时任务「${name}」？`)) return;
    const r = await api.req('DELETE', `/api/scheduler/${id}`);
    if(r?.code===200) { setTasks(p=>p.filter(t=>t.id!==id)); setMsg('✓ 已删除'); }
    else setMsg('✗ 删除失败');
  };

  const toggleEnable = async (t) => {
    const r = await api.patch(`/api/scheduler/${t.id}`, { enabled: !t.enabled });
    if(r?.code===200) setTasks(p=>p.map(x=>x.id===t.id?{...x,enabled:!t.enabled}:x));
  };

  const runNow = async (id) => {
    setRunning(p=>({...p,[id]:true})); setMsg('');
    const r = await api.post(`/api/scheduler/${id}/run`, {});
    setRunning(p=>({...p,[id]:false}));
    if(r?.code===200) {
      setMsg(r.dispatched?'✓ 任务已触发，前往「历史任务」查看进度':'✗ 触发失败（Celery Worker 是否运行？）');
      load(false);
    } else {
      setMsg('✗ 请求失败：'+(r?.detail||''));
    }
  };

  const STATUS_COLOR = { ok:'var(--green)', error:'var(--red)', pending:'var(--text3)' };

  const schedDesc = (t) => {
    if(t.schedule_type === 'daily')   return `每天 ${t.run_at_time}`;
    if(t.schedule_type === 'weekly') {
      const dStr = (t.run_on_days||[]).map(d=>WEEK_DAYS[d]||d).join('、');
      return `每周${dStr} ${t.run_at_time}`;
    }
    const h = t.interval_hours;
    return h>=168?'每周':h>=72?`每${h/24}天`:h>=24?'每天':`每${h}小时`;
  };

  const taskTypeDesc = (t) => {
    if(t.task_type==='quickscan') {
      const cnt = (t.params?.checks||[]).length;
      return `综合扫描 (${cnt}项)`;
    }
    if(t.task_type==='vuln') return `漏洞检测·${t.params?.vuln_type||''}${t.params?.port?`:${t.params.port}`:''}`;
    if(t.task_type==='weakpass') return `弱口令·${t.params?.service||''}${t.params?.port?`:${t.params.port}`:''}`;
    return TYPE_LABEL[t.task_type]||t.task_type;
  };

  return (
    <div>
      {(showForm||editTask) && (
        <SchedulerFormModal
          task={editTask}
          onClose={()=>{ setShowForm(false); setEditTask(null); }}
          onSaved={()=>load(false)}
        />
      )}

      <div className="flex-between mb-16">
        <div>
          <div style={{fontSize:22,fontFamily:'Rajdhani',fontWeight:700,letterSpacing:1}}>定时任务</div>
          <div style={{fontSize:12,color:'var(--text3)',marginTop:2}}>自动化周期性扫描 · 支持间隔 / 每天定时 / 每周定时</div>
        </div>
        <div style={{display:'flex',gap:8}}>
          <button className="btn btn-ghost" onClick={()=>load(true)} disabled={refreshing}>
            {refreshing?<span className="spinner" style={{width:13,height:13}}></span>:icons.refresh} 刷新
          </button>
          <button className="btn btn-primary" onClick={()=>{ setEditTask(null); setShowForm(true); }}>
            + 新建任务
          </button>
        </div>
      </div>

      {msg && <div className={`alert ${msg.startsWith('✓')?'alert-success':'alert-error'}`} style={{marginBottom:16}}>{msg}</div>}

      {/* 说明卡片 */}
      <div className="card section-gap" style={{background:'rgba(0,229,255,.03)',border:'1px solid rgba(0,229,255,.1)',marginBottom:20}}>
        <div style={{display:'grid',gridTemplateColumns:'repeat(4,1fr)',gap:16,padding:'2px 0'}}>
          {[
            { icon:'⏱', title:'按间隔执行', desc:'每N小时自动触发，适合持续监控' },
            { icon:'📅', title:'每天定时', desc:'指定时间点执行，如每天08:30扫描' },
            { icon:'🗓', title:'每周定时', desc:'指定星期几+时间点，适合周期报告' },
            { icon:'⚡', title:'综合扫描支持', desc:'可选全部检测项，一键全量扫描' },
          ].map(i=>(
            <div key={i.title} style={{display:'flex',gap:8,alignItems:'flex-start'}}>
              <span style={{fontSize:18,flexShrink:0}}>{i.icon}</span>
              <div>
                <div style={{fontSize:13,fontWeight:600,color:'var(--text)',marginBottom:2}}>{i.title}</div>
                <div style={{fontSize:11,color:'var(--text3)',lineHeight:1.5}}>{i.desc}</div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* 任务列表 */}
      <div className="card">
        <div className="card-header">
          <span className="card-title">任务列表（{tasks.length}）</span>
        </div>

        {!initDone ? (
          <div className="empty-state"><span className="spinner"></span></div>
        ) : tasks.length===0 ? (
          <div className="empty-state">
            <div className="empty-icon">⏰</div>
            <div style={{marginBottom:12}}>暂无定时任务</div>
            <button className="btn btn-primary" onClick={()=>setShowForm(true)}>+ 创建第一个任务</button>
          </div>
        ) : (
          <div className="table-wrap">
            <table>
              <thead><tr>
                <th>任务名称</th><th>类型</th><th>调度方式</th><th>目标数</th>
                <th>上次执行</th><th>下次执行</th><th>上次结果</th><th>次数</th><th>启用</th><th>操作</th>
              </tr></thead>
              <tbody>
                {tasks.map(t=>(
                  <tr key={t.id}>
                    <td>
                      <div style={{fontWeight:500}}>{t.name}</div>
                      <div style={{fontSize:11,color:'var(--text3)'}}>{taskTypeDesc(t)}</div>
                    </td>
                    <td><span className={`badge ${TYPE_COLOR[t.task_type]||'badge-gray'}`}>{TYPE_LABEL[t.task_type]||t.task_type}</span></td>
                    <td>
                      <span className="badge badge-blue">{SCHED_LABEL[t.schedule_type]||t.schedule_type}</span>
                      <div style={{fontSize:11,color:'var(--text3)',marginTop:2}}>{schedDesc(t)}</div>
                    </td>
                    <td className="text-dimmer">{(t.targets||[]).length} 个</td>
                    <td style={{fontSize:11,color:'var(--text3)'}}>{t.last_run||'—'}</td>
                    <td style={{fontSize:11,color:t.enabled?'var(--cyan)':'var(--text3)'}}>{t.next_run||'—'}</td>
                    <td>
                      {t.last_status==='ok'    && <span style={{fontSize:12,color:'var(--green)',fontWeight:500}}>✓ 成功</span>}
                      {t.last_status==='error' && <span style={{fontSize:12,color:'var(--red)',fontWeight:500}}>✗ 失败</span>}
                      {(!t.last_status||t.last_status==='pending') && <span className="text-dimmer">待运行</span>}
                    </td>
                    <td className="text-dimmer">{t.run_count}</td>
                    <td>
                      {/* 开关 */}
                      <div style={{width:36,height:20,borderRadius:10,cursor:'pointer',position:'relative',
                        background:t.enabled?'var(--cyan)':'var(--border)',transition:'background .2s'}}
                        onClick={()=>toggleEnable(t)}>
                        <div style={{position:'absolute',top:2,width:16,height:16,borderRadius:8,background:'#fff',
                          left:t.enabled?18:2,transition:'left .2s'}}/>
                      </div>
                    </td>
                    <td>
                      <div style={{display:'flex',gap:4}}>
                        <button className="btn btn-ghost" style={{padding:'2px 8px',fontSize:11}}
                          onClick={()=>{ setEditTask(t); setShowForm(true); }}>编辑</button>
                        <button className="btn btn-ghost"
                          style={{padding:'2px 8px',fontSize:11,color:'var(--cyan)'}}
                          onClick={()=>runNow(t.id)} disabled={running[t.id]}>
                          {running[t.id]?<span className="spinner" style={{width:10,height:10}}></span>:'▶ 立即'}
                        </button>
                        <button className="btn btn-ghost"
                          style={{padding:'2px 8px',fontSize:11,color:'var(--red)'}}
                          onClick={()=>deleteTask(t.id,t.name)}>删除</button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
