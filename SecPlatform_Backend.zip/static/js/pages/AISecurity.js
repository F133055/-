// pages/AISecurity.js - 大模型/AI安全检测页面 (MD 6.1)
function AISecurityPage() {
  const [targets,  setTargets]  = useState('');
  const [checks,   setChecks]   = useState(['prompt_injection','mcp','ai_service']);
  const [running,  setRunning]  = useState(false);
  const [results,  setResults]  = useState(null);
  const [history,  setHistory]  = useState([]);

  const CHECK_OPTIONS = [
    { id:'prompt_injection', label:'Prompt Injection',  icon:'🤖', color:'var(--red)',
      desc:'检测 AI 对话接口是否存在提示词注入漏洞，攻击者可绕过安全限制' },
    { id:'mcp',             label:'MCP 服务暴露',       icon:'🔌', color:'var(--orange)',
      desc:'检测 Model Context Protocol 服务是否未授权暴露工具调用能力' },
    { id:'ai_service',      label:'AI 服务未授权',      icon:'⚡', color:'var(--purple)',
      desc:'检测 Ollama/LocalAI/OpenAI-compatible API 是否对外无认证暴露' },
  ];

  const toggleCheck = (id) => {
    setChecks(c => c.includes(id) ? c.filter(x=>x!==id) : [...c, id]);
  };

  const run = async () => {
    const ips = targets.split(/[\n,\s]+/).filter(Boolean);
    if (!ips.length) { alert('请输入目标地址'); return; }
    if (!checks.length) { alert('请至少选择一个检测项'); return; }
    setRunning(true); setResults(null);

    const checkType = checks.length === 3 ? 'all' : checks[0];
    const r = await api.post('/api/ai-security/scan', { targets: ips, check_type: checkType });
    setRunning(false);

    if (r?.results) {
      setResults(r);
      setHistory(h => [{ time: new Date().toLocaleString('zh-CN'), targets: ips.length,
        risks: r.risk_count, total: r.total }, ...h.slice(0,9)]);
    }
  };

  const severityBadge = (s) => {
    const map = {'高':<span className="badge badge-red">高危</span>,
                 '中':<span className="badge badge-orange">中危</span>,
                 '低':<span className="badge badge-green">低危</span>,
                 '信息':<span className="badge badge-gray">信息</span>};
    return map[s] || map['信息'];
  };

  const riskResults  = results?.results?.filter(r=>r.risk)  || [];
  const infoResults  = results?.results?.filter(r=>!r.risk) || [];

  return (
    <div>
      <div className="mb-16">
        <div style={{fontSize:22,fontFamily:'Rajdhani',fontWeight:700,letterSpacing:1}}>AI 安全检测</div>
        <div style={{fontSize:12,color:'var(--text3)',marginTop:2}}>
          AI 服务安全专项扫描：检测目标系统是否存在 Prompt Injection、MCP接口暴露、AI服务未授权等风险（本工具为安全扫描器，不调用任何 AI 模型）
        </div>
      </div>

      <div style={{display:'grid',gridTemplateColumns:'1fr 300px',gap:16}}>
        {/* 左侧主体 */}
        <div>
          {/* 检测项选择 */}
          <div className="card section-gap">
            <div className="card-header"><span className="card-title">🛡 检测项目</span></div>
            <div style={{display:'grid',gridTemplateColumns:'repeat(3,1fr)',gap:10}}>
              {CHECK_OPTIONS.map(opt=>(
                <div key={opt.id} onClick={()=>toggleCheck(opt.id)}
                  style={{padding:'12px 14px',borderRadius:8,cursor:'pointer',
                    border:`2px solid ${checks.includes(opt.id)?opt.color:'var(--border)'}`,
                    background:checks.includes(opt.id)?`rgba(0,0,0,.2)`:'var(--card2)',
                    transition:'all .15s'}}>
                  <div style={{display:'flex',alignItems:'center',gap:8,marginBottom:6}}>
                    <span style={{fontSize:18}}>{opt.icon}</span>
                    <span style={{fontWeight:600,fontSize:13,color:checks.includes(opt.id)?opt.color:'var(--text)'}}>{opt.label}</span>
                    {checks.includes(opt.id)&&<span style={{marginLeft:'auto',color:opt.color,fontSize:14}}>✓</span>}
                  </div>
                  <div style={{fontSize:11,color:'var(--text3)',lineHeight:1.5}}>{opt.desc}</div>
                </div>
              ))}
            </div>
          </div>

          {/* 目标输入 */}
          <div className="card section-gap">
            <div className="card-header">
              <span className="card-title">🎯 扫描目标</span>
              <span style={{fontSize:11,color:'var(--text3)'}}>支持 IP:Port 或 http(s):// URL，每行一个，最多20个</span>
            </div>
            <textarea className="form-input" rows={5} value={targets} onChange={e=>setTargets(e.target.value)}
              placeholder={"192.168.1.100:8080\nhttps://api.example.com\nhttp://10.0.0.5:11434"}
              style={{fontFamily:'JetBrains Mono',fontSize:12,resize:'vertical'}}/>
            <div style={{marginTop:12,display:'flex',gap:8,alignItems:'center'}}>
              <button className="btn btn-primary" onClick={run} disabled={running||!targets.trim()}>
                {running ? <><span className="spinner"></span> 检测中...</> : '🚀 开始检测'}
              </button>
              {results && (
                <span style={{fontSize:12,color:'var(--text3)'}}>
                  共 {results.total} 项结果，
                  <span style={{color:'var(--red)',fontWeight:600}}>{results.risk_count} 项风险</span>
                </span>
              )}
            </div>
          </div>

          {/* 检测结果 */}
          {running && (
            <div className="card" style={{textAlign:'center',padding:40}}>
              <span className="spinner" style={{width:24,height:24,marginBottom:12}}></span>
              <div style={{color:'var(--text3)',fontSize:13,marginTop:8}}>正在检测 AI 安全风险，请稍候...</div>
            </div>
          )}

          {results && !running && (
            <div>
              {riskResults.length > 0 && (
                <div className="card section-gap" style={{borderTop:'2px solid var(--red)'}}>
                  <div className="card-header">
                    <span className="card-title" style={{color:'var(--red)'}}>⚠ 发现风险 ({riskResults.length})</span>
                  </div>
                  {riskResults.map((r,i)=>(
                    <div key={i} style={{marginBottom:12,padding:'12px 14px',background:'var(--card2)',
                      borderRadius:8,borderLeft:`3px solid var(--red)`}}>
                      <div style={{display:'flex',alignItems:'center',gap:8,marginBottom:6}}>
                        {severityBadge(r.severity)}
                        <span style={{fontWeight:600,fontSize:14}}>{r.title}</span>
                        <span style={{fontSize:11,color:'var(--text3)',marginLeft:'auto',fontFamily:'JetBrains Mono'}}>{r.target}</span>
                      </div>
                      <div style={{fontSize:13,color:'var(--text2)',marginBottom:r.evidence?6:0}}>{r.description}</div>
                      {r.evidence && (
                        <div style={{fontSize:11,fontFamily:'JetBrains Mono',color:'var(--orange)',
                          background:'rgba(245,158,11,.06)',padding:'6px 10px',borderRadius:4,
                          maxHeight:80,overflow:'auto',wordBreak:'break-all'}}>
                          {r.evidence}
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              )}

              {infoResults.length > 0 && (
                <div className="card">
                  <div className="card-header">
                    <span className="card-title">📋 信息项 ({infoResults.length})</span>
                  </div>
                  {infoResults.map((r,i)=>(
                    <div key={i} style={{display:'flex',justifyContent:'space-between',alignItems:'flex-start',
                      padding:'8px 0',borderBottom:'1px solid var(--border)'}}>
                      <div>
                        <div style={{display:'flex',gap:6,alignItems:'center',marginBottom:2}}>
                          {severityBadge(r.severity)}
                          <span style={{fontSize:13,fontWeight:500}}>{r.title}</span>
                        </div>
                        <div style={{fontSize:12,color:'var(--text3)'}}>{r.description}</div>
                      </div>
                      <span style={{fontSize:11,color:'var(--text3)',fontFamily:'JetBrains Mono',flexShrink:0,marginLeft:12}}>{r.target}</span>
                    </div>
                  ))}
                </div>
              )}

              {results.total === 0 && (
                <div className="card" style={{textAlign:'center',padding:40}}>
                  <div style={{fontSize:36,marginBottom:8}}>✅</div>
                  <div style={{color:'var(--green)',fontWeight:600}}>未发现 AI 安全风险</div>
                  <div style={{color:'var(--text3)',fontSize:12,marginTop:4}}>所有检测项均未发现问题</div>
                </div>
              )}
            </div>
          )}
        </div>

        {/* 右侧：知识说明 + 历史 */}
        <div>
          <div className="card section-gap">
            <div className="card-header"><span className="card-title">📖 风险说明</span></div>
            <div style={{fontSize:12,color:'var(--text2)',lineHeight:1.8}}>
              <div style={{marginBottom:12,paddingBottom:12,borderBottom:'1px solid var(--border)'}}>
                <div style={{fontWeight:600,color:'var(--red)',marginBottom:4}}>🤖 Prompt Injection</div>
                <div style={{color:'var(--text3)'}}>攻击者通过构造特殊输入，使 AI 模型忽略安全限制，执行未授权操作或泄露敏感信息。</div>
              </div>
              <div style={{marginBottom:12,paddingBottom:12,borderBottom:'1px solid var(--border)'}}>
                <div style={{fontWeight:600,color:'var(--orange)',marginBottom:4}}>🔌 MCP 服务暴露</div>
                <div style={{color:'var(--text3)'}}>Model Context Protocol 服务未授权暴露，攻击者可调用任意工具，包括文件读取、命令执行等高危能力。</div>
              </div>
              <div>
                <div style={{fontWeight:600,color:'var(--purple)',marginBottom:4}}>⚡ AI 服务未授权</div>
                <div style={{color:'var(--text3)'}}>Ollama/LocalAI 等本地 AI 服务未设置认证，外部可直接调用消耗算力，或用于生成恶意内容。</div>
              </div>
            </div>
          </div>

          {history.length > 0 && (
            <div className="card">
              <div className="card-header"><span className="card-title">📜 检测历史</span></div>
              {history.map((h,i)=>(
                <div key={i} style={{fontSize:11,padding:'6px 0',borderBottom:'1px solid var(--border)',color:'var(--text3)'}}>
                  <div style={{color:'var(--text2)',marginBottom:2}}>{h.time}</div>
                  <div>{h.targets} 个目标，<span style={{color:h.risks>0?'var(--red)':'var(--green)'}}>{h.risks} 项风险</span></div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
