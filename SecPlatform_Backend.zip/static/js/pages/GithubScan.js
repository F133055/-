// pages/GithubScan.js - GitHub/Gitee 信息泄露扫描页面

function GithubScanPage() {
  const [results,    setResults]    = useState([]);
  const [stats,      setStats]      = useState({});
  const [config,     setConfig]     = useState(null);
  const [initDone,   setInitDone]   = useState(false);
  const [refreshing, setRefreshing] = useState(false);
  const [keyword,    setKeyword]    = useState('');
  const [platform,   setPlatform]   = useState('github');
  const [maxResults, setMaxResults] = useState(30);
  const [scanning,   setScanning]   = useState(false);
  const [scanMsg,    setScanMsg]    = useState('');
  const [filterStat, setFilterStat] = useState('');
  const [filterPlat, setFilterPlat] = useState('');
  const [detail,     setDetail]     = useState(null);

  const load = useCallback(async (isManual = false) => {
    if (isManual) setRefreshing(true);
    const [r, s, c] = await Promise.all([
      api.get('/api/github-scan/results?limit=500'),
      api.get('/api/github-scan/stats'),
      api.get('/api/github-scan/config-check'),
    ]);
    if (r?.data) setResults(r.data);
    if (s?.data) setStats(s.data);
    if (c?.data) setConfig(c.data);
    setInitDone(true);
    if (isManual) setRefreshing(false);
  }, []);

  useEffect(() => { load(false); }, []);

  const startScan = async () => {
    if (!keyword.trim()) { setScanMsg('✗ 请输入搜索关键字'); return; }
    setScanning(true); setScanMsg('');
    const r = await api.post('/api/github-scan/start', {
      keyword: keyword.trim(), platform, max_results: Number(maxResults),
    });
    setScanning(false);
    if (r?.code === 200) {
      setScanMsg(`✓ ${r.message}，扫描在后台进行，稍后刷新查看结果`);
    } else {
      setScanMsg('✗ ' + (r?.detail || '启动失败'));
    }
  };

  const updateStatus = async (id, status) => {
    await api.patch(`/api/github-scan/${id}/status`, { status });
    setResults(prev => prev.map(i => i.id === id ? { ...i, status } : i));
  };

  const deleteOne = async (id) => {
    if (!confirm('确认删除此记录？')) return;
    const r = await api.req('DELETE', `/api/github-scan/${id}`);
    if (r?.code === 200) setResults(prev => prev.filter(i => i.id !== id));
  };

  const leakTypeColor = t => {
    const m = {
      api_key: 'var(--red)', token: 'var(--red)', password: 'var(--red)',
      private_key: 'var(--red)', access_token: 'var(--orange)',
      secret: 'var(--orange)', credential: 'var(--orange)',
    };
    return m[t] || 'var(--text2)';
  };

  const sevBadge = s => {
    const m = { 高: 'badge-red', 中: 'badge-orange', 低: 'badge-green' };
    return <span className={`badge ${m[s] || 'badge-gray'}`}>{s || '—'}</span>;
  };

  const filtered = results.filter(i => {
    if (filterStat && i.status   !== filterStat) return false;
    if (filterPlat && i.platform !== filterPlat) return false;
    return true;
  });

  const statCards = [
    { l: '发现泄露', v: stats.total,            c: 'red'    },
    { l: '高危泄露', v: stats.high_severity,    c: 'orange' },
    { l: '未处理',   v: stats.unhandled,        c: 'purple' },
    { l: '已扫关键字',v: stats.keywords_scanned,c: 'cyan'   },
  ];

  return (
    <div>
      {/* 详情弹窗 */}
      {detail && (
        <div style={{ position: 'fixed', inset: 0, zIndex: 800, display: 'flex', alignItems: 'center', justifyContent: 'center' }}
          onClick={() => setDetail(null)}>
          <div style={{ position: 'absolute', inset: 0, background: 'rgba(0,0,0,.65)' }} />
          <div style={{ position: 'relative', width: 660, maxWidth: '94vw', maxHeight: '80vh', background: 'var(--surface)', borderRadius: 12, border: '1px solid var(--border)', boxShadow: '0 20px 60px rgba(0,0,0,.5)', display: 'flex', flexDirection: 'column', overflow: 'hidden' }}
            onClick={e => e.stopPropagation()}>
            <div style={{ padding: '14px 20px', borderBottom: '1px solid var(--border)', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <div style={{ fontFamily: 'Rajdhani', fontWeight: 700, fontSize: 16 }}>泄露详情</div>
              <button onClick={() => setDetail(null)} style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--text3)', fontSize: 20 }}>✕</button>
            </div>
            <div style={{ flex: 1, overflowY: 'auto', padding: 20 }}>
              {[
                ['关键字', detail.keyword],
                ['平台', detail.platform?.toUpperCase()],
                ['仓库', <a href={detail.repo_url} target="_blank" style={{ color: 'var(--cyan)' }}>{detail.repo_name}</a>],
                ['文件路径', <span className="mono" style={{ fontSize: 12 }}>{detail.file_path}</span>],
                ['泄露类型', <span style={{ color: leakTypeColor(detail.leak_type), fontWeight: 600 }}>{detail.leak_type}</span>],
                ['危害等级', sevBadge(detail.severity)],
                ['发现时间', detail.discovered_at],
              ].map(([k, v]) => (
                <div key={k} style={{ display: 'flex', justifyContent: 'space-between', padding: '8px 0', borderBottom: '1px solid var(--border)', fontSize: 13 }}>
                  <span style={{ color: 'var(--text3)', minWidth: 80 }}>{k}</span>
                  <span style={{ color: 'var(--text2)', textAlign: 'right', maxWidth: 420, wordBreak: 'break-all' }}>{v}</span>
                </div>
              ))}
              {detail.matched_text && (
                <div style={{ marginTop: 16 }}>
                  <div style={{ fontSize: 12, color: 'var(--text3)', marginBottom: 6, textTransform: 'uppercase', letterSpacing: 1 }}>匹配内容</div>
                  <pre style={{ background: 'var(--bg)', borderRadius: 8, padding: '12px 14px', fontFamily: 'JetBrains Mono', fontSize: 12, color: 'var(--red)', lineHeight: 1.6, whiteSpace: 'pre-wrap', wordBreak: 'break-all', margin: 0 }}>
                    {detail.matched_text}
                  </pre>
                </div>
              )}
            </div>
            <div style={{ padding: '12px 20px', borderTop: '1px solid var(--border)', display: 'flex', justifyContent: 'flex-end' }}>
              <button className="btn btn-ghost" onClick={() => setDetail(null)}>关闭</button>
            </div>
          </div>
        </div>
      )}

      <div className="flex-between mb-16">
        <div>
          <div style={{ fontSize: 22, fontFamily: 'Rajdhani', fontWeight: 700, letterSpacing: 1 }}>信息收集</div>
          <div style={{ fontSize: 12, color: 'var(--text3)', marginTop: 2 }}>GitHub / Gitee 敏感信息泄露检测</div>
        </div>
        <button className="btn btn-ghost" onClick={() => load(true)} disabled={refreshing}>
          {refreshing ? <span className="spinner" style={{ width: 13, height: 13 }}></span> : '↻'} 刷新
        </button>
      </div>

      {/* Token 配置提示 */}
      {config && !config.github_configured && (
        <div className="alert alert-error" style={{ marginBottom: 16 }}>
          <div style={{ fontWeight: 600, marginBottom: 4 }}>⚠️ GitHub Token 未配置</div>
          <div style={{ fontSize: 12 }}>请在 <code>.env</code> 文件中添加 <code>GITHUB_TOKEN=ghp_xxxx</code> 后重启服务。
            <a href="https://github.com/settings/tokens" target="_blank" style={{ color: 'var(--cyan)', marginLeft: 6 }}>→ 生成 Token</a>
          </div>
        </div>
      )}

      {/* 统计卡片 */}
      <div className="stats-grid section-gap" style={{ gridTemplateColumns: 'repeat(4,1fr)' }}>
        {statCards.map(c => (
          <div key={c.l} className={`stat-card ${c.c}`}>
            <div className="stat-value">{!initDone ? '...' : (c.v ?? '-')}</div>
            <div className="stat-label">{c.l}</div>
          </div>
        ))}
      </div>

      {/* 扫描配置 */}
      <div className="card section-gap">
        <div className="card-header"><span className="card-title">🔍 发起扫描</span></div>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 140px 140px auto', gap: 12, alignItems: 'end' }}>
          <div className="form-group" style={{ marginBottom: 0 }}>
            <label className="form-label">搜索关键字（公司名/域名/项目名）</label>
            <input className="form-input" value={keyword} onChange={e => setKeyword(e.target.value)}
              onKeyDown={e => e.key === 'Enter' && startScan()}
              placeholder="如：example.com / MyCompany / api_key" />
          </div>
          <div className="form-group" style={{ marginBottom: 0 }}>
            <label className="form-label">平台</label>
            <select className="form-select" value={platform} onChange={e => setPlatform(e.target.value)}>
              <option value="github">GitHub</option>
              <option value="gitee">Gitee</option>
              <option value="all">全部</option>
            </select>
          </div>
          <div className="form-group" style={{ marginBottom: 0 }}>
            <label className="form-label">最大结果数</label>
            <input className="form-input" type="number" value={maxResults}
              onChange={e => setMaxResults(e.target.value)} min={5} max={100} />
          </div>
          <button className="btn btn-primary" style={{ padding: '8px 20px', marginBottom: 14, whiteSpace: 'nowrap' }}
            onClick={startScan} disabled={scanning}>
            {scanning ? <><span className="spinner"></span> 扫描中...</> : '⊙ 开始扫描'}
          </button>
        </div>
        {scanMsg && (
          <div className={`alert ${scanMsg.startsWith('✓') ? 'alert-success' : 'alert-error'}`}>{scanMsg}</div>
        )}
        <div style={{ fontSize: 12, color: 'var(--text3)', marginTop: 4, lineHeight: 1.7 }}>
          🔎 检测规则：API Key / Token / 密码 / 私钥 / 数据库连接串 / AWS密钥等 12 种泄露模式
        </div>
      </div>

      {/* 结果列表 */}
      <div className="card">
        <div className="card-header">
          <span className="card-title">泄露记录（{filtered.length}）</span>
          <div style={{ display: 'flex', gap: 8 }}>
            <select className="form-select" style={{ width: 90, padding: '3px 6px', fontSize: 12 }}
              value={filterPlat} onChange={e => setFilterPlat(e.target.value)}>
              <option value="">全部平台</option>
              <option value="github">GitHub</option>
              <option value="gitee">Gitee</option>
            </select>
            <select className="form-select" style={{ width: 90, padding: '3px 6px', fontSize: 12 }}
              value={filterStat} onChange={e => setFilterStat(e.target.value)}>
              <option value="">全部状态</option>
              {['未处理', '已确认', '忽略'].map(s => <option key={s} value={s}>{s}</option>)}
            </select>
          </div>
        </div>

        {!initDone ? (
          <div className="empty-state"><span className="spinner"></span></div>
        ) : filtered.length === 0 ? (
          <div className="empty-state">
            <div className="empty-icon">🔍</div>
            <div>{results.length === 0 ? '暂无记录，请发起扫描' : '无匹配记录'}</div>
          </div>
        ) : (
          <div className="table-wrap">
            <table>
              <thead>
                <tr>
                  <th>关键字</th><th>平台</th><th>仓库</th><th>文件</th>
                  <th>泄露类型</th><th>危害</th><th>状态</th><th>发现时间</th><th>操作</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map(item => (
                  <tr key={item.id} style={{ cursor: 'pointer' }} onClick={() => setDetail(item)}>
                    <td><span className="badge badge-blue">{item.keyword}</span></td>
                    <td style={{ fontSize: 12 }}>{item.platform?.toUpperCase()}</td>
                    <td style={{ maxWidth: 160, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', fontSize: 12 }}>
                      {item.repo_name}
                    </td>
                    <td style={{ maxWidth: 140, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                      <span className="mono" style={{ fontSize: 11, color: 'var(--text3)' }}>{item.file_path}</span>
                    </td>
                    <td>
                      <span style={{ fontSize: 12, color: leakTypeColor(item.leak_type), fontWeight: 500 }}>
                        {item.leak_type}
                      </span>
                    </td>
                    <td>{sevBadge(item.severity)}</td>
                    <td onClick={e => e.stopPropagation()}>
                      <select className="form-select" style={{ padding: '2px 5px', fontSize: 11, width: 'auto' }}
                        value={item.status || '未处理'}
                        onChange={e => updateStatus(item.id, e.target.value)}>
                        {['未处理', '已确认', '忽略'].map(s => <option key={s} value={s}>{s}</option>)}
                      </select>
                    </td>
                    <td className="text-dimmer" style={{ fontSize: 11 }}>{item.discovered_at}</td>
                    <td onClick={e => e.stopPropagation()}>
                      <button className="btn btn-ghost" style={{ padding: '2px 8px', fontSize: 11, color: 'var(--red)' }}
                        onClick={() => deleteOne(item.id)}>删除</button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
