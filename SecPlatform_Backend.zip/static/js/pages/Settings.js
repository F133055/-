// pages/Settings.js
function SettingsPage() {
  const [theme, setThemeState]     = useState(localStorage.getItem('sec_theme')||'dark');
  const [sysInfo, setSysInfo]       = useState(null);
  const [llmConfig, setLlmConfig]   = useState({ api_url:'', api_key:'', model:'gpt-4o-mini', enabled:false, has_key:false });
  const [llmForm, setLlmForm]       = useState({ api_url:'', api_key:'', model:'' });
  const [llmMsg, setLlmMsg]         = useState('');
  const [llmSaving, setLlmSaving]   = useState(false);
  const [llmTesting, setLlmTesting] = useState(false);

  const handleTheme = (t) => {
    setThemeState(t); applyTheme(t);
    window.dispatchEvent(new CustomEvent('themechange', {detail:t}));
  };

  useEffect(() => {
    api.get('/api/health/detailed').then(r => { if (r?.components) setSysInfo(r); });
    api.get('/api/agent/config').then(r => {
      if (r) {
        setLlmConfig(r);
        setLlmForm({ api_url: r.api_url||'', api_key: '', model: r.model||'gpt-4o-mini' });
      }
    });
  }, []);

  const saveLlm = async () => {
    setLlmSaving(true); setLlmMsg('');
    try {
      const payload = { llm_model: llmForm.model };
      if (llmForm.api_url) payload.llm_api_url = llmForm.api_url;
      if (llmForm.api_key && llmForm.api_key !== '****') payload.llm_api_key = llmForm.api_key;
      const r = await api.post('/api/agent/config', payload);
      setLlmMsg(r?.message || '保存成功');
      // Reload config
      const cfg = await api.get('/api/agent/config');
      if (cfg) { setLlmConfig(cfg); setLlmForm(f=>({...f, api_key:''})); }
    } catch(e) { setLlmMsg('保存失败: ' + e.message); }
    setLlmSaving(false);
  };

  const testLlm = async () => {
    setLlmTesting(true); setLlmMsg('');
    try {
      const r = await api.post('/api/agent/test', {});
      setLlmMsg(r?.message || (r?.success ? '✅ 连接成功' : '❌ 连接失败'));
    } catch(e) { setLlmMsg('❌ 测试失败: ' + e.message); }
    setLlmTesting(false);
  };

  const componentStatus = (s) => s==='healthy'
    ? <span className="badge badge-green">正常</span>
    : s==='unhealthy' ? <span className="badge badge-red">异常</span>
    : <span className="badge badge-gray">未知</span>;

  const MODEL_PRESETS = [
    { label:'GPT-4o Mini',  value:'gpt-4o-mini',          url:'https://api.openai.com/v1' },
    { label:'GPT-4o',       value:'gpt-4o',                url:'https://api.openai.com/v1' },
    { label:'DeepSeek V3',  value:'deepseek-chat',         url:'https://api.deepseek.com/v1' },
    { label:'通义千问',      value:'qwen-plus',             url:'https://dashscope.aliyuncs.com/compatible-mode/v1' },
    { label:'Ollama 本地',  value:'llama3.1',              url:'http://localhost:11434/v1' },
    { label:'自定义',        value:'',                      url:'' },
  ];

  return (
    <div>
      <div className="mb-16">
        <div style={{fontSize:22,fontFamily:'Rajdhani',fontWeight:700,letterSpacing:1}}>系统设置</div>
        <div style={{fontSize:12,color:'var(--text3)',marginTop:2}}>外观主题、AI 模型配置与系统状态</div>
      </div>

      {/* 主题 */}
      <div className="card section-gap">
        <div className="card-header"><span className="card-title">🎨 界面主题</span></div>
        <div style={{display:'flex',gap:16,flexWrap:'wrap'}}>
          {THEMES.map(t=>(
            <div key={t.id} onClick={()=>handleTheme(t.id)} style={{
              flex:'1 1 160px',cursor:'pointer',padding:'16px',borderRadius:10,
              border:`2px solid ${theme===t.id?'var(--cyan)':'var(--border)'}`,
              background:theme===t.id?'rgba(0,229,255,0.06)':'var(--card2)',
              transition:'all .2s',position:'relative',
            }}>
              {theme===t.id&&<span style={{position:'absolute',top:8,right:10,color:'var(--cyan)',fontSize:16}}>✓</span>}
              <div style={{fontSize:28,marginBottom:8}}>{t.icon}</div>
              <div style={{fontWeight:600,fontSize:14,color:'var(--text)',marginBottom:4}}>{t.label}</div>
              <div style={{fontSize:12,color:'var(--text3)',lineHeight:1.5}}>{t.desc}</div>
            </div>
          ))}
        </div>
      </div>

      {/* ── AI 模型配置 ── */}
      <div className="card section-gap">
        <div className="card-header">
          <span className="card-title">🤖 AI 模型配置</span>
          <span style={{fontSize:11,padding:'2px 8px',borderRadius:10,
            background: llmConfig.enabled?'rgba(34,197,94,.15)':'rgba(239,68,68,.1)',
            color: llmConfig.enabled?'var(--green)':'var(--red)'}}>
            {llmConfig.enabled ? '✅ 已配置' : '⚠️ 未配置'}
          </span>
        </div>

        <div className="alert alert-info" style={{marginBottom:16,fontSize:12}}>
          配置后可使用「AI 智能分析师」和知识库「AI 智能检索」功能。支持 OpenAI、DeepSeek、通义千问、本地 Ollama 等任意兼容接口。
        </div>

        {/* 快速选择预设 */}
        <div style={{marginBottom:16}}>
          <label className="form-label">快速选择模型</label>
          <div style={{display:'flex',gap:8,flexWrap:'wrap'}}>
            {MODEL_PRESETS.map(p=>(
              <button key={p.label} className="btn btn-ghost" style={{fontSize:11,padding:'4px 10px'}}
                onClick={()=>setLlmForm(f=>({...f,
                  model:p.value||f.model,
                  api_url:p.url||f.api_url
                }))}>
                {p.label}
              </button>
            ))}
          </div>
        </div>

        <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:12}}>
          <div className="form-group">
            <label className="form-label">API 地址 *</label>
            <input className="form-input" placeholder="https://api.openai.com/v1"
              value={llmForm.api_url} onChange={e=>setLlmForm(f=>({...f,api_url:e.target.value}))}/>
          </div>
          <div className="form-group">
            <label className="form-label">模型名称 *</label>
            <input className="form-input" placeholder="gpt-4o-mini"
              value={llmForm.model} onChange={e=>setLlmForm(f=>({...f,model:e.target.value}))}/>
          </div>
          <div className="form-group" style={{gridColumn:'1/-1'}}>
            <label className="form-label">API Key * {llmConfig.has_key && <span style={{color:'var(--green)',fontSize:11}}>(已保存，留空则不更新)</span>}</label>
            <input className="form-input" type="password"
              placeholder={llmConfig.has_key ? '已保存，如需更新请填写新 Key' : 'sk-... 或 ollama（本地部署填 ollama）'}
              value={llmForm.api_key} onChange={e=>setLlmForm(f=>({...f,api_key:e.target.value}))}/>
          </div>
        </div>

        {llmMsg && (
          <div className={`alert ${llmMsg.includes('失败')||llmMsg.includes('❌')?'alert-warning':'alert-info'}`}
            style={{marginTop:12,fontSize:12}}>{llmMsg}</div>
        )}

        <div style={{display:'flex',gap:8,marginTop:12}}>
          <button className="btn btn-primary" onClick={saveLlm} disabled={llmSaving}>
            {llmSaving?<><span className="spinner" style={{width:12,height:12}}/> 保存中</>:'💾 保存配置'}
          </button>
          <button className="btn btn-ghost" onClick={testLlm} disabled={llmTesting||!llmConfig.has_key}>
            {llmTesting?<><span className="spinner" style={{width:12,height:12}}/> 测试中</>:'🔌 测试连接'}
          </button>
        </div>
      </div>

      <div className="grid-2">
        {/* FOFA配置 */}
        <div className="card">
          <div className="card-header"><span className="card-title">🔍 FOFA API 配置</span></div>
          <div className="alert alert-info" style={{marginBottom:12,fontSize:12}}>
            在 <a href="https://fofa.info/userInfo" target="_blank" style={{color:'var(--cyan)'}}>fofa.info</a> 获取 API Key，配置到 <code style={{fontFamily:'JetBrains Mono',fontSize:11,color:'var(--cyan)'}}>/.env</code> 文件
          </div>
          <div style={{padding:'10px 12px',background:'var(--card2)',borderRadius:6,border:'1px solid var(--border)',fontFamily:'JetBrains Mono',fontSize:12,color:'var(--cyan)',lineHeight:2}}>
            FOFA_EMAIL=your@email.com<br/>
            FOFA_API_KEY=your_api_key
          </div>
        </div>

        {/* 组件状态 */}
        <div className="card">
          <div className="card-header">
            <span className="card-title">⚡ 组件状态</span>
            <button className="btn btn-ghost" style={{padding:'3px 8px',fontSize:11}} onClick={()=>{
              api.get('/api/health/detailed').then(r=>{ if(r?.components) setSysInfo(r); });
            }}>{icons.refresh}</button>
          </div>
          {sysInfo ? (
            <div>
              {[['数据库',sysInfo.components?.database?.status],['Redis',sysInfo.components?.redis?.status],['Celery',sysInfo.components?.celery?.status]].map(([n,s])=>(
                <div key={n} className="flex-between" style={{padding:'8px 0',borderBottom:'1px solid var(--border)'}}>
                  <span style={{fontSize:13}}>{n}</span>{componentStatus(s)}
                </div>
              ))}
              {sysInfo.components?.system && (
                <div style={{marginTop:12,padding:'10px',background:'var(--card2)',borderRadius:6,fontSize:12,color:'var(--text3)',lineHeight:1.8}}>
                  <div>CPU: {sysInfo.components.system.cpu_percent}%</div>
                  <div>内存: {sysInfo.components.system.memory_percent}%</div>
                  <div>磁盘: {sysInfo.components.system.disk_percent}%</div>
                </div>
              )}
            </div>
          ) : <div className="empty-state" style={{padding:'24px'}}><span className="spinner"></span></div>}
        </div>

        {/* 平台信息 */}
        <div className="card">
          <div className="card-header"><span className="card-title">📋 平台信息</span></div>
          {[
            ['版本','SecPlatform v4.3'],
            ['后端框架','FastAPI + Celery'],
            ['任务队列','Redis + Celery Worker'],
            ['数据库','MySQL (SQLAlchemy ORM)'],
            ['AI 分析','LLM（OpenAI 兼容接口）'],
            ['漏洞类型','Nacos/Swagger/MinIO/Actuator/Druid/Redis/Docker'],
            ['弱密码','SSH/MySQL/Redis/FTP/PostgreSQL/Oracle/DM/Web'],
          ].map(([k,v])=>(
            <div key={k} className="flex-between" style={{padding:'7px 0',borderBottom:'1px solid var(--border)'}}>
              <span className="text-dimmer" style={{fontSize:12}}>{k}</span>
              <span className="mono" style={{fontSize:11,color:'var(--cyan)'}}>{v}</span>
            </div>
          ))}
        </div>

        {/* 功能清单 */}
        <div className="card">
          <div className="card-header"><span className="card-title">✅ 功能完成情况</span></div>
          {[
            {icon:'✅',label:'资产扫描与对比分析'},
            {icon:'✅',label:'漏洞扫描（7种）'},
            {icon:'✅',label:'弱密码检测（SSH/MySQL/Oracle/DM/Web等11种）'},
            {icon:'✅',label:'AI 安全检测（Prompt Injection/MCP/AI服务）'},
            {icon:'✅',label:'FOFA 互联网暴露探测'},
            {icon:'✅',label:'GitHub/Gitee 信息收集'},
            {icon:'✅',label:'威胁情报关联分析'},
            {icon:'✅',label:'异常检测与告警'},
            {icon:'✅',label:'知识库 + AI 智能检索'},
            {icon:'✅',label:'设备监控 & 策略审核'},
            {icon:'✅',label:'AI 智能分析师（智能体）'},
            {icon:'✅',label:'自动报告生成与定时推送'},
          ].map(f=>(
            <div key={f.label} style={{display:'flex',alignItems:'center',gap:8,padding:'4px 0',borderBottom:'1px solid var(--border)',fontSize:12}}>
              <span>{f.icon}</span>
              <span style={{color:'var(--text2)'}}>{f.label}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
