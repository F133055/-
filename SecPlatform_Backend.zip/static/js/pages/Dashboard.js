// pages/Dashboard.js

function RiskChart({ high, total, assets }) {
  const pct    = total > 0 ? Math.round((high / total) * 100) : 0;
  const r      = 60, circ = 2 * Math.PI * r;
  const offset = circ - (pct / 100) * circ;
  const color  = pct > 50 ? 'var(--red)' : pct > 20 ? 'var(--orange)' : 'var(--green)';
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 32, padding: '8px 0' }}>
      <svg width="140" height="140" viewBox="0 0 140 140">
        <circle cx="70" cy="70" r={r} fill="none" stroke="var(--border)" strokeWidth="10" />
        <circle cx="70" cy="70" r={r} fill="none" stroke={color} strokeWidth="10"
          strokeDasharray={circ} strokeDashoffset={offset} strokeLinecap="round"
          transform="rotate(-90 70 70)" style={{ transition: 'stroke-dashoffset .8s,stroke .4s' }} />
        <text x="70" y="66" textAnchor="middle" fill={color} fontSize="22" fontWeight="700" fontFamily="Rajdhani">{pct}%</text>
        <text x="70" y="84" textAnchor="middle" fill="var(--text3)" fontSize="11">高危占比</text>
      </svg>
      <div>
        {[
          { label: '总漏洞数', value: total,  color: 'var(--orange)' },
          { label: '高危漏洞', value: high,   color: 'var(--red)',   note: '不含误报/已修复' },
          { label: '资产总数', value: assets, color: 'var(--cyan)' },
        ].map(i => (
          <div key={i.label} style={{ marginBottom: 14 }}>
            <div style={{ fontSize: 11, color: 'var(--text3)', marginBottom: 2 }}>{i.label}</div>
            <div style={{ fontSize: 24, fontFamily: 'Rajdhani', fontWeight: 700, color: i.color }}>{i.value}</div>
            {i.note && <div style={{ fontSize: 10, color: 'var(--text3)' }}>{i.note}</div>}
          </div>
        ))}
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// StatDetailModal  z-index:400  — 统计卡片详情（资产/漏洞列表）
// 点击漏洞行时调用 onVulnClick，VulnDetailModal 以 noOverlay 模式
// 浮在其上方（z:1000），两个弹窗同时可见。
// ─────────────────────────────────────────────────────────────
function StatDetailModal({ card, onClose, onVulnClick }) {
  const [data,    setData]    = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!card) return;
    setLoading(true); setData(null);
    const url = card.dataType === 'assets'
      ? '/api/assets/?limit=500' + (card.filter || '')
      : '/api/vulns/?limit=500'  + (card.filter || '');
    api.get(url).then(r => {
      let items = r?.data || [];
      if (card.clientFilter) items = items.filter(card.clientFilter);
      setData(items);
      setLoading(false);
    });
  }, [card]);

  if (!card) return null;

  const riskColor   = { 高: 'var(--red)', 中: 'var(--orange)', 低: 'var(--green)' };
  const statusColor = { ONLINE: 'var(--green)', OFFLINE: 'var(--text3)' };

  return (
    <div
      style={{ position: 'fixed', inset: 0, zIndex: 400, display: 'flex', alignItems: 'center', justifyContent: 'center' }}
      onClick={onClose}
    >
      <div style={{ position: 'absolute', inset: 0, background: 'rgba(0,0,0,.6)' }} />
      <div
        style={{
          position: 'relative', width: 760, maxWidth: '94vw', maxHeight: '82vh',
          background: 'var(--surface)', borderRadius: 12, border: '1px solid var(--border)',
          boxShadow: '0 20px 60px rgba(0,0,0,.5)', display: 'flex', flexDirection: 'column', overflow: 'hidden',
        }}
        onClick={e => e.stopPropagation()}
      >
        {/* 头部 */}
        <div style={{ padding: '16px 20px', borderBottom: '1px solid var(--border)', display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexShrink: 0 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <span style={{ fontSize: 20 }}>{card.icon}</span>
            <div>
              <div style={{ fontFamily: 'Rajdhani', fontSize: 17, fontWeight: 700, letterSpacing: 1 }}>{card.label}</div>
              <div style={{ fontSize: 12, color: 'var(--text3)', marginTop: 1 }}>
                {loading ? '加载中...' : `共 ${data?.length ?? 0} 条`}
                {card.dataType === 'vulns' && (
                  <span style={{ marginLeft: 8, color: 'var(--cyan)', fontSize: 11 }}>▶ 点击行查看详情</span>
                )}
              </div>
            </div>
          </div>
          <button onClick={onClose}
            style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--text3)', fontSize: 20, padding: '2px 8px', lineHeight: 1 }}>✕</button>
        </div>

        {/* 内容 */}
        <div style={{ flex: 1, overflowY: 'auto', padding: 16 }}>
          {loading ? (
            <div className="empty-state"><span className="spinner"></span></div>
          ) : !data?.length ? (
            <div className="empty-state"><div className="empty-icon">{card.icon}</div><div>暂无数据</div></div>
          ) : card.dataType === 'assets' ? (
            <div className="table-wrap"><table>
              <thead><tr><th>IP 地址</th><th>开放端口</th><th>状态</th><th>风险等级</th><th>最后在线</th></tr></thead>
              <tbody>{data.map(a => (
                <tr key={a.id}>
                  <td className="mono text-cyan">{a.ip_address}</td>
                  <td className="mono" style={{ fontSize: 11, color: 'var(--text2)', maxWidth: 180, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{a.open_ports || '—'}</td>
                  <td><span style={{ fontSize: 12, color: statusColor[a.status] || 'var(--text3)' }}>{a.status === 'ONLINE' ? '在线' : '离线'}</span></td>
                  <td><span style={{ fontSize: 12, color: riskColor[a.risk_level] || 'var(--text3)', fontWeight: 600 }}>{a.risk_level || '未知'}</span></td>
                  <td style={{ fontSize: 11, color: 'var(--text3)' }}>{a.last_seen || '—'}</td>
                </tr>
              ))}</tbody>
            </table></div>
          ) : (
            <div className="table-wrap"><table>
              <thead><tr><th>IP</th><th>类型</th><th>标题</th><th>危险等级</th><th>状态</th><th>发现时间</th></tr></thead>
              <tbody>{data.map(v => (
                <tr key={v.id} style={{ cursor: 'pointer', transition: 'background .12s' }}
                  onClick={() => onVulnClick && onVulnClick(v)}
                  onMouseEnter={e => e.currentTarget.style.background = 'var(--card2)'}
                  onMouseLeave={e => e.currentTarget.style.background = ''}>
                  <td className="mono text-cyan">{v.ip_address}</td>
                  <td><span className="badge badge-blue" style={{ fontSize: 10 }}>{v.vuln_type}</span></td>
                  <td style={{ fontSize: 12, color: 'var(--text2)', maxWidth: 200, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{v.title}</td>
                  <td><span style={{ fontSize: 12, color: riskColor[v.severity] || 'var(--text3)', fontWeight: 600 }}>{v.severity}</span></td>
                  <td><span style={{
                    fontSize: 11, padding: '2px 6px', borderRadius: 4,
                    background: v.status === '误报' ? 'rgba(100,100,100,.2)' : v.status === '已修复' ? 'rgba(34,197,94,.15)' : 'rgba(239,68,68,.1)',
                    color:      v.status === '误报' ? 'var(--text3)'         : v.status === '已修复' ? 'var(--green)'           : 'var(--red)',
                  }}>{v.status || '未处理'}</span></td>
                  <td style={{ fontSize: 11, color: 'var(--text3)' }}>{v.discovered_at || '—'}</td>
                </tr>
              ))}</tbody>
            </table></div>
          )}
        </div>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// DashboardPage
// ─────────────────────────────────────────────────────────────
// ── 迷你折线图组件 ─────────────────────────────────────────────
function MiniSparkline({ data=[], color='var(--cyan)', height=40, width=120, label='' }) {
  if (!data.length) return null;
  const max = Math.max(...data, 1);
  const min = Math.min(...data, 0);
  const range = max - min || 1;
  const pts = data.map((v, i) => {
    const x = (i / Math.max(data.length - 1, 1)) * (width - 10) + 5;
    const y = height - 5 - ((v - min) / range) * (height - 10);
    return `${x.toFixed(1)},${y.toFixed(1)}`;
  });
  const last = data[data.length - 1];
  return (
    <svg width={width} height={height} style={{display:'block'}}>
      <polyline points={pts.join(' ')} fill="none" stroke={color} strokeWidth="2"
        strokeLinejoin="round" strokeLinecap="round" opacity=".9"/>
      <circle cx={pts[pts.length-1].split(',')[0]} cy={pts[pts.length-1].split(',')[1]}
        r="3" fill={color}/>
    </svg>
  );
}

// ── 趋势图卡片 ─────────────────────────────────────────────────
function TrendCard({ title, data=[], color, suffix='' }) {
  const last   = data[data.length - 1] ?? 0;
  const prev   = data[data.length - 2] ?? last;
  const delta  = last - prev;
  const up     = delta > 0;
  return (
    <div className="card" style={{flex:1,minWidth:0}}>
      <div style={{display:'flex',justifyContent:'space-between',alignItems:'flex-start',marginBottom:8}}>
        <span style={{fontSize:11,color:'var(--text3)',letterSpacing:1,textTransform:'uppercase'}}>{title}</span>
        {delta !== 0 && (
          <span style={{fontSize:11,fontWeight:600,color:up?'var(--red)':'var(--green)'}}>
            {up?'↑':'↓'}{Math.abs(delta)}{suffix}
          </span>
        )}
      </div>
      <div style={{fontSize:28,fontFamily:'Rajdhani',fontWeight:700,color,lineHeight:1,marginBottom:6}}>
        {last}{suffix}
      </div>
      <MiniSparkline data={data} color={color} width={160} height={40}/>
      <div style={{display:'flex',justifyContent:'space-between',fontSize:10,color:'var(--text3)',marginTop:4}}>
        <span>7天前</span><span>今天</span>
      </div>
    </div>
  );
}

function DashboardPage({ onNavigate }) {
  const [stats,      setStats]      = useState({});
  const [tasks,      setTasks]      = useState([]);
  const [initDone,   setInitDone]   = useState(false);
  const [trendData,  setTrendData]  = useState(null);
  const [refreshing, setRefreshing] = useState(false);
  const [modalCard,  setModalCard]  = useState(null);  // StatDetailModal
  const [detailVuln, setDetailVuln] = useState(null);  // VulnDetailModal（noOverlay 模式）

  const load = useCallback(async (isManual = false) => {
    if (isManual) setRefreshing(true);
    const [s, t, tr] = await Promise.all([
      api.get('/api/assets/stats/summary'),
      api.get('/api/scan/tasks?limit=5'),
      api.get('/api/assets/stats/trend').catch(()=>null),
    ]);
    if (s?.data) setStats(s.data);
    if (t?.data) setTasks(t.data);
    if (tr?.data) setTrendData(tr.data);
    if (isManual) setRefreshing(false);
    setInitDone(true);
  }, []);

  useEffect(() => {
    load();
    const t = setInterval(() => load(false), 30000);
    return () => clearInterval(t);
  }, []);

  const statCards = [
    { label: '资产总数',  value: stats.total_assets          ?? '-', color: 'cyan',   icon: '⬡', dataType: 'assets', filter: '',                          clientFilter: null,                           desc: '全部已发现资产' },
    { label: '在线资产',  value: stats.online_assets         ?? '-', color: 'green',  icon: '◉', dataType: 'assets', filter: '&status_filter=ONLINE',     clientFilter: null,                           desc: '当前在线主机' },
    { label: '高危资产',  value: stats.high_risk_assets      ?? '-', color: 'red',    icon: '⚠', dataType: 'assets', filter: '',                          clientFilter: a => a.risk_level === '高',      desc: '风险等级为高的资产' },
    { label: '漏洞总数',  value: stats.total_vulnerabilities ?? '-', color: 'orange', icon: '◎', dataType: 'vulns',  filter: '',                          clientFilter: null,                           desc: '全部漏洞记录' },
    { label: '高危漏洞',  value: stats.high_vulnerabilities  ?? '-', color: 'purple', icon: '◆', dataType: 'vulns',  filter: '&severity=高',              clientFilter: null,                           desc: '高危（不含误报/已修复）' },
    { label: '离线资产',  value: stats.offline_assets        ?? '-', color: 'blue',   icon: '○', dataType: 'assets', filter: '&status_filter=OFFLINE',    clientFilter: null,                           desc: '当前离线主机' },
  ];

  const typeMap     = { asset: '资产扫描', vuln: '漏洞扫描', weakpass: '弱口令', fofa: 'FOFA探测' };
  const statusBadge = s => {
    const m = { SUCCESS: 'badge-green', FAILED: 'badge-red', FAILURE: 'badge-red', RUNNING: 'badge-cyan', STARTED: 'badge-cyan', PENDING: 'badge-gray' };
    const l = { SUCCESS: '完成', FAILED: '失败', FAILURE: '失败', RUNNING: '运行中', STARTED: '运行中', PENDING: '等待中' };
    return <span className={`badge ${m[s] || 'badge-gray'}`}>{l[s] || s}</span>;
  };

  return (
    <div>
      <div className="flex-between mb-16">
        <div>
          <div style={{ fontSize: 22, fontFamily: 'Rajdhani', fontWeight: 700, letterSpacing: 1 }}>安全态势总览</div>
          <div style={{ fontSize: 12, color: 'var(--text3)', marginTop: 2 }}>点击卡片查看详细数据</div>
        </div>
        <button className="btn btn-ghost" onClick={() => load(true)} disabled={refreshing}>
          {refreshing ? <><span className="spinner"></span> 刷新中</> : `${icons.refresh} 刷新`}
        </button>
      </div>

      {/* 统计卡片 */}
      <div className="stats-grid">
        {statCards.map(c => (
          <div key={c.label} className={`stat-card ${c.color}`}
            style={{ cursor: 'pointer', transition: 'transform .15s,box-shadow .15s' }}
            onClick={() => setModalCard(c)}
            onMouseEnter={e => { e.currentTarget.style.transform = 'translateY(-2px)'; e.currentTarget.style.boxShadow = '0 6px 20px rgba(0,0,0,.3)'; }}
            onMouseLeave={e => { e.currentTarget.style.transform = ''; e.currentTarget.style.boxShadow = ''; }}
            title={c.desc}>
            <div className="stat-icon">{c.icon}</div>
            <div className="stat-value">{!initDone ? '...' : c.value}</div>
            <div className="stat-label">{c.label}</div>
            <div style={{ fontSize: 10, color: 'var(--text3)', marginTop: 4, opacity: .7 }}>点击查看 →</div>
          </div>
        ))}
      </div>

      {/* ── 风险趋势图 ─────────────────────────────────────── */}
      {trendData && (
        <div style={{display:'flex',gap:12,marginBottom:20,flexWrap:'wrap'}}>
          <TrendCard title="资产总数趋势"  data={trendData.assets||[]}  color="var(--cyan)"/>
          <TrendCard title="漏洞数量趋势"  data={trendData.vulns||[]}   color="var(--orange)"/>
          <TrendCard title="高危漏洞趋势"  data={trendData.high_vulns||[]} color="var(--red)"/>
          <TrendCard title="弱密码趋势"    data={trendData.weakpass||[]} color="var(--purple)"/>
        </div>
      )}

      <div className="grid-2">
        <div className="card">
          <div className="card-header">
            <span className="card-title">最近扫描任务</span>
            <div style={{ display: 'flex', gap: 6 }}>
              <button className="btn btn-ghost" style={{ padding: '3px 8px', fontSize: 11 }}
                onClick={() => onNavigate?.('history')}>查看全部</button>
              <button className="btn btn-ghost" style={{ padding: '3px 8px', fontSize: 11 }}
                onClick={() => load()}>{icons.refresh}</button>
            </div>
          </div>
          {!tasks.length
            ? <div className="empty-state"><div className="empty-icon">◎</div><div>暂无扫描记录</div></div>
            : <div className="table-wrap"><table>
                <thead><tr><th>类型</th><th>状态</th><th>时间</th></tr></thead>
                <tbody>{tasks.map(t => (
                  <tr key={t.id} style={{ cursor: 'pointer' }} onClick={() => onNavigate?.('history')}>
                    <td>{typeMap[t.task_type] || t.task_type}</td>
                    <td>{statusBadge(t.status)}</td>
                    <td className="text-dimmer">{t.created_at}</td>
                  </tr>
                ))}</tbody>
              </table></div>
          }
        </div>

        <div className="card">
          <div className="card-header"><span className="card-title">风险分布</span></div>
          <RiskChart
            high={stats.high_vulnerabilities  || 0}
            total={stats.total_vulnerabilities || 0}
            assets={stats.total_assets         || 0}
          />
        </div>
      </div>

      {/*
        弹窗层叠逻辑：
          StatDetailModal  z-index:400  — 点击卡片打开（列表弹窗）
          VulnDetailModal  z-index:1000 — 点击漏洞行打开（详情弹窗，noOverlay 模式）

        效果：两个弹窗同时可见，VulnDetailModal 卡片浮在 StatDetailModal 列表上方。
        StatDetailModal 的深色背景已提供整体遮罩，VulnDetailModal 只渲染内容卡片，
        不再额外叠加一层暗色遮罩。

        关闭规则：
          · 点击 VulnDetailModal 外部区域 → 仅关闭详情，列表保持
          · 点击 StatDetailModal 背景     → 同时关闭列表和详情
      */}
      {modalCard && (
        <StatDetailModal
          card={modalCard}
          onClose={() => { setModalCard(null); setDetailVuln(null); }}
          onVulnClick={v => setDetailVuln(v)}     // ← 只设置详情，不关闭列表
        />
      )}
      {/* VulnDetailModal 来自 Vulns.js，传入 noOverlay=true 避免遮挡列表 */}
      {detailVuln && (
        <VulnDetailModal
          vuln={detailVuln}
          onClose={() => setDetailVuln(null)}
          noOverlay={true}
        />
      )}
    </div>
  );
}
