// pages/Agent.js — AI 智能分析师（MD 十：智能体能力）
function AgentPage() {
  const [query, setQuery]       = useState('');
  const [answer, setAnswer]     = useState('');
  const [loading, setLoading]   = useState(false);
  const [enabled, setEnabled]   = useState(null);  // null=unknown
  const [history, setHistory]   = useState([]);
  const [summaryLoading, setSummaryLoading] = useState(false);
  const chatEndRef = useRef(null);

  // Preset questions
  const PRESETS = [
    { icon: '🔍', text: '分析当前最高优先级安全风险' },
    { icon: '📋', text: '基于当前数据生成安全整改建议' },
    { icon: '🛡', text: '高危漏洞有哪些？如何修复？' },
    { icon: '📊', text: '当前资产安全评分如何？' },
    { icon: '⚠️', text: '哪些资产需要立即处理？' },
    { icon: '📝', text: '生成本周安全态势分析' },
  ];

  useEffect(() => {
    api.get('/api/agent/config').then(r => {
      setEnabled(r?.enabled ?? false);
    });
  }, []);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [history, loading]);

  const sendQuery = async (q) => {
    const text = (q || query).trim();
    if (!text || loading) return;
    setQuery('');
    const userMsg = { role: 'user', text, ts: new Date().toLocaleTimeString() };
    setHistory(h => [...h, userMsg]);
    setLoading(true);
    try {
      const r = await api.post('/api/agent/analyze', { query: text });
      setEnabled(r?.enabled !== false);
      const aiMsg = {
        role: 'ai',
        text: r?.answer || '分析失败，请检查 LLM 配置',
        ts: new Date().toLocaleTimeString(),
      };
      setHistory(h => [...h, aiMsg]);
    } catch (e) {
      setHistory(h => [...h, { role: 'ai', text: '请求失败: ' + (e.message || e), ts: new Date().toLocaleTimeString() }]);
    }
    setLoading(false);
  };

  const genReportSummary = async () => {
    setSummaryLoading(true);
    try {
      const r = await api.post('/api/agent/report-summary', {});
      if (r?.summary) {
        setHistory(h => [...h,
          { role: 'user', text: '📊 生成安全状况分析报告', ts: new Date().toLocaleTimeString() },
          { role: 'ai', text: r.summary, ts: new Date().toLocaleTimeString() },
        ]);
      }
    } catch (e) {}
    setSummaryLoading(false);
  };

  // Simple markdown-like rendering
  const renderText = (text) => {
    if (!text) return null;
    const lines = text.split('\n');
    return lines.map((line, i) => {
      if (line.startsWith('# '))  return <div key={i} style={{fontSize:16,fontWeight:700,marginTop:12,marginBottom:4,color:'var(--cyan)'}}>{line.slice(2)}</div>;
      if (line.startsWith('## ')) return <div key={i} style={{fontSize:14,fontWeight:700,marginTop:10,marginBottom:4}}>{line.slice(3)}</div>;
      if (line.startsWith('**') && line.endsWith('**')) return <div key={i} style={{fontWeight:600,marginTop:6}}>{line.slice(2,-2)}</div>;
      if (line.startsWith('- ') || line.startsWith('· ')) return <div key={i} style={{paddingLeft:16,marginBottom:2,color:'var(--text2)'}}>• {line.slice(2)}</div>;
      if (line.startsWith('> ')) return <div key={i} style={{paddingLeft:12,borderLeft:'3px solid var(--cyan)',color:'var(--text2)',margin:'4px 0',fontSize:12}}>{line.slice(2)}</div>;
      if (line.trim() === '') return <div key={i} style={{height:6}}/>;
      // Bold inline **...**
      const boldParts = line.split(/\*\*([^*]+)\*\*/g);
      if (boldParts.length > 1) {
        return <div key={i} style={{marginBottom:2}}>{boldParts.map((p,j) => j%2===1 ? <strong key={j}>{p}</strong> : p)}</div>;
      }
      return <div key={i} style={{marginBottom:2,lineHeight:1.6}}>{line}</div>;
    });
  };

  return (
    <div style={{display:'flex',flexDirection:'column',height:'calc(100vh - 140px)',gap:0}}>
      {/* Header */}
      <div style={{marginBottom:16}}>
        <div style={{fontSize:22,fontFamily:'Rajdhani',fontWeight:700,letterSpacing:1}}>🤖 AI 智能分析师</div>
        <div style={{fontSize:12,color:'var(--text3)',marginTop:2}}>
          基于平台安全数据，自动分析风险、生成建议、回答安全问题（MD §十 智能体能力）
        </div>
      </div>

      {/* LLM not configured warning */}
      {enabled === false && (
        <div className="alert alert-warning" style={{marginBottom:12,display:'flex',alignItems:'center',justifyContent:'space-between'}}>
          <span>⚠️ AI 功能未配置。请前往「系统设置」→「AI 模型配置」填写 LLM API Key</span>
          <button className="btn btn-ghost" style={{fontSize:11}} onClick={()=>window.dispatchEvent(new CustomEvent('navigate',{detail:'settings'}))}>
            前往设置 →
          </button>
        </div>
      )}

      {/* Quick actions */}
      <div style={{display:'flex',gap:8,marginBottom:12,flexWrap:'wrap'}}>
        <button className="btn btn-ghost" style={{fontSize:11,padding:'4px 10px'}}
          onClick={genReportSummary} disabled={summaryLoading}>
          {summaryLoading ? <><span className="spinner" style={{width:10,height:10}}/> 生成中…</> : '📊 一键生成安全报告'}
        </button>
        {history.length > 0 && (
          <button className="btn btn-ghost" style={{fontSize:11,padding:'4px 10px',color:'var(--text3)'}}
            onClick={()=>setHistory([])}>🗑 清空对话</button>
        )}
      </div>

      <div style={{display:'grid',gridTemplateColumns:'1fr 220px',gap:12,flex:1,minHeight:0}}>
        {/* Chat area */}
        <div className="card" style={{display:'flex',flexDirection:'column',padding:0,overflow:'hidden'}}>
          {/* Messages */}
          <div style={{flex:1,overflowY:'auto',padding:'16px 20px'}}>
            {history.length === 0 && (
              <div style={{textAlign:'center',padding:'40px 20px',color:'var(--text3)'}}>
                <div style={{fontSize:40,marginBottom:12}}>🤖</div>
                <div style={{fontSize:14,fontWeight:600,color:'var(--text2)',marginBottom:6}}>AI 安全分析师就绪</div>
                <div style={{fontSize:12}}>
                  {enabled === false
                    ? '请先在系统设置中配置 LLM API Key'
                    : '提问任何安全问题，或点击右侧快捷问题开始分析'}
                </div>
              </div>
            )}
            {history.map((msg, i) => (
              <div key={i} style={{
                display:'flex', flexDirection: msg.role==='user'?'row-reverse':'row',
                gap:10, marginBottom:16, alignItems:'flex-start',
              }}>
                <div style={{
                  width:32,height:32,borderRadius:'50%',flexShrink:0,
                  background: msg.role==='user'?'var(--cyan)':'rgba(0,229,255,.15)',
                  border: msg.role==='ai'?'1px solid var(--border2)':'none',
                  display:'flex',alignItems:'center',justifyContent:'center',
                  fontSize:14,
                }}>
                  {msg.role==='user'?'👤':'🤖'}
                </div>
                <div style={{
                  maxWidth:'82%',
                  background: msg.role==='user'?'rgba(0,229,255,.1)':'var(--card2)',
                  border:'1px solid var(--border)',
                  borderRadius: msg.role==='user'?'12px 4px 12px 12px':'4px 12px 12px 12px',
                  padding:'10px 14px',
                  fontSize:13,
                  lineHeight:1.6,
                }}>
                  {msg.role==='ai' ? renderText(msg.text) : <span>{msg.text}</span>}
                  <div style={{fontSize:10,color:'var(--text3)',marginTop:6,textAlign:'right'}}>{msg.ts}</div>
                </div>
              </div>
            ))}
            {loading && (
              <div style={{display:'flex',gap:10,alignItems:'flex-start',marginBottom:16}}>
                <div style={{width:32,height:32,borderRadius:'50%',background:'rgba(0,229,255,.15)',border:'1px solid var(--border2)',display:'flex',alignItems:'center',justifyContent:'center',fontSize:14}}>🤖</div>
                <div style={{background:'var(--card2)',border:'1px solid var(--border)',borderRadius:'4px 12px 12px 12px',padding:'12px 16px'}}>
                  <div style={{display:'flex',gap:4,alignItems:'center'}}>
                    {[0,1,2].map(j=>(
                      <div key={j} style={{width:6,height:6,borderRadius:'50%',background:'var(--cyan)',
                        animation:'pulse 1.2s ease infinite',animationDelay:`${j*0.2}s`}}/>
                    ))}
                    <span style={{fontSize:12,color:'var(--text3)',marginLeft:4}}>AI 分析中…</span>
                  </div>
                </div>
              </div>
            )}
            <div ref={chatEndRef}/>
          </div>

          {/* Input */}
          <div style={{borderTop:'1px solid var(--border)',padding:'12px 16px',display:'flex',gap:8}}>
            <input
              className="form-input"
              style={{flex:1,fontSize:13}}
              placeholder={enabled===false ? '请先配置 LLM API Key…' : '输入安全问题，如：当前最高风险是什么？'}
              value={query}
              onChange={e=>setQuery(e.target.value)}
              onKeyDown={e=>e.key==='Enter'&&!e.shiftKey&&sendQuery()}
              disabled={loading}
            />
            <button className="btn btn-primary" onClick={()=>sendQuery()} disabled={loading||!query.trim()}
              style={{padding:'0 18px',minWidth:72}}>
              {loading ? <span className="spinner" style={{width:14,height:14}}/> : '发送'}
            </button>
          </div>
        </div>

        {/* Preset questions sidebar */}
        <div style={{display:'flex',flexDirection:'column',gap:8}}>
          <div style={{fontSize:11,color:'var(--text3)',letterSpacing:1,textTransform:'uppercase',padding:'0 4px',marginBottom:4}}>快捷问题</div>
          {PRESETS.map((p, i) => (
            <button key={i} className="btn btn-ghost"
              style={{textAlign:'left',padding:'8px 12px',fontSize:12,lineHeight:1.4,height:'auto',
                border:'1px solid var(--border)',borderRadius:8,
                opacity: loading?0.6:1,
              }}
              onClick={()=>sendQuery(p.text)} disabled={loading}>
              <span style={{marginRight:6}}>{p.icon}</span>{p.text}
            </button>
          ))}
          <div style={{marginTop:8,padding:'10px 12px',background:'var(--card)',border:'1px solid var(--border)',borderRadius:8,fontSize:11,color:'var(--text3)',lineHeight:1.7}}>
            <div style={{fontWeight:600,color:'var(--text2)',marginBottom:4}}>💡 支持模型</div>
            <div>· OpenAI GPT-4/3.5</div>
            <div>· 本地 Ollama</div>
            <div>· DeepSeek / 通义</div>
            <div>· 任意兼容接口</div>
          </div>
        </div>
      </div>
    </div>
  );
}
