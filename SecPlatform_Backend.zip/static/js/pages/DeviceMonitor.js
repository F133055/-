// pages/DeviceMonitor.js - 安全设备监控页面
function DeviceMonitorPage() {
  const [devices, setDevices]   = useState([]);
  const [loading, setLoading]   = useState(false);
  const [showAdd, setShowAdd]   = useState(false);
  const [selected, setSelected] = useState(null);
  const [saving, setSaving]     = useState(false);
  const [msg, setMsg]           = useState('');
  const [checking, setChecking] = useState(null);
  const [form, setForm] = useState({
    name:'', device_type:'防火墙', ip_address:'', port:22,
    protocol:'SSH', username:'', password:'', description:''
  });

  const DEVICE_TYPES = ['防火墙','IDS/IPS','WAF','堡垒机','安全网关','VPN设备','负载均衡','交换机','路由器'];

  const load = async () => {
    setLoading(true);
    const r = await api.get('/api/devices/');
    if (r?.data) setDevices(r.data);
    setLoading(false);
  };

  useEffect(() => {
    load();
    const t = setInterval(load, 60000);
    return () => clearInterval(t);
  }, []);

  const save = async () => {
    if (!form.name.trim() || !form.ip_address.trim()) {
      setMsg('✗ 设备名称和IP不能为空');
      setTimeout(() => setMsg(''), 3000);
      return;
    }
    setSaving(true);
    const r = await api.post('/api/devices/', form);
    setSaving(false);
    if (r?.code === 200) {
      setMsg('✓ 设备添加成功');
      setShowAdd(false);
      setForm({ name:'', device_type:'防火墙', ip_address:'', port:22, protocol:'SSH', username:'', password:'', description:'' });
      load();
    } else {
      setMsg('✗ ' + (r?.detail || '添加失败'));
    }
    setTimeout(() => setMsg(''), 3000);
  };

  const del = async (id) => {
    if (!confirm('确认删除该设备？')) return;
    await api.delete(`/api/devices/${id}`);
    if (selected?.id === id) setSelected(null);
    load();
  };

  const checkStatus = async (id) => {
    setChecking(id);
    await api.post(`/api/devices/${id}/check`);
    setChecking(null);
    const r = await api.get('/api/devices/');
    if (r?.data) {
      setDevices(r.data);
      if (selected?.id === id) {
        setSelected(r.data.find(d => d.id === id) || null);
      }
    }
  };

  const statusBadge = (s) => {
    const map = {
      online:  <span className="badge badge-green">在线</span>,
      offline: <span className="badge badge-red">离线</span>,
      unknown: <span className="badge badge-gray">未知</span>,
      warning: <span className="badge badge-orange">告警</span>,
    };
    return map[s] || map.unknown;
  };

  const typeIcon = (t) => {
    const m = { '防火墙':'🔥','IDS/IPS':'🛡','WAF':'🌐','堡垒机':'🏰','安全网关':'🔗',
                'VPN设备':'🔒','负载均衡':'⚖','交换机':'🔀','路由器':'📡' };
    return m[t] || '🖥';
  };

  const total   = devices.length;
  const online  = devices.filter(d => d.status === 'online').length;
  const offline = devices.filter(d => d.status === 'offline').length;
  const warning = devices.filter(d => d.status === 'warning').length;

  return (
    <div>
      {/* 标题栏 */}
      <div className="mb-16" style={{display:'flex',justifyContent:'space-between',alignItems:'flex-start'}}>
        <div>
          <div style={{fontSize:22,fontFamily:'Rajdhani',fontWeight:700,letterSpacing:1}}>设备监控</div>
          <div style={{fontSize:12,color:'var(--text3)',marginTop:2}}>安全设备运行状态监控与性能跟踪</div>
        </div>
        <div style={{display:'flex',gap:8}}>
          <button className="btn btn-ghost" onClick={load} disabled={loading}>↻ 刷新</button>
          <button className="btn btn-primary" onClick={() => setShowAdd(true)}>+ 添加设备</button>
        </div>
      </div>

      {/* 统计卡片 */}
      <div style={{display:'grid',gridTemplateColumns:'repeat(4,1fr)',gap:12,marginBottom:16}}>
        {[
          { label:'设备总数', value:total,   color:'var(--cyan)',   icon:'🖥' },
          { label:'在线设备', value:online,  color:'var(--green)',  icon:'✅' },
          { label:'离线设备', value:offline, color:'var(--red)',    icon:'❌' },
          { label:'告警设备', value:warning, color:'var(--orange)', icon:'⚠' },
        ].map(s => (
          <div key={s.label} className="card" style={{textAlign:'center'}}>
            <div style={{fontSize:24,marginBottom:4}}>{s.icon}</div>
            <div style={{fontSize:28,fontFamily:'Rajdhani',fontWeight:700,color:s.color}}>{s.value}</div>
            <div style={{fontSize:12,color:'var(--text3)'}}>{s.label}</div>
          </div>
        ))}
      </div>

      {/* 设备列表 */}
      {loading && (
        <div style={{textAlign:'center',padding:40,color:'var(--text3)'}}>
          <span className="spinner" style={{width:20,height:20}}/> 加载中…
        </div>
      )}
      {!loading && devices.length === 0 && (
        <div style={{textAlign:'center',padding:60,color:'var(--text3)'}}>
          <div style={{fontSize:48,marginBottom:8}}>🖥</div>
          <div>暂无设备，点击「添加设备」开始监控</div>
        </div>
      )}

      <div style={{display:'grid',gridTemplateColumns:'repeat(auto-fill,minmax(320px,1fr))',gap:12}}>
        {devices.map(dev => (
          <div key={dev.id} className="card" style={{cursor:'pointer',transition:'border-color .15s'}}
            onClick={() => setSelected(dev.id === selected?.id ? null : dev)}>

            {/* 卡片头部 */}
            <div style={{display:'flex',justifyContent:'space-between',alignItems:'flex-start',marginBottom:12}}>
              <div style={{display:'flex',alignItems:'center',gap:8}}>
                <span style={{fontSize:22}}>{typeIcon(dev.device_type)}</span>
                <div>
                  <div style={{fontWeight:600,fontSize:14}}>{dev.name}</div>
                  <div style={{fontSize:11,color:'var(--text3)'}}>{dev.device_type}</div>
                </div>
              </div>
              {statusBadge(dev.status)}
            </div>

            {/* 基础信息 */}
            <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:6,fontSize:12,color:'var(--text3)',marginBottom:12}}>
              <div><span style={{color:'var(--text2)'}}>IP：</span>{dev.ip_address}</div>
              <div><span style={{color:'var(--text2)'}}>端口：</span>{dev.port}</div>
              <div><span style={{color:'var(--text2)'}}>协议：</span>{dev.protocol}</div>
              <div><span style={{color:'var(--text2)'}}>检查：</span>
                {dev.last_checked ? new Date(dev.last_checked).toLocaleTimeString('zh-CN') : '未检查'}
              </div>
            </div>

            {/* 性能指标 */}
            {dev.cpu_usage != null && (
              <div style={{marginBottom:10}}>
                {[{label:'CPU',val:dev.cpu_usage},{label:'内存',val:dev.mem_usage},{label:'磁盘',val:dev.disk_usage}].map(m => (
                  <div key={m.label} style={{marginBottom:4}}>
                    <div style={{display:'flex',justifyContent:'space-between',fontSize:11,marginBottom:2}}>
                      <span style={{color:'var(--text3)'}}>{m.label}</span>
                      <span style={{color:m.val>80?'var(--red)':m.val>60?'var(--orange)':'var(--green)'}}>{m.val}%</span>
                    </div>
                    <div style={{height:4,background:'var(--card2)',borderRadius:2,overflow:'hidden'}}>
                      <div style={{height:'100%',width:`${m.val}%`,borderRadius:2,transition:'width .5s',
                        background:m.val>80?'var(--red)':m.val>60?'var(--orange)':'var(--green)'}}/>
                    </div>
                  </div>
                ))}
              </div>
            )}

            {/* 操作按钮 */}
            <div style={{display:'flex',gap:8}}>
              <button className="btn btn-ghost" style={{flex:1,fontSize:12}}
                onClick={e => { e.stopPropagation(); checkStatus(dev.id); }}
                disabled={checking === dev.id}>
                {checking === dev.id
                  ? <><span className="spinner" style={{width:10,height:10}}/> 检测中</>
                  : '🔍 状态检测'}
              </button>
              <button className="btn btn-ghost" style={{fontSize:12,color:'var(--red)'}}
                onClick={e => { e.stopPropagation(); del(dev.id); }}>✕</button>
            </div>
          </div>
        ))}
      </div>

      {/* ── 设备详情弹窗 ── */}
      <Modal show={!!selected} onClose={() => setSelected(null)}
        title={selected ? `${typeIcon(selected.device_type)} ${selected.name}` : ''}
        width={520}>
        {selected && (
          <div>
            {/* 基础信息网格 */}
            <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:8,marginBottom:16}}>
              {[
                ['设备类型', selected.device_type],
                ['IP 地址',  selected.ip_address],
                ['端口',     selected.port],
                ['协议',     selected.protocol],
                ['运行状态', <span key="s">{statusBadge(selected.status)}</span>],
                ['上次检查', selected.last_checked
                  ? new Date(selected.last_checked).toLocaleString('zh-CN')
                  : '—'],
              ].map(([k, v]) => (
                <div key={k} style={{background:'var(--card2)',borderRadius:6,padding:'8px 12px'}}>
                  <div style={{fontSize:10,color:'var(--text3)',marginBottom:2}}>{k}</div>
                  <div style={{fontSize:13,fontWeight:500}}>{v}</div>
                </div>
              ))}
            </div>

            {/* 错误信息 */}
            {selected.last_error && (
              <div className="alert alert-error" style={{marginBottom:12,fontSize:12}}>
                {selected.last_error}
              </div>
            )}

            {/* 操作按钮 */}
            <div style={{display:'flex',gap:8}}>
              <button className="btn btn-primary"
                onClick={() => checkStatus(selected.id)}
                disabled={checking === selected.id}>
                {checking === selected.id
                  ? <><span className="spinner" style={{width:12,height:12}}/> 检测中</>
                  : '🔍 立即检测'}
              </button>
              <button className="btn btn-ghost" style={{color:'var(--red)'}}
                onClick={() => del(selected.id)}>
                🗑 删除设备
              </button>
            </div>
          </div>
        )}
      </Modal>

      {/* ── 新增设备弹窗 ── */}
      <Modal show={showAdd} onClose={() => setShowAdd(false)} title="🖥 添加安全设备" width={580}>
        <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:12}}>
          <div className="form-group" style={{gridColumn:'1/-1'}}>
            <label className="form-label">设备名称 *</label>
            <input className="form-input"
              value={form.name}
              onChange={e => setForm(f => ({...f, name: e.target.value}))}
              placeholder="如：办公区防火墙-01"/>
          </div>
          <div className="form-group">
            <label className="form-label">设备类型</label>
            <select className="form-input"
              value={form.device_type}
              onChange={e => setForm(f => ({...f, device_type: e.target.value}))}>
              {DEVICE_TYPES.map(t => <option key={t}>{t}</option>)}
            </select>
          </div>
          <div className="form-group">
            <label className="form-label">协议</label>
            <select className="form-input"
              value={form.protocol}
              onChange={e => setForm(f => ({...f, protocol: e.target.value}))}>
              {['SSH','SNMP','HTTP','HTTPS','ICMP'].map(p => <option key={p}>{p}</option>)}
            </select>
          </div>
          <div className="form-group">
            <label className="form-label">IP 地址 *</label>
            <input className="form-input"
              value={form.ip_address}
              onChange={e => setForm(f => ({...f, ip_address: e.target.value}))}
              placeholder="192.168.1.1"/>
          </div>
          <div className="form-group">
            <label className="form-label">端口</label>
            <input className="form-input" type="number"
              value={form.port}
              onChange={e => setForm(f => ({...f, port: parseInt(e.target.value) || 22}))}/>
          </div>
          <div className="form-group">
            <label className="form-label">用户名</label>
            <input className="form-input"
              value={form.username}
              onChange={e => setForm(f => ({...f, username: e.target.value}))}
              placeholder="admin"/>
          </div>
          <div className="form-group">
            <label className="form-label">密码</label>
            <input className="form-input" type="password"
              value={form.password}
              onChange={e => setForm(f => ({...f, password: e.target.value}))}
              placeholder="可选，用于状态采集"/>
          </div>
          <div className="form-group" style={{gridColumn:'1/-1'}}>
            <label className="form-label">备注</label>
            <textarea className="form-input" rows={2}
              value={form.description}
              onChange={e => setForm(f => ({...f, description: e.target.value}))}
              placeholder="设备描述、位置等信息"/>
          </div>
        </div>
        {msg && (
          <div className={`alert ${msg.startsWith('✓') ? 'alert-success' : 'alert-error'}`}
            style={{marginTop:12}}>{msg}</div>
        )}
        <div style={{display:'flex',gap:8,marginTop:12}}>
          <button className="btn btn-primary" onClick={save} disabled={saving}>
            {saving ? <><span className="spinner" style={{width:12,height:12}}/> 保存中</> : '✓ 添加设备'}
          </button>
          <button className="btn btn-ghost" onClick={() => setShowAdd(false)}>取消</button>
        </div>
      </Modal>
    </div>
  );
}
