// pages/FOFA.js
function FOFAPage() {
  const [query, setQuery] = useState('');
  const [email, setEmail] = useState('');
  const [apiKey, setApiKey] = useState('');
  const [size, setSize] = useState(50);
  const [results, setResults] = useState([]);
  const [loading, setLoading] = useState(false);
  const [msg, setMsg] = useState('');
  const [total, setTotal] = useState(0);

  const presets = [
    { label:'Nacos',      q:'app="Nacos"' },
    { label:'高危端口',   q:'port="6379" || port="27017" || port="9200"' },
    { label:'MinIO',      q:'app="minio"' },
    { label:'Swagger',    q:'title="swagger"' },
    { label:'Redis未授权',q:'port="6379" && banner="PONG"' },
    { label:'Docker API', q:'port="2375"' },
  ];

  const doSearch = async () => {
    if (!query) return;
    setLoading(true); setMsg(''); setResults([]);
    const r = await api.post('/api/fofa/search', {
      query, size,
      email: email||undefined,
      api_key: apiKey||undefined
    });
    setLoading(false);
    if (r?.data) {
      setResults(r.data); setTotal(r.total||r.data.length);
      setMsg(`✓ 返回 ${r.returned} 条，共 ${r.total} 条`);
    } else {
      setMsg('✗ ' + (r?.detail||'查询失败，请检查 API Key'));
    }
  };

  return (
    <div>
      <div className="flex-between mb-16">
        <div>
          <div style={{fontSize:22,fontFamily:'Rajdhani',fontWeight:700,letterSpacing:1}}>FOFA 互联网资产探测</div>
          <div style={{fontSize:12,color:'var(--text3)',marginTop:2}}>通过 FOFA 发现互联网暴露面</div>
        </div>
      </div>

      <div className="card section-gap">
        <div className="card-header"><span className="card-title">搜索配置</span></div>
        <div className="grid-2" style={{gap:12,marginBottom:12}}>
          <div className="form-group" style={{marginBottom:0}}>
            <label className="form-label">FOFA 邮箱（留空使用系统配置）</label>
            <input className="form-input" value={email} onChange={e=>setEmail(e.target.value)} placeholder="your@email.com"/>
          </div>
          <div className="form-group" style={{marginBottom:0}}>
            <label className="form-label">FOFA API Key</label>
            <input className="form-input" type="password" value={apiKey} onChange={e=>setApiKey(e.target.value)} placeholder="••••••••••••••"/>
          </div>
        </div>
        <div style={{display:'flex',gap:8,marginBottom:12,flexWrap:'wrap'}}>
          {presets.map(p=>(
            <button key={p.label} className="btn btn-ghost" style={{padding:'4px 10px',fontSize:11}} onClick={()=>setQuery(p.q)}>{p.label}</button>
          ))}
        </div>
        <div style={{display:'flex',gap:12,alignItems:'end'}}>
          <div style={{flex:1}} className="form-group">
            <label className="form-label">查询语句</label>
            <input className="form-input" value={query} onChange={e=>setQuery(e.target.value)} onKeyDown={e=>e.key==='Enter'&&doSearch()} placeholder='app="Nacos" && country="CN"'/>
          </div>
          <div className="form-group" style={{width:100}}>
            <label className="form-label">返回数量</label>
            <input className="form-input" type="number" value={size} onChange={e=>setSize(Number(e.target.value))} min={10} max={1000}/>
          </div>
          <button className="btn btn-primary" onClick={doSearch} disabled={loading} style={{padding:'8px 20px',marginBottom:14}}>
            {loading?<><span className="spinner"></span> 查询中...</>:'◉ 搜 索'}
          </button>
        </div>
        {msg && <div className={`alert ${msg.startsWith('✓')?'alert-success':'alert-error'}`}>{msg}</div>}
      </div>

      {results.length > 0 && (
        <div className="card">
          <div className="card-header"><span className="card-title">搜索结果 ({results.length}/{total})</span></div>
          <div className="table-wrap">
            <table>
              <thead><tr><th>IP</th><th>端口</th><th>协议</th><th>标题</th><th>国家</th><th>城市</th><th>组织</th><th>域名</th></tr></thead>
              <tbody>{results.map((r,i)=>(
                <tr key={i}>
                  <td className="mono text-cyan">{r.ip}</td>
                  <td className="mono">{r.port}</td>
                  <td><span className="badge badge-blue">{r.protocol||'—'}</span></td>
                  <td style={{maxWidth:200,overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap',fontSize:12}}>{r.title||'—'}</td>
                  <td className="text-dimmer">{r.country||'—'}</td>
                  <td className="text-dimmer">{r.city||'—'}</td>
                  <td style={{maxWidth:120,overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap',fontSize:11,color:'var(--text3)'}}>{r.org||'—'}</td>
                  <td className="text-dimmer">{r.domain||'—'}</td>
                </tr>
              ))}</tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}
