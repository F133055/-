// pages/Notify.js
function NotifyPage() {
  const channels = [
    {id:'wechat',  name:'企业微信', icon:'💬', field:'webhook_url'},
    {id:'feishu',  name:'飞书',     icon:'🚀', field:'webhook_url'},
    {id:'dingtalk',name:'钉钉',     icon:'📌', field:'webhook_url'},
    {id:'bark',    name:'Bark(iOS)',icon:'📲', field:'api_key'},
  ];
  const [configs, setConfigs] = useState({});
  const [saving, setSaving] = useState('');
  const [testing, setTesting] = useState('');
  const [msgs, setMsgs] = useState({});

  useEffect(() => {
    api.get('/api/notify/configs').then(r => {
      if (r?.data) {
        const m = {};
        r.data.forEach(c=>{ m[c.channel]={webhook_url:c.webhook_url||'',api_key:'',name:c.name,enabled:c.enabled}; });
        setConfigs(m);
      }
    });
  }, []);

  const save = async (ch) => {
    setSaving(ch);
    const c = configs[ch]||{};
    const r = await api.post('/api/notify/configs',{channel:ch,name:c.name||ch,webhook_url:c.webhook_url||null,api_key:c.api_key||null});
    setSaving('');
    setMsgs(m=>({...m,[ch]:r?.code===200?'✓ 保存成功':'✗ 保存失败'}));
    setTimeout(()=>setMsgs(m=>({...m,[ch]:''})),3000);
  };

  const test = async (ch) => {
    setTesting(ch);
    const c = configs[ch]||{};
    const r = await api.post('/api/notify/test',{channel:ch,webhook_url:c.webhook_url||null,api_key:c.api_key||null});
    setTesting('');
    setMsgs(m=>({...m,[ch]:r?.code===200?'✓ 测试成功':'✗ '+(r?.detail||'失败')}));
    setTimeout(()=>setMsgs(m=>({...m,[ch]:''})),4000);
  };

  const update = (ch, field, val) => setConfigs(c=>({...c,[ch]:{...c[ch],[field]:val}}));

  return (
    <div>
      <div className="mb-16">
        <div style={{fontSize:22,fontFamily:'Rajdhani',fontWeight:700,letterSpacing:1}}>消息通知</div>
        <div style={{fontSize:12,color:'var(--text3)',marginTop:2}}>配置扫描完成、高危告警等推送渠道</div>
      </div>
      <div className="grid-2">
        {channels.map(ch=>(
          <div key={ch.id} className="card">
            <div className="card-header">
              <span className="card-title">{ch.icon} {ch.name}</span>
              <label style={{display:'flex',alignItems:'center',gap:6,cursor:'pointer'}}>
                <input type="checkbox" checked={configs[ch.id]?.enabled!==false} onChange={e=>update(ch.id,'enabled',e.target.checked)}/>
                <span style={{fontSize:12,color:'var(--text3)'}}>启用</span>
              </label>
            </div>
            {ch.field==='webhook_url'
              ? <div className="form-group"><label className="form-label">Webhook URL</label>
                  <input className="form-input" value={configs[ch.id]?.webhook_url||''} onChange={e=>update(ch.id,'webhook_url',e.target.value)} placeholder="https://qyapi.weixin.qq.com/..."/>
                </div>
              : <div className="form-group"><label className="form-label">API Key / Device Key</label>
                  <input className="form-input" value={configs[ch.id]?.api_key||''} onChange={e=>update(ch.id,'api_key',e.target.value)} placeholder="your-device-key"/>
                </div>
            }
            {msgs[ch.id] && <div className={`alert ${msgs[ch.id].startsWith('✓')?'alert-success':'alert-error'}`}>{msgs[ch.id]}</div>}
            <div className="flex gap-8">
              <button className="btn btn-primary" onClick={()=>save(ch.id)} disabled={saving===ch.id}>
                {saving===ch.id?<><span className="spinner"></span></>:'保存'}
              </button>
              <button className="btn btn-ghost" onClick={()=>test(ch.id)} disabled={testing===ch.id}>
                {testing===ch.id?<><span className="spinner"></span> 测试中</>:'发送测试'}
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
