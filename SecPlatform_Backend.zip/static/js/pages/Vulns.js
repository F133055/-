// pages/Vulns.js

// ─────────────────────────────────────────────────────────────
// VulnDetailModal
// noOverlay=true 时不渲染半透明遮罩（供 Dashboard 双层弹窗使用）
// ─────────────────────────────────────────────────────────────
function VulnDetailModal({ vuln, onClose, noOverlay = false }) {
  if (!vuln) return null;
  const severityColor = { 高: 'var(--red)', 严重: 'var(--red)', 中: 'var(--orange)', 低: 'var(--green)' };

  return (
    <div
      style={{ position: 'fixed', inset: 0, zIndex: 1000, display: 'flex', alignItems: 'center', justifyContent: 'center' }}
      onClick={onClose}
    >
      {/* 背景遮罩：双层模式下隐藏，避免盖住 StatDetailModal */}
      {!noOverlay && (
        <div style={{ position: 'absolute', inset: 0, background: 'rgba(0,0,0,.65)' }} />
      )}

      <div
        style={{
          position: 'relative', width: 640, maxWidth: '94vw', maxHeight: '80vh',
          background: 'var(--surface)', borderRadius: 12, border: '1px solid var(--border)',
          boxShadow: '0 24px 70px rgba(0,0,0,.7)', display: 'flex', flexDirection: 'column', overflow: 'hidden',
        }}
        onClick={e => e.stopPropagation()}
      >
        {/* Header */}
        <div style={{ padding: '16px 20px', borderBottom: '1px solid var(--border)', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <span style={{ fontSize: 18 }}>🔍</span>
            <div>
              <div style={{ fontWeight: 600, fontSize: 15 }}>{vuln.title}</div>
              <div style={{ fontSize: 12, color: 'var(--text3)', marginTop: 2 }}>
                <span className="mono" style={{ color: 'var(--cyan)' }}>{vuln.ip_address}</span>
                <span style={{ margin: '0 8px', opacity: 0.4 }}>·</span>
                <span className="badge badge-blue" style={{ fontSize: 10 }}>{vuln.vuln_type}</span>
              </div>
            </div>
          </div>
          <button onClick={onClose} style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--text3)', fontSize: 18, lineHeight: 1 }}>✕</button>
        </div>

        {/* Body */}
        <div style={{ flex: 1, overflowY: 'auto', padding: 20 }}>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, marginBottom: 16 }}>
            {[
              ['严重程度', <span style={{ color: severityColor[vuln.severity] || 'var(--text2)', fontWeight: 600 }}>{vuln.severity}</span>],
              ['处理状态', vuln.status],
              ['发现时间', vuln.discovered_at],
              ['IP 地址',  <span className="mono">{vuln.ip_address}</span>],
            ].map(([label, val]) => (
              <div key={label} style={{ background: 'var(--bg)', borderRadius: 8, padding: '10px 14px' }}>
                <div style={{ fontSize: 11, color: 'var(--text3)', marginBottom: 4 }}>{label}</div>
                <div style={{ fontSize: 13, color: 'var(--text1)' }}>{val}</div>
              </div>
            ))}
          </div>

          {vuln.description && (
            <div style={{ marginBottom: 12 }}>
              <div style={{ fontSize: 12, color: 'var(--text3)', marginBottom: 6, textTransform: 'uppercase', letterSpacing: 1 }}>检测结果</div>
              <div style={{
                background: 'var(--bg)', borderRadius: 8, padding: '12px 14px',
                fontFamily: 'JetBrains Mono, monospace', fontSize: 13, lineHeight: 1.6, wordBreak: 'break-all',
                color: (vuln.description.includes('发现') || vuln.description.includes('弱口令')) ? 'var(--red)' : 'var(--text2)',
              }}>
                {vuln.description}
              </div>
            </div>
          )}

          {vuln.evidence && (
            <div style={{ marginBottom: 12 }}>
              <div style={{ fontSize: 12, color: 'var(--text3)', marginBottom: 6, textTransform: 'uppercase', letterSpacing: 1 }}>原始证据 / 验证信息</div>
              <pre style={{
                background: 'var(--bg)', borderRadius: 8, padding: '12px 14px',
                fontFamily: 'JetBrains Mono, monospace', fontSize: 12, color: 'var(--text2)',
                lineHeight: 1.6, overflowX: 'auto', whiteSpace: 'pre-wrap', wordBreak: 'break-all', margin: 0,
              }}>
                {vuln.evidence}
              </pre>
            </div>
          )}

          {!vuln.description && !vuln.evidence && (
            <div style={{ color: 'var(--text3)', fontSize: 13, textAlign: 'center', padding: '20px 0' }}>暂无详细信息</div>
          )}
        </div>

        {/* Footer */}
        <div style={{ padding: '12px 20px', borderTop: '1px solid var(--border)', display: 'flex', justifyContent: 'flex-end', gap: 8 }}>
          <button className="btn btn-ghost" onClick={onClose}>关闭</button>
        </div>
      </div>
    </div>
  );
}


// ─────────────────────────────────────────────────────────────
// VulnsPage
// ─────────────────────────────────────────────────────────────
function VulnsPage() {
  const [vulns,          setVulns]          = useState([]);
  const [stats,          setStats]          = useState({});
  const [initDone,       setInitDone]       = useState(false);
  const [refreshing,     setRefreshing]     = useState(false);
  const [filterSeverity, setFilterSeverity] = useState('');
  const [scanTargets,    setScanTargets]    = useState('');
  const [scanType,       setScanType]       = useState('nacos');
  const [scanning,       setScanning]       = useState(false);
  const [scanMsg,        setScanMsg]        = useState('');
  const [detailVuln,     setDetailVuln]     = useState(null);
  // 批量操作
  const [selected,       setSelected]       = useState([]);
  const [batchMsg,       setBatchMsg]       = useState('');
  const [batchWorking,   setBatchWorking]   = useState(false);

  const load = useCallback(async (isManual = false) => {
    if (isManual) setRefreshing(true);
    const [v, s] = await Promise.all([
      api.get('/api/vulns/?limit=500'),
      api.get('/api/vulns/stats'),
    ]);
    if (v?.data) setVulns(v.data);
    if (s?.data) setStats(s.data);
    setInitDone(true);
    if (isManual) { setRefreshing(false); setSelected([]); }
  }, []);

  useEffect(() => {
    load(false);
    const t = setInterval(() => load(false), 30000);
    return () => clearInterval(t);
  }, []);

  const startVulnScan = async () => {
    const ips = scanTargets.split(/[\n,\s]+/).filter(Boolean);
    if (!ips.length) return;
    setScanning(true); setScanMsg('');
    const r = await api.post('/api/scan/vuln', { targets: ips, vuln_type: scanType });
    setScanning(false);
    setScanMsg(r?.task_id ? `✓ 任务已下发 (${r.task_id.slice(0,8)}...)，完成后刷新查看` : `✗ 失败：${r?.detail||''}`);
  };

  // 删除单条
  const deleteOne = async (id) => {
    if (!confirm('确认删除该漏洞记录？')) return;
    const r = await api.req('DELETE', `/api/vulns/${id}`);
    if (r?.code === 200) {
      setVulns(prev => prev.filter(v => v.id !== id));
      setSelected(prev => prev.filter(i => i !== id));
    } else {
      alert('删除失败：' + (r?.detail || JSON.stringify(r)));
    }
  };

  // 批量删除
  const batchDelete = async () => {
    if (!selected.length) return;
    if (!confirm(`确认删除所选 ${selected.length} 条漏洞记录？此操作不可恢复。`)) return;
    setBatchWorking(true); setBatchMsg('');
    const r = await api.req('DELETE', '/api/vulns/batch', { ids: selected });
    setBatchWorking(false);
    if (r?.code === 200) {
      setBatchMsg(`✓ 已删除 ${r.deleted_count} 条`);
      setVulns(prev => prev.filter(v => !selected.includes(v.id)));
      setSelected([]);
    } else {
      setBatchMsg('✗ 批量删除失败：' + (r?.detail || JSON.stringify(r)));
    }
  };

  // 批量改状态
  const batchStatus = async (status) => {
    if (!selected.length) return;
    setBatchWorking(true); setBatchMsg('');
    const r = await api.patch('/api/vulns/batch/status', { ids: selected, status });
    setBatchWorking(false);
    if (r?.code === 200) {
      setBatchMsg(`✓ 已将 ${r.updated_count} 条标记为「${status}」`);
      setVulns(prev => prev.map(v => selected.includes(v.id) ? { ...v, status } : v));
      setSelected([]);
    } else {
      setBatchMsg('✗ 操作失败');
    }
  };

  const severityBadge = s => {
    const m = { 高: 'badge-red', 严重: 'badge-red', 中: 'badge-orange', 低: 'badge-green', 信息: 'badge-blue' };
    return <span className={`badge ${m[s] || 'badge-gray'}`}>{s}</span>;
  };
  const statusColor = s => ({ 未处理: 'var(--red)', 处理中: 'var(--orange)', 已修复: 'var(--green)', 误报: 'var(--text3)' }[s] || 'var(--text2)');

  const VULN_TYPES = [
    { value: 'nacos',        label: 'Nacos 未授权访问' },
    { value: 'swagger',      label: 'Swagger 信息泄露' },
    { value: 'minio',        label: 'MinIO 未授权访问' },
    { value: 'actuator',     label: 'Spring Actuator 暴露' },
    { value: 'druid',        label: 'Druid 监控页暴露' },
    { value: 'redis_unauth', label: 'Redis 未授权访问' },
    { value: 'docker',       label: 'Docker API 未授权' },
  ];

  const statCards = [
    { l: '全部',   v: stats.total,     c: 'cyan',   filter: '' },
    { l: '高危',   v: stats.high,      c: 'red',    filter: '高' },
    { l: '中危',   v: stats.medium,    c: 'orange', filter: '中' },
    { l: '低危',   v: stats.low,       c: 'green',  filter: '低' },
    { l: '未处理', v: stats.unhandled, c: 'purple', filter: '__unhandled__' },
  ];

  const filteredVulns = filterSeverity === '__unhandled__'
    ? vulns.filter(v => v.status === '未处理')
    : filterSeverity ? vulns.filter(v => v.severity === filterSeverity) : vulns;

  const allSelected  = filteredVulns.length > 0 && filteredVulns.every(v => selected.includes(v.id));
  const someSelected = selected.length > 0;

  const toggleAll   = () => setSelected(allSelected ? [] : filteredVulns.map(v => v.id));
  const toggleOne   = id => setSelected(s => s.includes(id) ? s.filter(i => i !== id) : [...s, id]);

  return (
    <div>
      {detailVuln && <VulnDetailModal vuln={detailVuln} onClose={() => setDetailVuln(null)} />}
      <QSBanner />

      <div className="flex-between mb-16">
        <div>
          <div style={{ fontSize: 22, fontFamily: 'Rajdhani', fontWeight: 700, letterSpacing: 1 }}>漏洞管理</div>
          <div style={{ fontSize: 12, color: 'var(--text3)', marginTop: 2 }}>共 {stats.total || 0} 个漏洞</div>
        </div>
        <button className="btn btn-ghost" onClick={() => load(true)} disabled={refreshing}>
          {refreshing ? <span className="spinner" style={{ width: 13, height: 13 }}></span> : icons.refresh} 刷新
        </button>
      </div>

      {/* 统计卡片 */}
      <div className="stats-grid section-gap" style={{ gridTemplateColumns: 'repeat(5,1fr)' }}>
        {statCards.map(card => {
          const isActive = filterSeverity === card.filter ||
            (card.filter === '__unhandled__' && filterSeverity === '__unhandled__');
          return (
            <div key={card.l} className={`stat-card ${card.c}`}
              style={{ cursor: 'pointer', outline: isActive ? `2px solid var(--${card.c})` : 'none', outlineOffset: 2 }}
              onClick={() => {
                setFilterSeverity(card.filter === '__unhandled__' ? '__unhandled__' : card.filter);
                setSelected([]);
                setBatchMsg('');
              }}>
              <div className="stat-value">{card.v ?? '-'}</div>
              <div className="stat-label">{card.l}</div>
              {isActive && <div style={{ fontSize: 10, color: `var(--${card.c})`, marginTop: 2 }}>▶ 已过滤</div>}
            </div>
          );
        })}
      </div>

      {/* 扫描 + 类型说明 */}
      <div className="grid-2 section-gap">
        <div className="card">
          <div className="card-header"><span className="card-title">发起漏洞扫描</span></div>
          <div className="form-group">
            <label className="form-label">扫描类型</label>
            <select className="form-select" value={scanType} onChange={e => setScanType(e.target.value)}>
              {VULN_TYPES.map(t => <option key={t.value} value={t.value}>{t.label}</option>)}
            </select>
          </div>
          <div className="form-group">
            <label className="form-label">目标 IP / URL（每行一个）</label>
            <textarea className="form-textarea" value={scanTargets}
              onChange={e => setScanTargets(e.target.value)}
              placeholder={"192.168.1.1\nhttps://example.com"} rows={3} />
          </div>
          {scanMsg && <div className={`alert ${scanMsg.startsWith('✓') ? 'alert-success' : 'alert-error'}`}>{scanMsg}</div>}
          <button className="btn btn-primary" onClick={startVulnScan} disabled={scanning}>
            {scanning ? <><span className="spinner"></span> 扫描中...</> : '⚠ 开始漏洞扫描'}
          </button>
        </div>
        <div className="card">
          <div className="card-header"><span className="card-title">支持的漏洞类型</span></div>
          <div style={{ fontSize: 13, color: 'var(--text2)', lineHeight: 2 }}>
            {VULN_TYPES.map(t => <div key={t.value}>🔍 {t.label}</div>)}
            <div style={{ marginTop: 8, color: 'var(--text3)', fontSize: 12 }}>
              💡 可在「综合扫描」页批量检测全部类型
            </div>
          </div>
        </div>
      </div>

      {/* 漏洞列表 */}
      <div className="card">
        <div className="card-header">
          <span className="card-title">
            漏洞列表
            {filterSeverity === '__unhandled__' && ' (未处理)'}
            {filterSeverity && filterSeverity !== '__unhandled__' && ` (${filterSeverity}危)`}
          </span>
          <div style={{ display: 'flex', gap: 6, alignItems: 'center', flexWrap: 'wrap' }}>
            {filterSeverity && (
              <button className="btn btn-ghost" style={{ padding: '3px 8px', fontSize: 11 }}
                onClick={() => { setFilterSeverity(''); setSelected([]); setBatchMsg(''); }}>清除过滤</button>
            )}
            {someSelected && (
              <>
                <span style={{ fontSize: 12, color: 'var(--text3)' }}>已选 {selected.length} 条</span>
                {/* 批量改状态 */}
                <select className="form-select" style={{ padding: '3px 6px', fontSize: 11, width: 'auto' }}
                  defaultValue=""
                  onChange={async e => {
                    if (e.target.value) { await batchStatus(e.target.value); e.target.value = ''; }
                  }}
                  disabled={batchWorking}>
                  <option value="" disabled>批量改状态...</option>
                  {['未处理', '处理中', '已修复', '误报'].map(s => <option key={s} value={s}>{s}</option>)}
                </select>
                {/* 批量删除 */}
                <button className="btn btn-ghost"
                  style={{ padding: '3px 10px', fontSize: 11, color: 'var(--red)', borderColor: 'rgba(239,68,68,.3)' }}
                  onClick={batchDelete} disabled={batchWorking}>
                  {batchWorking
                    ? <span className="spinner" style={{ width: 10, height: 10 }}></span>
                    : `🗑 删除所选 (${selected.length})`}
                </button>
              </>
            )}
          </div>
        </div>

        {batchMsg && (
          <div className={`alert ${batchMsg.startsWith('✓') ? 'alert-success' : 'alert-error'}`}
            style={{ margin: '0 0 8px' }}>{batchMsg}</div>
        )}

        {!initDone ? (
          <div className="empty-state"><span className="spinner"></span></div>
        ) : filteredVulns.length === 0 ? (
          <div className="empty-state"><div className="empty-icon">✓</div><div>暂无漏洞记录</div></div>
        ) : (
          <div className="table-wrap">
            <table>
              <thead>
                <tr>
                  <th style={{ width: 32 }}>
                    <input type="checkbox" checked={allSelected} onChange={toggleAll} />
                  </th>
                  <th>IP</th><th>类型</th><th>标题</th><th>严重程度</th><th>状态</th><th>发现时间</th><th>操作</th>
                </tr>
              </thead>
              <tbody>
                {filteredVulns.map(v => (
                  <tr key={v.id}
                    style={{ cursor: 'pointer', background: selected.includes(v.id) ? 'rgba(0,229,255,.04)' : '' }}
                    onClick={() => setDetailVuln(v)}>
                    <td onClick={e => e.stopPropagation()}>
                      <input type="checkbox" checked={selected.includes(v.id)} onChange={() => toggleOne(v.id)} />
                    </td>
                    <td className="mono text-cyan" onClick={e => e.stopPropagation()}>{v.ip_address}</td>
                    <td><span className="badge badge-blue">{v.vuln_type}</span></td>
                    <td style={{ maxWidth: 200, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{v.title}</td>
                    <td>{severityBadge(v.severity)}</td>
                    <td style={{ color: statusColor(v.status), fontSize: 12, fontWeight: 500 }}>{v.status}</td>
                    <td className="text-dimmer">{v.discovered_at}</td>
                    <td onClick={e => e.stopPropagation()}>
                      <div style={{ display: 'flex', gap: 4, alignItems: 'center' }}>
                        <button className="btn btn-ghost" style={{ padding: '2px 7px', fontSize: 11 }}
                          onClick={() => setDetailVuln(v)}>详情</button>
                        <select className="form-select" style={{ padding: '2px 5px', fontSize: 11, width: 'auto' }}
                          value={v.status}
                          onChange={async e => {
                            await api.patch(`/api/vulns/${v.id}/status`, { status: e.target.value });
                            load(false);
                          }}>
                          {['未处理', '处理中', '已修复', '误报'].map(s => <option key={s} value={s}>{s}</option>)}
                        </select>
                        <button className="btn btn-ghost"
                          style={{ padding: '2px 7px', fontSize: 11, color: 'var(--red)' }}
                          onClick={() => deleteOne(v.id)}>删除</button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
