// pages/ThreatIntel.js - 威胁情报页面

function ThreatIntelPage() {
  const [list,       setList]       = useState([]);
  const [stats,      setStats]      = useState({});
  const [initDone,   setInitDone]   = useState(false);
  const [refreshing, setRefreshing] = useState(false);
  const [scanning,   setScanning]   = useState(false);
  const [scanMsg,    setScanMsg]    = useState('');
  const [batchLimit, setBatchLimit] = useState(200);
  const [cveQuery,   setCveQuery]   = useState('');
  const [cveResult,  setCveResult]  = useState(null);
  const [cveLoading, setCveLoading] = useState(false);
  const [filterSev,  setFilterSev]  = useState('');
  const [filterStat, setFilterStat] = useState('');
  const [selected,   setSelected]   = useState([]);

  const load = useCallback(async (isManual = false) => {
    if (isManual) setRefreshing(true);
    const [l, s] = await Promise.all([
      api.get('/api/threat-intel/list?limit=500'),
      api.get('/api/threat-intel/stats'),
    ]);
    if (l?.data) setList(l.data);
    if (s?.data) setStats(s.data);
    setInitDone(true);
    if (isManual) { setRefreshing(false); setSelected([]); }
  }, []);

  useEffect(() => { load(false); }, []);

  // 批量扫描
  const batchScan = async () => {
    setScanning(true); setScanMsg('');
    const r = await api.post('/api/threat-intel/batch-scan', { limit: Number(batchLimit) });
    setScanning(false);
    if (r?.code === 200) {
      setScanMsg(`✓ ${r.message}`);
      load(false);
    } else {
      setScanMsg('✗ 扫描失败：' + (r?.detail || ''));
    }
  };

  // 手动查询CVE
  const queryCve = async () => {
    if (!cveQuery.trim()) return;
    setCveLoading(true); setCveResult(null);
    const r = await api.post('/api/threat-intel/query-cve', { cve_id: cveQuery.trim() });
    setCveLoading(false);
    if (r?.code === 200) setCveResult(r.data);
    else setCveResult({ error: r?.detail || '查询失败' });
  };

  // 更新状态
  const updateStatus = async (id, status) => {
    await api.patch(`/api/threat-intel/${id}/status`, { status });
    setList(prev => prev.map(i => i.id === id ? { ...i, status } : i));
  };

  // 删除
  const deleteOne = async (id) => {
    if (!confirm('确认删除此情报记录？')) return;
    const r = await api.req('DELETE', `/api/threat-intel/${id}`);
    if (r?.code === 200) {
      setList(prev => prev.filter(i => i.id !== id));
      setSelected(prev => prev.filter(x => x !== id));
    }
  };

  const sevColor = { 高: 'var(--red)', 严重: 'var(--red)', 中: 'var(--orange)', 低: 'var(--green)' };
  const sevBadge = s => {
    const m = { 高: 'badge-red', 严重: 'badge-red', 中: 'badge-orange', 低: 'badge-green' };
    return <span className={`badge ${m[s] || 'badge-gray'}`}>{s || '未知'}</span>;
  };

  const filtered = list.filter(i => {
    if (filterSev  && i.severity !== filterSev)  return false;
    if (filterStat && i.status   !== filterStat) return false;
    return true;
  });

  const allSel = filtered.length > 0 && filtered.every(i => selected.includes(i.id));

  const statCards = [
    { l: '关联情报', v: stats.total,            c: 'cyan'   },
    { l: '高危情报', v: stats.high_severity,    c: 'red'    },
    { l: '未处理',   v: stats.unhandled,        c: 'orange' },
    { l: '受影响资产',v: stats.affected_assets, c: 'purple' },
  ];

  return (
    <div>
      <div className="flex-between mb-16">
        <div>
          <div style={{ fontSize: 22, fontFamily: 'Rajdhani', fontWeight: 700, letterSpacing: 1 }}>威胁情报</div>
          <div style={{ fontSize: 12, color: 'var(--text3)', marginTop: 2 }}>CVE 关联分析 · 资产风险识别</div>
        </div>
        <button className="btn btn-ghost" onClick={() => load(true)} disabled={refreshing}>
          {refreshing ? <span className="spinner" style={{ width: 13, height: 13 }}></span> : '↻'} 刷新
        </button>
      </div>

      {/* 统计卡片 */}
      <div className="stats-grid section-gap" style={{ gridTemplateColumns: 'repeat(4,1fr)' }}>
        {statCards.map(c => (
          <div key={c.l} className={`stat-card ${c.c}`}>
            <div className="stat-value">{!initDone ? '...' : (c.v ?? '-')}</div>
            <div className="stat-label">{c.l}</div>
          </div>
        ))}
      </div>

      <div className="grid-2 section-gap">
        {/* 批量扫描 */}
        <div className="card">
          <div className="card-header"><span className="card-title">🔍 批量 CVE 关联扫描</span></div>
          <div style={{ fontSize: 13, color: 'var(--text2)', marginBottom: 12, lineHeight: 1.7 }}>
            自动对所有在线资产进行 CVE 关联分析，识别已知漏洞风险。
          </div>
          <div className="form-group">
            <label className="form-label">最多扫描资产数</label>
            <input className="form-input" type="number" value={batchLimit}
              onChange={e => setBatchLimit(e.target.value)} min={10} max={1000} />
          </div>
          {scanMsg && (
            <div className={`alert ${scanMsg.startsWith('✓') ? 'alert-success' : 'alert-error'}`} style={{ marginBottom: 8 }}>
              {scanMsg}
            </div>
          )}
          <button className="btn btn-primary" onClick={batchScan} disabled={scanning}>
            {scanning ? <><span className="spinner"></span> 扫描中...</> : '⚡ 开始批量扫描'}
          </button>
        </div>

        {/* CVE 查询 */}
        <div className="card">
          <div className="card-header"><span className="card-title">🔎 手动查询 CVE</span></div>
          <div className="form-group">
            <label className="form-label">CVE 编号</label>
            <div style={{ display: 'flex', gap: 8 }}>
              <input className="form-input" style={{ flex: 1 }} value={cveQuery}
                onChange={e => setCveQuery(e.target.value)}
                onKeyDown={e => e.key === 'Enter' && queryCve()}
                placeholder="如：CVE-2021-44228" />
              <button className="btn btn-primary" style={{ padding: '6px 16px', whiteSpace: 'nowrap' }}
                onClick={queryCve} disabled={cveLoading}>
                {cveLoading ? <span className="spinner"></span> : '查询'}
              </button>
            </div>
          </div>
          {cveResult && (
            <div style={{ marginTop: 8 }}>
              {cveResult.error ? (
                <div className="alert alert-error">{cveResult.error}</div>
              ) : (
                <div style={{ background: 'var(--bg)', borderRadius: 8, padding: '12px 14px', fontSize: 13 }}>
                  <div style={{ fontWeight: 600, color: 'var(--cyan)', marginBottom: 6 }}>{cveResult.cve_id}</div>
                  <div style={{ color: 'var(--text2)', marginBottom: 4 }}>{cveResult.title}</div>
                  <div style={{ display: 'flex', gap: 12, fontSize: 12, color: 'var(--text3)' }}>
                    <span>CVSS: <b style={{ color: cveResult.cvss_score >= 7 ? 'var(--red)' : 'var(--orange)' }}>{cveResult.cvss_score}</b></span>
                    <span>危害: {sevBadge(cveResult.severity)}</span>
                    <span>来源: {cveResult.source}</span>
                  </div>
                  {cveResult.description && (
                    <div style={{ marginTop: 8, fontSize: 12, color: 'var(--text3)', lineHeight: 1.6 }}>
                      {cveResult.description}
                    </div>
                  )}
                </div>
              )}
            </div>
          )}
        </div>
      </div>

      {/* 情报列表 */}
      <div className="card">
        <div className="card-header">
          <span className="card-title">情报列表</span>
          <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
            <select className="form-select" style={{ width: 100, padding: '3px 6px', fontSize: 12 }}
              value={filterSev} onChange={e => setFilterSev(e.target.value)}>
              <option value="">全部危害</option>
              {['高', '中', '低'].map(s => <option key={s} value={s}>{s}</option>)}
            </select>
            <select className="form-select" style={{ width: 100, padding: '3px 6px', fontSize: 12 }}
              value={filterStat} onChange={e => setFilterStat(e.target.value)}>
              <option value="">全部状态</option>
              {['未处理', '已确认', '误报'].map(s => <option key={s} value={s}>{s}</option>)}
            </select>
            {(filterSev || filterStat) && (
              <button className="btn btn-ghost" style={{ padding: '3px 8px', fontSize: 11 }}
                onClick={() => { setFilterSev(''); setFilterStat(''); }}>清除</button>
            )}
          </div>
        </div>

        {!initDone ? (
          <div className="empty-state"><span className="spinner"></span></div>
        ) : filtered.length === 0 ? (
          <div className="empty-state">
            <div className="empty-icon">🛡</div>
            <div>{list.length === 0 ? '暂无情报，请先执行批量扫描' : '无匹配记录'}</div>
          </div>
        ) : (
          <div className="table-wrap">
            <table>
              <thead>
                <tr>
                  <th style={{ width: 32 }}>
                    <input type="checkbox" checked={allSel}
                      onChange={() => setSelected(allSel ? [] : filtered.map(i => i.id))} />
                  </th>
                  <th>资产 IP</th><th>CVE 编号</th><th>标题</th>
                  <th>CVSS</th><th>危害等级</th><th>状态</th><th>发现时间</th><th>操作</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map(item => (
                  <tr key={item.id} style={{ background: selected.includes(item.id) ? 'rgba(0,229,255,.04)' : '' }}>
                    <td>
                      <input type="checkbox" checked={selected.includes(item.id)}
                        onChange={() => setSelected(s => s.includes(item.id) ? s.filter(x => x !== item.id) : [...s, item.id])} />
                    </td>
                    <td className="mono text-cyan">{item.ip_address}</td>
                    <td>
                      <a href={`https://nvd.nist.gov/vuln/detail/${item.cve_id}`} target="_blank"
                        style={{ color: 'var(--cyan)', fontFamily: 'JetBrains Mono', fontSize: 12 }}>
                        {item.cve_id}
                      </a>
                    </td>
                    <td style={{ maxWidth: 220, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', fontSize: 12 }}>
                      {item.title}
                    </td>
                    <td>
                      <span style={{ fontWeight: 600, color: item.cvss_score >= 9 ? 'var(--red)' : item.cvss_score >= 7 ? 'var(--orange)' : 'var(--green)' }}>
                        {item.cvss_score ?? '—'}
                      </span>
                    </td>
                    <td>{sevBadge(item.severity)}</td>
                    <td>
                      <select className="form-select" style={{ padding: '2px 5px', fontSize: 11, width: 'auto' }}
                        value={item.status || '未处理'}
                        onChange={e => updateStatus(item.id, e.target.value)}>
                        {['未处理', '已确认', '误报'].map(s => <option key={s} value={s}>{s}</option>)}
                      </select>
                    </td>
                    <td className="text-dimmer" style={{ fontSize: 11 }}>{item.created_at}</td>
                    <td>
                      <button className="btn btn-ghost" style={{ padding: '2px 8px', fontSize: 11, color: 'var(--red)' }}
                        onClick={() => deleteOne(item.id)}>删除</button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
