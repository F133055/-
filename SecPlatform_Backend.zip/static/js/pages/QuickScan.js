// pages/QuickScan.js
// 综合扫描 - 轮询由 window.QS 负责，组件只监听 qs-update 事件

// ── 综合扫描结果详情弹窗 ─────────────────────────────────────
function QSResultModal({ check, info, onClose }) {
  if (!check || !info) return null;
  const results = info.results || [];

  const renderResults = () => {
    if (!results.length) return <div style={{color:'var(--text3)',padding:'20px 0',textAlign:'center'}}>暂无结果数据</div>;

    // 端口扫描结果
    if (check.id === 'port_scan') {
      return results.map((r, i) => {
        if (!r?.discovered_assets) return null;
        const entries = Object.entries(r.discovered_assets).filter(([,ports]) => Array.isArray(ports) && ports.length > 0);
        if (!entries.length) return <div key={i} style={{color:'var(--text3)',fontSize:13}}>未发现有响应主机</div>;
        return entries.map(([ip, ports]) => (
          <div key={ip} style={{display:'flex',alignItems:'center',gap:10,padding:'8px 0',borderBottom:'1px solid var(--border)'}}>
            <span className="mono" style={{color:'var(--cyan)',minWidth:130}}>{ip}</span>
            <div style={{display:'flex',flexWrap:'wrap',gap:4}}>
              {ports.map(p=><span key={p} className="badge badge-blue">{p}</span>)}
            </div>
          </div>
        ));
      });
    }

    // 弱口令结果
    if (['ssh','mysql','redis','ftp'].includes(check.id)) {
      return results.map((r, i) => {
        const isFound = r?.result && r.result.startsWith('⚠️');
        return (
          <div key={i} style={{display:'flex',alignItems:'flex-start',gap:10,padding:'8px 0',borderBottom:'1px solid var(--border)'}}>
            <span style={{fontSize:16,flexShrink:0}}>{isFound ? '⚠️' : '✅'}</span>
            <div>
              <div className="mono" style={{color:'var(--cyan)',fontSize:13}}>{r?.ip || r?.task_id?.slice(0,8)}</div>
              <div style={{color: isFound ? 'var(--red)' : 'var(--text3)', fontSize:13, marginTop:3, fontFamily:'JetBrains Mono,monospace'}}>
                {r?.result || '无结果'}
              </div>
            </div>
          </div>
        );
      });
    }

    // 漏洞扫描结果
    return results.map((r, i) => {
      if (!r?.results) return null;
      return Object.entries(r.results).map(([ip, v]) => (
        <div key={ip} style={{display:'flex',alignItems:'center',gap:10,padding:'8px 0',borderBottom:'1px solid var(--border)'}}>
          <span style={{fontSize:16,flexShrink:0}}>{v === '存在漏洞' ? '⚠️' : '✅'}</span>
          <span className="mono" style={{color:'var(--cyan)',minWidth:130}}>{ip}</span>
          <span style={{color: v === '存在漏洞' ? 'var(--red)' : 'var(--text3)', fontSize:13}}>{v}</span>
        </div>
      ));
    });
  };

  return (
    <div style={{position:'fixed',inset:0,zIndex:600,display:'flex',alignItems:'center',justifyContent:'center'}} onClick={onClose}>
      <div style={{position:'absolute',inset:0,background:'rgba(0,0,0,.6)'}}/>
      <div style={{position:'relative',width:580,maxWidth:'92vw',maxHeight:'75vh',background:'var(--surface)',borderRadius:12,border:'1px solid var(--border)',boxShadow:'0 20px 60px rgba(0,0,0,.5)',display:'flex',flexDirection:'column',overflow:'hidden'}} onClick={e=>e.stopPropagation()}>
        <div style={{padding:'14px 18px',borderBottom:'1px solid var(--border)',display:'flex',alignItems:'center',justifyContent:'space-between'}}>
          <div style={{display:'flex',alignItems:'center',gap:8}}>
            <span style={{fontSize:18}}>{check.icon}</span>
            <div>
              <div style={{fontWeight:600,fontSize:14}}>{check.label} — 检测结果</div>
              <div style={{fontSize:11,color:'var(--text3)',marginTop:1}}>
                {results.length} 个任务 · 状态: {info.status}
              </div>
            </div>
          </div>
          <button onClick={onClose} style={{background:'none',border:'none',cursor:'pointer',color:'var(--text3)',fontSize:18}}>✕</button>
        </div>
        <div style={{flex:1,overflowY:'auto',padding:'14px 18px'}}>
          {renderResults()}
        </div>
        <div style={{padding:'10px 18px',borderTop:'1px solid var(--border)',display:'flex',justifyContent:'flex-end'}}>
          <button className="btn btn-ghost" onClick={onClose}>关闭</button>
        </div>
      </div>
    </div>
  );
}

const QUICK_CHECKS = [
  { id:'port_scan',    label:'端口扫描',         group:'资产发现',  icon:'📡', desc:'发现开放端口与服务' },
  { id:'nacos',        label:'Nacos 未授权',      group:'漏洞检测',  icon:'🔓', desc:'CVE-2021-29441' },
  { id:'swagger',      label:'Swagger 信息泄露',  group:'漏洞检测',  icon:'📖', desc:'API文档对外暴露' },
  { id:'minio',        label:'MinIO 未授权',      group:'漏洞检测',  icon:'🗄', desc:'对象存储未授权访问' },
  { id:'actuator',     label:'Spring Actuator',   group:'漏洞检测',  icon:'🌱', desc:'高危端点暴露' },
  { id:'druid',        label:'Druid 监控页',      group:'漏洞检测',  icon:'💧', desc:'监控页未授权访问' },
  { id:'redis_unauth', label:'Redis 未授权',      group:'漏洞检测',  icon:'🔴', desc:'无密码Redis服务' },
  { id:'docker',       label:'Docker API 未授权', group:'漏洞检测',  icon:'🐳', desc:'远程控制容器风险' },
  { id:'ssh',          label:'SSH 弱密码',        group:'弱密码检测',icon:'🔑', desc:'端口22' },
  { id:'mysql',        label:'MySQL 弱密码',      group:'弱密码检测',icon:'🗃', desc:'端口3306' },
  { id:'redis',        label:'Redis 弱密码',      group:'弱密码检测',icon:'🔴', desc:'端口6379' },
  { id:'ftp',          label:'FTP 弱密码',        group:'弱密码检测',icon:'📂', desc:'端口21' },
  { id:'oracle',       label:'Oracle 弱密码',     group:'弱密码检测',icon:'🔶', desc:'端口1521' },
  { id:'dm',           label:'达梦DB 弱密码',      group:'弱密码检测',icon:'🏛', desc:'端口5236（国产数据库）' },
  { id:'web',          label:'Web 系统弱密码',     group:'弱密码检测',icon:'🌐', desc:'HTTP 表单爆破' },
  { id:'ai_prompt',    label:'Prompt Injection',  group:'AI安全检测', icon:'🤖', desc:'提示词注入风险' },
  { id:'ai_mcp',       label:'MCP 服务暴露',       group:'AI安全检测', icon:'🔌', desc:'MCP接口未授权' },
  { id:'ai_service',   label:'AI 服务未授权',      group:'AI安全检测', icon:'⚡', desc:'Ollama/LocalAI未授权' },
];
const CHECK_GROUPS = ['资产发现', '漏洞检测', '弱密码检测', 'AI安全检测'];

// 综合扫描端口列表（覆盖常见服务，含 8000/8080 等 Web 端口）
const QS_PORTS = [21,22,23,25,53,80,443,445,1433,3306,3389,5432,5900,6379,7001,8000,8080,8443,8848,9090,9200,27017];

// API 调用：每个检测项对应的接口
function dispatchCheck(checkId, targets) {
  if (checkId === 'port_scan')
    return api.post('/api/scan/asset', { targets, ports: QS_PORTS });
  if (['ssh','mysql','redis','ftp','oracle','dm','web',
       'postgresql','telnet','mongodb','mssql'].includes(checkId))
    return api.post('/api/scan/weakness', { targets, service: checkId });
  if (['ai_prompt','ai_mcp','ai_service'].includes(checkId)) {
    const typeMap = { ai_prompt:'prompt_injection', ai_mcp:'mcp', ai_service:'ai_service' };
    return api.post('/api/ai-security/scan', { targets, check_type: typeMap[checkId] });
  }
  return api.post('/api/scan/vuln', { targets, vuln_type: checkId });
}

// ── 结果解析 ──────────────────────────────────────────────────
function hasVuln(info) {
  if (!info || info.status !== 'SUCCESS') return false;
  return (info.results || []).some(r => {
    if (!r) return false;
    if (r.result && r.result.startsWith('⚠️')) return true;  // 弱口令成功标志：⚠️发现xxx弱口令:
    if (r.results) return Object.values(r.results).some(v => v === '存在漏洞');
    if (r.discovered_assets) return Object.values(r.discovered_assets).some(ports => Array.isArray(ports) && ports.length > 0);
    return false;
  });
}

function getResultText(checkId, info) {
  if (!info) return '—';
  if (info.status === 'ERROR') return info.error || '下发失败';
  if (info.status === 'PENDING') return '等待中...';
  if (info.status === 'RUNNING') {
    const total = info.task_ids?.length || 1;
    const done  = info.done_count || 0;
    return `检测中${total > 1 ? ` (${done}/${total})` : ''}...`;
  }
  if (info.status !== 'SUCCESS') return '失败';

  const results = info.results || [];
  if (!results.length) return '无结果数据';

  // 端口扫描：合计发现的资产数
  if (checkId === 'port_scan') {
    let cnt = 0;
    results.forEach(r => { if (r?.discovered_assets) cnt += Object.values(r.discovered_assets).filter(p => Array.isArray(p) && p.length > 0).length; });
    return cnt > 0 ? `发现 ${cnt} 个有响应主机` : '未发现有响应主机';
  }

  // 弱密码：合计发现数
  if (['ssh','mysql','redis','ftp'].includes(checkId)) {
    const found = results.filter(r => r?.result && r.result.startsWith('⚠️'));
    if (found.length) return `⚠️ ${found.length} 个目标发现弱密码`;
    return '未发现弱密码';
  }

  // 漏洞扫描：汇总 vulnerable IPs
  let vulnIps = [];
  results.forEach(r => {
    if (r?.results) {
      Object.entries(r.results).forEach(([ip, v]) => { if (v === '存在漏洞') vulnIps.push(ip); });
    }
  });
  return vulnIps.length > 0 ? `⚠️ ${vulnIps.length} 个目标存在漏洞` : '未发现漏洞';
}

function getStatusBadge(status) {
  if (!status || status === 'PENDING') return <span className="badge badge-gray">等待中</span>;
  if (status === 'RUNNING')  return <span className="badge badge-cyan"><span className="spinner" style={{width:9,height:9,marginRight:3}}></span>检测中</span>;
  if (status === 'SUCCESS')  return <span className="badge badge-green">完成</span>;
  if (status === 'ERROR')    return <span className="badge badge-red">下发失败</span>;
  return <span className="badge badge-red">失败</span>;
}

// ── QuickScan 页面组件 ─────────────────────────────────────────
function QuickScanPage() {
  // 只用一个 counter 触发重渲染，实际数据全从 window.QS.state 读
  const [, forceUpdate] = useState(0);

  // 本地配置（不需要跨页保存，重进页面保持上次输入的内容）
  const [targets, setTargets] = useState(window.QS.state.targets || '');
  const [selectedChecks, setSelectedChecks] = useState(
    window.QS.state.selectedChecks ?? QUICK_CHECKS.map(c => c.id)
  );
  const [dispatching, setDispatching] = useState(false);
  const [detailItem,  setDetailItem]  = useState(null);  // {check, info}

  // 订阅全局更新事件，组件挂载时立即同步一次当前状态
  useEffect(() => {
    // 挂载时强制渲染一次（从其他页面切回来时，立即显示最新状态）
    forceUpdate(v => v + 1);
    const handler = () => forceUpdate(v => v + 1);
    window.addEventListener('qs-update', handler);
    return () => window.removeEventListener('qs-update', handler);
    // 组件卸载时移除监听，但 window.QS 的轮询继续运行
  }, []);

  // 同步本地配置到全局（切页后保留上次输入）
  useEffect(() => {
    window.QS.state.targets = targets;
    window.QS.state.selectedChecks = selectedChecks;
  }, [targets, selectedChecks]);

  // ── 开始扫描 ────────────────────────────────────────────────
  const startScan = async () => {
    const ips = targets.split(/[\n,\s]+/).filter(Boolean);
    if (!ips.length)          { alert('请输入目标IP'); return; }
    if (!selectedChecks.length) { alert('请至少选择一项检测'); return; }

    setDispatching(true);
    window.QS.reset(selectedChecks);  // 重置并广播

    for (const checkId of selectedChecks) {
      try {
        const r = await dispatchCheck(checkId, ips);
        if (!r) {
          window.QS.setError(checkId, '请求失败，请检查网络');
        } else if (r.code === 202 || r.task_id || r.task_ids) {
          window.QS.setDispatched(checkId, r);
        } else {
          window.QS.setError(checkId, r.detail || r.message || '下发失败');
        }
      } catch (e) {
        window.QS.setError(checkId, e.message);
      }
    }

    setDispatching(false);
    window.QS.startPolling();
  };

  const clearResults = () => window.QS.stopPolling();

  const toggleCheck  = id => setSelectedChecks(prev =>
    prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]);

  const toggleGroup  = group => {
    const gIds = QUICK_CHECKS.filter(c => c.group === group).map(c => c.id);
    const allSel = gIds.every(id => selectedChecks.includes(id));
    setSelectedChecks(prev => allSel
      ? prev.filter(id => !gIds.includes(id))
      : [...new Set([...prev, ...gIds])]);
  };

  // ── 从全局状态计算展示数据 ────────────────────────────────────
  const { taskMap, running } = window.QS.state;
  const taskList  = Object.values(taskMap);
  const total     = taskList.length;
  const done      = taskList.filter(t =>
    t.status === 'SUCCESS' || t.status === 'FAILURE' || t.status === 'ERROR'
  ).length;
  const found     = taskList.filter(t => hasVuln(t)).length;
  const pct       = total > 0 ? Math.round((done / total) * 100) : 0;
  const hasResults = total > 0;
  const allDone    = hasResults && done === total;
  const isRunning  = running || dispatching;

  return (
    <div>
      {detailItem && <QSResultModal check={detailItem.check} info={detailItem.info} onClose={()=>setDetailItem(null)}/>}
      {/* ── 页头 ── */}
      <div className="flex-between mb-16">
        <div>
          <div style={{fontSize:22,fontFamily:'Rajdhani',fontWeight:700,letterSpacing:1}}>综合扫描</div>
          <div style={{fontSize:12,color:'var(--text3)',marginTop:2}}>
            一键对目标运行全部安全检测，各检测项目完全独立不冲突
            {isRunning && (
              <span style={{color:'var(--cyan)',marginLeft:10}}>
                ● 扫描进行中，切换页面不影响任务
              </span>
            )}
          </div>
        </div>
        {hasResults && !isRunning && (
          <button className="btn btn-ghost" onClick={clearResults}>清空结果</button>
        )}
      </div>

      <div style={{display:'grid',gridTemplateColumns:'1fr 1.5fr',gap:20}}>

        {/* ── 左：配置面板 ── */}
        <div className="card">
          <div className="card-header">
            <span className="card-title">扫描目标</span>
          </div>
          <div className="form-group">
            <label className="form-label">目标 IP / 域名（每行一个）</label>
            <textarea
              className="form-textarea"
              value={targets}
              onChange={e => setTargets(e.target.value)}
              placeholder={"192.168.1.1\n10.0.0.1"}
              rows={4}
              disabled={isRunning}
            />
          </div>

          <div className="card-header" style={{marginTop:4}}>
            <span className="card-title">检测项目</span>
            <div style={{display:'flex',gap:6}}>
              <button className="btn btn-ghost" style={{padding:'2px 8px',fontSize:11}}
                onClick={() => setSelectedChecks(QUICK_CHECKS.map(c => c.id))} disabled={isRunning}>全选</button>
              <button className="btn btn-ghost" style={{padding:'2px 8px',fontSize:11}}
                onClick={() => setSelectedChecks([])} disabled={isRunning}>清空</button>
            </div>
          </div>

          {CHECK_GROUPS.map(group => {
            const gc = QUICK_CHECKS.filter(c => c.group === group);
            const allSel = gc.every(c => selectedChecks.includes(c.id));
            return (
              <div key={group} className="check-group">
                <div className="check-group-title" style={{display:'flex',justifyContent:'space-between',alignItems:'center'}}>
                  <span>{group}</span>
                  <button className="btn btn-ghost" style={{padding:'1px 6px',fontSize:10}}
                    onClick={() => toggleGroup(group)} disabled={isRunning}>
                    {allSel ? '取消全组' : '全选此组'}
                  </button>
                </div>
                <div className="check-items">
                  {gc.map(c => (
                    <div key={c.id}
                      className={`check-item${selectedChecks.includes(c.id) ? ' selected' : ''}${isRunning ? ' disabled' : ''}`}
                      onClick={() => !isRunning && toggleCheck(c.id)}
                      title={c.desc}
                    >
                      {c.icon} {c.label}
                    </div>
                  ))}
                </div>
              </div>
            );
          })}

          <div style={{marginTop:14}}>
            <div style={{fontSize:12,color:'var(--text3)',marginBottom:8}}>
              已选 {selectedChecks.length} / {QUICK_CHECKS.length} 项
            </div>
            <button
              className="btn btn-primary"
              style={{width:'100%',justifyContent:'center',padding:'10px',fontSize:14}}
              onClick={startScan}
              disabled={isRunning || !selectedChecks.length}
            >
              {dispatching
                ? <><span className="spinner"></span> 下发任务中...</>
                : isRunning
                ? <><span className="spinner"></span> 扫描中 ({pct}%)...</>
                : '⊙ 开始综合扫描'}
            </button>
          </div>
        </div>

        {/* ── 右：实时结果 ── */}
        <div className="card">
          <div className="card-header">
            <span className="card-title">检测结果</span>
            {hasResults && (
              <span style={{fontSize:12,color:'var(--text3)'}}>
                完成 {done}/{total}
              </span>
            )}
          </div>

          {/* 进度条 */}
          {hasResults && (
            <div style={{marginBottom:14}}>
              <div className="progress-bar">
                <div className="progress-fill" style={{
                  width: `${pct}%`,
                  background: allDone
                    ? (found > 0 ? 'var(--red)' : 'var(--green)')
                    : 'var(--cyan)',
                  transition: 'width .4s ease',
                }}></div>
              </div>
              <div style={{fontSize:11,color:'var(--text3)',marginTop:4,display:'flex',justifyContent:'space-between'}}>
                <span>进度: {pct}%</span>
                <span style={{color: allDone ? (found > 0 ? 'var(--red)' : 'var(--green)') : 'var(--text3)'}}>
                  {allDone
                    ? (found > 0 ? `⚠️ 发现 ${found} 项风险` : '✓ 未发现风险')
                    : '检测中...'}
                </span>
              </div>
            </div>
          )}

          {!hasResults ? (
            <div className="empty-state">
              <div className="empty-icon">⊙</div>
              <div>选择目标和检测项目，点击"开始综合扫描"</div>
              <div style={{fontSize:12,marginTop:8,color:'var(--text3)'}}>
                切换页面后任务在后台继续运行，回来后进度依然保留
              </div>
            </div>
          ) : (
            <div style={{maxHeight:460,overflowY:'auto'}}>
              {CHECK_GROUPS.map(group => {
                const gc = QUICK_CHECKS.filter(c => taskMap[c.id] !== undefined && c.group === group);
                if (!gc.length) return null;
                return (
                  <div key={group} style={{marginBottom:14}}>
                    <div style={{
                      fontSize:10,color:'var(--text3)',letterSpacing:2,textTransform:'uppercase',
                      marginBottom:6,paddingBottom:4,borderBottom:'1px solid var(--border)',
                    }}>{group}</div>
                    {gc.map(c => {
                      const info = taskMap[c.id];
                      const vuln = hasVuln(info);
                      return (
                        <div key={c.id} className="result-row"
                          style={{background: vuln ? 'rgba(239,68,68,.05)' : '', cursor: info?.status==='SUCCESS' ? 'pointer' : 'default'}}
                          title={info?.status==='SUCCESS' ? '点击查看详细结果' : ''}
                          onClick={() => info?.status==='SUCCESS' && setDetailItem({check:c, info})}>
                          <span className="result-check-name">{c.icon} {c.label}</span>
                          <span className="result-detail" style={{color: vuln ? 'var(--red)' : 'var(--text3)'}}>
                            {getResultText(c.id, info)}
                            {info?.status==='SUCCESS' && <span style={{fontSize:10,opacity:.5,marginLeft:4}}>↗详情</span>}
                          </span>
                          <span>{getStatusBadge(info?.status)}</span>
                        </div>
                      );
                    })}
                  </div>
                );
              })}
            </div>
          )}

          {allDone && (
            <div style={{
              marginTop:10, padding:'10px 14px', borderRadius:8,
              background: found > 0 ? 'rgba(239,68,68,.08)' : 'rgba(34,197,94,.08)',
              border: `1px solid ${found > 0 ? 'rgba(239,68,68,.3)' : 'rgba(34,197,94,.3)'}`,
              color: found > 0 ? 'var(--red)' : 'var(--green)',
              fontSize:13, fontWeight:600,
            }}>
              {found > 0
                ? `⚠️ 扫描完成：发现 ${found} 项风险，请前往漏洞管理查看详情`
                : '✓ 扫描完成：未发现明显安全风险'}
            </div>
          )}
        </div>
      </div>

      {/* ── 使用提示 ── */}
      <div className="card" style={{marginTop:20}}>
        <div className="card-header"><span className="card-title">使用提示</span></div>
        <div style={{display:'grid',gridTemplateColumns:'repeat(3,1fr)',gap:16,fontSize:12,color:'var(--text2)'}}>
          <div>
            <div style={{color:'var(--cyan)',fontWeight:600,marginBottom:4}}>📌 扫描目标格式</div>
            <div style={{lineHeight:1.8}}>
              支持 IP（192.168.1.1）、域名（example.com）、CIDR（10.0.0.0/24）。<br/>
              弱密码检测仅支持 IP，不支持域名。<br/>
              每个目标单独一行，上限 1000 个。
            </div>
          </div>
          <div>
            <div style={{color:'var(--cyan)',fontWeight:600,marginBottom:4}}>⚡ 扫描速度参考</div>
            <div style={{lineHeight:1.8}}>
              端口扫描：50并发，每IP约0.5-2s。<br/>
              漏洞检测：TCP预检+并发，每IP约3-8s。<br/>
              弱密码：取决于字典大小，默认字典约5-15s/IP。
            </div>
          </div>
          <div>
            <div style={{color:'var(--cyan)',fontWeight:600,marginBottom:4}}>📋 发现漏洞后</div>
            <div style={{lineHeight:1.8}}>
              漏洞自动写入「漏洞管理」，可标记处理状态。<br/>
              点击结果行「↗详情」查看受影响的具体 IP。<br/>
              「安全报告」→「生成日报」可导出完整分析。
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
