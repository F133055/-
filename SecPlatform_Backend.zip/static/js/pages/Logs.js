// pages/Logs.js - 系统日志调试页面
function LogsPage() {
  const [lines,    setLines]    = useState([]);
  const [logType,  setLogType]  = useState('app');
  const [lineCount,setLineCount]= useState(100);
  const [loading,  setLoading]  = useState(false);
  const [autoRefresh, setAutoRefresh] = useState(false);
  const [filter,   setFilter]   = useState('');
  const [levelFilter, setLevelFilter] = useState('');
  const endRef = useRef(null);

  const load = useCallback(async () => {
    setLoading(true);
    const r = await api.get(`/api/logs?lines=${lineCount}&log_type=${logType}`);
    if (r?.lines) setLines(r.lines);
    setLoading(false);
  }, [logType, lineCount]);

  useEffect(() => { load(); }, [load]);

  // 自动刷新
  useEffect(() => {
    if (!autoRefresh) return;
    const t = setInterval(load, 10000);
    return () => clearInterval(t);
  }, [autoRefresh, load]);

  // 自动滚到底部
  useEffect(() => {
    if (autoRefresh) endRef.current?.scrollIntoView({behavior:'smooth'});
  }, [lines, autoRefresh]);

  const getLevelColor = (line) => {
    if (line.includes('[ERROR]') || line.includes('ERROR') || line.includes('❌')) return 'var(--red)';
    if (line.includes('[WARNING]') || line.includes('WARNING') || line.includes('⚠')) return 'var(--orange)';
    if (line.includes('[INFO]') || line.includes('✅') || line.includes('INFO')) return 'var(--text2)';
    if (line.includes('[DEBUG]') || line.includes('DEBUG')) return 'var(--text3)';
    return 'var(--text2)';
  };

  const getLevelBg = (line) => {
    if (line.includes('[ERROR]') || line.includes('❌')) return 'rgba(239,68,68,0.05)';
    if (line.includes('[WARNING]') || line.includes('⚠')) return 'rgba(251,146,60,0.05)';
    return '';
  };

  const filtered = lines.filter(l => {
    const matchText  = !filter || l.toLowerCase().includes(filter.toLowerCase());
    const matchLevel = !levelFilter || l.toUpperCase().includes(levelFilter);
    return matchText && matchLevel;
  });

  return (
    <div>
      <div className="flex-between mb-16">
        <div>
          <div style={{fontSize:22,fontFamily:'Rajdhani',fontWeight:700,letterSpacing:1}}>系统日志</div>
          <div style={{fontSize:12,color:'var(--text3)',marginTop:2}}>实时查看系统运行日志，辅助排查问题</div>
        </div>
        <div style={{display:'flex',gap:8,alignItems:'center'}}>
          <label style={{fontSize:12,color:'var(--text2)',display:'flex',alignItems:'center',gap:4,cursor:'pointer'}}>
            <input type="checkbox" checked={autoRefresh} onChange={e=>setAutoRefresh(e.target.checked)}/>
            自动刷新 (3s)
          </label>
          <button className="btn btn-ghost" onClick={load} disabled={loading}>
            {loading ? <span className="spinner"></span> : icons.refresh} 刷新
          </button>
        </div>
      </div>

      {/* 控制栏 */}
      <div className="card section-gap" style={{marginBottom:16}}>
        <div style={{display:'flex',gap:12,flexWrap:'wrap',alignItems:'center'}}>
          <div style={{display:'flex',gap:6}}>
            {[{v:'app',l:'应用日志'},{v:'celery',l:'Celery日志'}].map(t=>(
              <button key={t.v}
                className={`btn ${logType===t.v?'btn-primary':'btn-ghost'}`}
                style={{padding:'5px 14px',fontSize:12}}
                onClick={()=>setLogType(t.v)}>
                {t.l}
              </button>
            ))}
          </div>
          <select className="form-select" style={{width:110}} value={lineCount}
            onChange={e=>setLineCount(Number(e.target.value))}>
            <option value={50}>最近50行</option>
            <option value={100}>最近100行</option>
            <option value={200}>最近200行</option>
            <option value={500}>最近500行</option>
          </select>
          <select className="form-select" style={{width:110}} value={levelFilter}
            onChange={e=>setLevelFilter(e.target.value)}>
            <option value="">全部级别</option>
            <option value="ERROR">ERROR</option>
            <option value="WARNING">WARNING</option>
            <option value="INFO">INFO</option>
            <option value="DEBUG">DEBUG</option>
          </select>
          <input className="form-input" style={{flex:1,minWidth:160,padding:'5px 10px',fontSize:12}}
            value={filter} onChange={e=>setFilter(e.target.value)}
            placeholder="关键词过滤..."/>
          {filter && (
            <button className="btn btn-ghost" style={{padding:'4px 10px',fontSize:12}} onClick={()=>setFilter('')}>清除</button>
          )}
          <span style={{fontSize:12,color:'var(--text3)',marginLeft:'auto'}}>
            {filter || levelFilter ? `过滤后 ${filtered.length} / ${lines.length} 行` : `共 ${lines.length} 行`}
          </span>
        </div>
      </div>

      {/* 日志内容 */}
      <div style={{
        background:'var(--card)',border:'1px solid var(--border)',borderRadius:10,
        overflow:'hidden',fontFamily:'JetBrains Mono',fontSize:11,
      }}>
        <div style={{maxHeight:'60vh',overflowY:'auto',padding:'8px 0'}}>
          {loading && lines.length===0 ? (
            <div className="empty-state"><span className="spinner"></span></div>
          ) : filtered.length===0 ? (
            <div className="empty-state">
              <div className="empty-icon">📋</div>
              <div>{lines.length===0 ? '暂无日志' : '没有匹配的日志行'}</div>
            </div>
          ) : (
            filtered.map((line, i) => (
              <div key={i} style={{
                padding:'3px 16px',lineHeight:1.7,
                color: getLevelColor(line),
                background: getLevelBg(line),
                borderBottom: i < filtered.length-1 ? '1px solid rgba(255,255,255,0.03)' : 'none',
                wordBreak:'break-all',
              }}>
                <span style={{color:'var(--text3)',userSelect:'none',marginRight:8,fontSize:10}}>{lines.length - lines.indexOf(line)}</span>
                {line}
              </div>
            ))
          )}
          <div ref={endRef}/>
        </div>
      </div>

      {/* 快捷说明 */}
      <div className="card" style={{marginTop:16,background:'rgba(0,0,0,0.2)'}}>
        <div style={{fontSize:12,color:'var(--text3)',lineHeight:1.8}}>
          <div>📂 <b>应用日志</b>：FastAPI 启动、API请求、资产写库、错误信息</div>
          <div>⚙️ <b>Celery日志</b>：任务队列、扫描任务执行过程、Worker状态</div>
          <div>🔴 <b>ERROR</b> = 需要关注的错误 &nbsp; 🟡 <b>WARNING</b> = 警告信息 &nbsp; ⚪ <b>INFO/DEBUG</b> = 正常运行日志</div>
        </div>
      </div>
    </div>
  );
}
