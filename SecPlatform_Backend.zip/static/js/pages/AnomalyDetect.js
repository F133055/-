// pages/AnomalyDetect.js - 异常检测页面

function AnomalyDetectPage() {
  const [events,       setEvents]       = useState([]);
  const [stats,        setStats]        = useState({});
  const [highRisk,     setHighRisk]     = useState([]);
  const [snapTimes,    setSnapTimes]    = useState([]);
  const [initDone,     setInitDone]     = useState(false);
  const [refreshing,   setRefreshing]   = useState(false);
  const [detecting,    setDetecting]    = useState(false);
  const [detectMsg,    setDetectMsg]    = useState('');
  const [detectResult, setDetectResult] = useState(null);
  const [filterSev,    setFilterSev]    = useState('');
  const [filterStat,   setFilterStat]   = useState('');
  const [tabActive,    setTabActive]    = useState('events');
  const [snapA,        setSnapA]        = useState('');
  const [snapB,        setSnapB]        = useState('');
  const [comparing,    setComparing]    = useState(false);
  const [compareRes,   setCompareRes]   = useState(null);
  // 详情弹窗
  const [detailModal,  setDetailModal]  = useState(null); // { title, items, type }
  const [assetDetail,  setAssetDetail]  = useState(null); // 高危端口资产详情

  const load = useCallback(async (isManual = false) => {
    if (isManual) setRefreshing(true);
    const [e, s, h, t] = await Promise.all([
      api.get('/api/anomaly/events?limit=500'),
      api.get('/api/anomaly/stats'),
      api.get('/api/anomaly/high-risk-ports'),
      api.get('/api/anomaly/snapshot-times'),
    ]);
    if (e?.data) setEvents(e.data);
    if (s?.data) setStats(s.data);
    if (h?.data) setHighRisk(h.data);
    if (t?.data) setSnapTimes(t.data);
    setInitDone(true);
    if (isManual) setRefreshing(false);
  }, []);

  useEffect(() => { load(false); }, []);

  // 触发检测
  const runDetection = async () => {
    setDetecting(true); setDetectMsg(''); setDetectResult(null);
    const r = await api.post('/api/anomaly/run-detection', {});
    setDetecting(false);
    if (r?.code === 200) {
      setDetectResult(r.data);
      setDetectMsg('✓ 检测完成');
      load(false);
    } else {
      setDetectMsg('✗ 检测失败：' + (r?.detail || ''));
    }
  };

  // 快照对比
  const doCompare = async () => {
    if (!snapA || !snapB) { alert('请选择两个时间点'); return; }
    if (snapA === snapB)  { alert('请选择不同的两个时间点'); return; }
    setComparing(true); setCompareRes(null);
    const r = await api.post('/api/anomaly/compare-snapshots', { time_a: snapA, time_b: snapB });
    setComparing(false);
    if (r?.code === 200) setCompareRes(r.data);
    else alert('对比失败：' + (r?.detail || ''));
  };

  // 更新状态
  const updateStatus = async (id, status) => {
    await api.patch(`/api/anomaly/${id}/status`, { status });
    setEvents(prev => prev.map(e => e.id === id ? { ...e, status } : e));
  };

  // 删除
  const deleteOne = async (id) => {
    if (!confirm('确认删除此事件？')) return;
    const r = await api.req('DELETE', `/api/anomaly/${id}`);
    if (r?.code === 200) setEvents(prev => prev.filter(e => e.id !== id));
  };

  const sevBadge = s => {
    const m = { 高: 'badge-red', 中: 'badge-orange', 低: 'badge-green', 信息: 'badge-blue' };
    return <span className={`badge ${m[s] || 'badge-gray'}`}>{s || '—'}</span>;
  };

  const typeIcon = t => {
    const m = {
      new_high_risk_port: '🚨', high_risk_port_exists: '🚨',
      new_asset: '🆕', asset_offline: '💀', asset_disappeared: '💀',
      port_change: '🔄', service_change: '⚠️',
    };
    return m[t] || '🔍';
  };

  const typeName = t => {
    const m = {
      new_high_risk_port: '新增高危端口', high_risk_port_exists: '高危端口暴露',
      new_asset: '新增资产', asset_offline: '资产离线', asset_disappeared: '资产消失',
      port_change: '端口变化', service_change: '服务变化',
    };
    return m[t] || t;
  };

  const filtered = events.filter(e => {
    if (filterSev  && e.severity !== filterSev)  return false;
    if (filterStat && e.status   !== filterStat) return false;
    return true;
  });

  // 统计卡片点击：打开详情弹窗
  // stats字段：total / unhandled / high_severity_unhandled / today
  const statCards = [
    {
      l: '异常事件', v: stats.total ?? '-', c: 'orange',
      onClick: () => setDetailModal({
        title: '全部异常事件', icon: '🔍',
        items: events, type: 'events',
      }),
    },
    {
      l: '高危事件', v: stats.high_severity_unhandled ?? '-', c: 'red',
      onClick: () => setDetailModal({
        title: '高危未处理事件', icon: '🚨',
        items: events.filter(e => e.severity === '高' && e.status === '未处理'), type: 'events',
      }),
    },
    {
      l: '未处理', v: stats.unhandled ?? '-', c: 'purple',
      onClick: () => setDetailModal({
        title: '未处理事件', icon: '⏳',
        items: events.filter(e => e.status === '未处理'), type: 'events',
      }),
    },
    {
      l: '高危端口资产', v: highRisk.length, c: 'cyan',
      onClick: () => setDetailModal({
        title: '高危端口资产', icon: '🔌',
        items: highRisk, type: 'highRisk',
      }),
    },
  ];

  const tabs = [
    { id: 'events',   label: '异常事件' },
    { id: 'highRisk', label: '高危端口资产' },
    { id: 'snapshot', label: '快照对比' },
  ];

  return (
    <div>
      {/* ── 异常事件/高危资产详情弹窗 ─────────────────────────── */}
      {detailModal && (
        <div style={{ position: 'fixed', inset: 0, zIndex: 600, display: 'flex', alignItems: 'center', justifyContent: 'center' }}
          onClick={() => setDetailModal(null)}>
          <div style={{ position: 'absolute', inset: 0, background: 'rgba(0,0,0,.65)' }} />
          <div style={{
            position: 'relative', width: 820, maxWidth: '96vw', maxHeight: '82vh',
            background: 'var(--surface)', borderRadius: 12, border: '1px solid var(--border)',
            boxShadow: '0 20px 60px rgba(0,0,0,.5)', display: 'flex', flexDirection: 'column', overflow: 'hidden',
          }} onClick={e => e.stopPropagation()}>
            <div style={{ padding: '14px 20px', borderBottom: '1px solid var(--border)', display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexShrink: 0 }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                <span style={{ fontSize: 20 }}>{detailModal.icon}</span>
                <div>
                  <div style={{ fontFamily: 'Rajdhani', fontWeight: 700, fontSize: 17, letterSpacing: 1 }}>{detailModal.title}</div>
                  <div style={{ fontSize: 12, color: 'var(--text3)', marginTop: 1 }}>共 {detailModal.items.length} 条</div>
                </div>
              </div>
              <button onClick={() => setDetailModal(null)} style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--text3)', fontSize: 20 }}>✕</button>
            </div>
            <div style={{ flex: 1, overflowY: 'auto', padding: 16 }}>
              {detailModal.items.length === 0 ? (
                <div className="empty-state"><div className="empty-icon">✓</div><div style={{ color: 'var(--green)' }}>暂无数据</div></div>
              ) : detailModal.type === 'events' ? (
                <div className="table-wrap">
                  <table>
                    <thead><tr><th>类型</th><th>资产IP</th><th>描述</th><th>危害</th><th>状态</th><th>检测时间</th></tr></thead>
                    <tbody>{detailModal.items.map(ev => (
                      <tr key={ev.id}>
                        <td>
                          <span style={{ marginRight: 4 }}>{typeIcon(ev.anomaly_type)}</span>
                          <span style={{ fontSize: 11, color: 'var(--text3)' }}>{typeName(ev.anomaly_type)}</span>
                        </td>
                        <td className="mono text-cyan" style={{ fontSize: 12 }}>{ev.ip_address}</td>
                        <td style={{ fontSize: 12, color: 'var(--text2)', maxWidth: 220, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{ev.description}</td>
                        <td>{sevBadge(ev.severity)}</td>
                        <td>
                          <select className="form-select" style={{ padding: '2px 5px', fontSize: 11, width: 'auto' }}
                            value={ev.status || '未处理'}
                            onChange={e => { updateStatus(ev.id, e.target.value); setDetailModal(prev => ({ ...prev, items: prev.items.map(i => i.id === ev.id ? { ...i, status: e.target.value } : i) })); }}>
                            {['未处理', '已确认', '忽略'].map(s => <option key={s} value={s}>{s}</option>)}
                          </select>
                        </td>
                        <td style={{ fontSize: 11, color: 'var(--text3)' }}>{ev.detected_at}</td>
                      </tr>
                    ))}</tbody>
                  </table>
                </div>
              ) : (
                /* 高危端口资产视图 */
                <div className="table-wrap">
                  <table>
                    <thead><tr><th>IP 地址</th><th>风险等级</th><th>高危端口</th><th>全部端口</th><th>最后在线</th></tr></thead>
                    <tbody>{detailModal.items.map((asset, i) => (
                      <tr key={i} style={{ cursor: 'pointer' }} onClick={() => setAssetDetail(asset)}>
                        <td className="mono text-cyan">{asset.ip_address}</td>
                        <td><span style={{ fontWeight: 600, fontSize: 12, color: asset.risk_level === '高' ? 'var(--red)' : 'var(--text3)' }}>{asset.risk_level || '未知'}</span></td>
                        <td>
                          <div style={{ display: 'flex', flexWrap: 'wrap', gap: 4 }}>
                            {(asset.high_risk_ports || []).map(p => (
                              <span key={p.port} title={p.service} className="badge badge-red">{p.port}</span>
                            ))}
                          </div>
                        </td>
                        <td className="mono" style={{ fontSize: 11, color: 'var(--text2)', maxWidth: 180, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{asset.all_ports}</td>
                        <td style={{ fontSize: 11, color: 'var(--text3)' }}>{asset.last_seen}</td>
                      </tr>
                    ))}</tbody>
                  </table>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* ── 高危端口资产单项详情弹窗 ──────────────────────────── */}
      {assetDetail && (
        <div style={{ position: 'fixed', inset: 0, zIndex: 800, display: 'flex', alignItems: 'center', justifyContent: 'center' }}
          onClick={() => setAssetDetail(null)}>
          <div style={{ position: 'absolute', inset: 0, background: 'rgba(0,0,0,.55)' }} />
          <div style={{ position: 'relative', width: 520, maxWidth: '94vw', background: 'var(--surface)', borderRadius: 12, border: '1px solid var(--border)', boxShadow: '0 24px 60px rgba(0,0,0,.6)', overflow: 'hidden' }}
            onClick={e => e.stopPropagation()}>
            <div style={{ padding: '14px 20px', borderBottom: '1px solid var(--border)', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <div style={{ fontFamily: 'Rajdhani', fontWeight: 700, fontSize: 17 }}>🔌 高危端口详情</div>
              <button onClick={() => setAssetDetail(null)} style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--text3)', fontSize: 20 }}>✕</button>
            </div>
            <div style={{ padding: 20 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', padding: '8px 0', borderBottom: '1px solid var(--border)', fontSize: 13 }}>
                <span style={{ color: 'var(--text3)', minWidth: 90 }}>IP 地址</span>
                <span className="mono text-cyan" style={{ fontWeight: 600 }}>{assetDetail.ip_address}</span>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', padding: '8px 0', borderBottom: '1px solid var(--border)', fontSize: 13 }}>
                <span style={{ color: 'var(--text3)', minWidth: 90 }}>风险等级</span>
                <span style={{ fontWeight: 600, color: assetDetail.risk_level === '高' ? 'var(--red)' : 'var(--text2)' }}>{assetDetail.risk_level || '未知'}</span>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', padding: '8px 0', borderBottom: '1px solid var(--border)', fontSize: 13 }}>
                <span style={{ color: 'var(--text3)', minWidth: 90 }}>最后在线</span>
                <span style={{ color: 'var(--text2)' }}>{assetDetail.last_seen}</span>
              </div>
              <div style={{ marginTop: 16 }}>
                <div style={{ fontSize: 12, color: 'var(--text3)', marginBottom: 10, textTransform: 'uppercase', letterSpacing: 1 }}>高危端口列表</div>
                {(assetDetail.high_risk_ports || []).map(p => (
                  <div key={p.port} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '8px 12px', background: 'rgba(239,68,68,.08)', borderRadius: 8, marginBottom: 6, border: '1px solid rgba(239,68,68,.2)' }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                      <span className="badge badge-red" style={{ fontSize: 13, fontFamily: 'JetBrains Mono', padding: '3px 10px' }}>{p.port}</span>
                      <span style={{ fontSize: 13, color: 'var(--text2)', fontWeight: 500 }}>{p.service}</span>
                    </div>
                    <span style={{ fontSize: 11, color: 'var(--red)', opacity: .8 }}>高风险暴露</span>
                  </div>
                ))}
              </div>
              {assetDetail.all_ports && (
                <div style={{ marginTop: 14 }}>
                  <div style={{ fontSize: 12, color: 'var(--text3)', marginBottom: 6, textTransform: 'uppercase', letterSpacing: 1 }}>全部开放端口</div>
                  <div className="mono" style={{ fontSize: 12, color: 'var(--text2)', background: 'var(--bg)', borderRadius: 6, padding: '8px 12px', wordBreak: 'break-all', lineHeight: 1.6 }}>{assetDetail.all_ports}</div>
                </div>
              )}
            </div>
            <div style={{ padding: '12px 20px', borderTop: '1px solid var(--border)', display: 'flex', justifyContent: 'flex-end' }}>
              <button className="btn btn-ghost" onClick={() => setAssetDetail(null)}>关闭</button>
            </div>
          </div>
        </div>
      )}

      {/* ── 主页面 ─────────────────────────────────────────────── */}
      <div className="flex-between mb-16">
        <div>
          <div style={{ fontSize: 22, fontFamily: 'Rajdhani', fontWeight: 700, letterSpacing: 1 }}>异常检测</div>
          <div style={{ fontSize: 12, color: 'var(--text3)', marginTop: 2 }}>资产变化 · 高危端口 · 快照对比 · 点击卡片查看详情</div>
        </div>
        <div style={{ display: 'flex', gap: 8 }}>
          <button className="btn btn-ghost" onClick={() => load(true)} disabled={refreshing}>
            {refreshing ? <span className="spinner" style={{ width: 13, height: 13 }}></span> : '↻'} 刷新
          </button>
          <button className="btn btn-primary" onClick={runDetection} disabled={detecting}>
            {detecting ? <><span className="spinner"></span> 检测中...</> : '▶ 立即检测'}
          </button>
        </div>
      </div>

      {detectMsg && (
        <div className={`alert ${detectMsg.startsWith('✓') ? 'alert-success' : 'alert-error'}`} style={{ marginBottom: 16 }}>
          {detectMsg}
          {detectResult?.summary && (
            <span style={{ marginLeft: 12, fontSize: 12, opacity: 0.8 }}>
              新增资产: {detectResult.summary.new_assets || 0} ·
              消失资产: {detectResult.summary.disappeared || 0} ·
              高危端口: {detectResult.summary.new_high_risk_ports || 0} ·
              端口变化: {detectResult.summary.port_changes || 0}
            </span>
          )}
        </div>
      )}

      {/* 统计卡片（可点击） */}
      <div className="stats-grid section-gap" style={{ gridTemplateColumns: 'repeat(4,1fr)' }}>
        {statCards.map(c => (
          <div key={c.l} className={`stat-card ${c.c}`}
            style={{ cursor: 'pointer', transition: 'transform .15s, box-shadow .15s' }}
            onClick={c.onClick}
            onMouseEnter={e => { e.currentTarget.style.transform = 'translateY(-2px)'; e.currentTarget.style.boxShadow = '0 6px 20px rgba(0,0,0,.3)'; }}
            onMouseLeave={e => { e.currentTarget.style.transform = ''; e.currentTarget.style.boxShadow = ''; }}
            title="点击查看详情">
            <div className="stat-value">{!initDone ? '...' : c.v}</div>
            <div className="stat-label">{c.l}</div>
            <div style={{ fontSize: 10, color: 'var(--text3)', marginTop: 4, opacity: .7 }}>点击查看 →</div>
          </div>
        ))}
      </div>

      {/* Tab 切换 */}
      <div style={{ display: 'flex', gap: 4, marginBottom: 16, borderBottom: '1px solid var(--border)' }}>
        {tabs.map(t => (
          <button key={t.id} onClick={() => setTabActive(t.id)}
            style={{
              padding: '8px 18px', fontSize: 13, border: 'none', cursor: 'pointer',
              background: 'none', color: tabActive === t.id ? 'var(--cyan)' : 'var(--text3)',
              borderBottom: tabActive === t.id ? '2px solid var(--cyan)' : '2px solid transparent',
              fontWeight: tabActive === t.id ? 600 : 400, transition: 'all .15s',
            }}>
            {t.label}
          </button>
        ))}
      </div>

      {/* ── Tab: 异常事件 ─────────────────────────────────────── */}
      {tabActive === 'events' && (
        <div className="card">
          <div className="card-header">
            <span className="card-title">异常事件列表（{filtered.length}）</span>
            <div style={{ display: 'flex', gap: 8 }}>
              <select className="form-select" style={{ width: 90, padding: '3px 6px', fontSize: 12 }}
                value={filterSev} onChange={e => setFilterSev(e.target.value)}>
                <option value="">全部危害</option>
                {['高', '中', '低', '信息'].map(s => <option key={s} value={s}>{s}</option>)}
              </select>
              <select className="form-select" style={{ width: 90, padding: '3px 6px', fontSize: 12 }}
                value={filterStat} onChange={e => setFilterStat(e.target.value)}>
                <option value="">全部状态</option>
                {['未处理', '已确认', '忽略'].map(s => <option key={s} value={s}>{s}</option>)}
              </select>
              {(filterSev || filterStat) && (
                <button className="btn btn-ghost" style={{ padding: '3px 8px', fontSize: 11 }}
                  onClick={() => { setFilterSev(''); setFilterStat(''); }}>清除</button>
              )}
            </div>
          </div>
          {!initDone ? (
            <div className="empty-state"><span className="spinner"></span></div>
          ) : filtered.length === 0 ? (
            <div className="empty-state">
              <div className="empty-icon">✓</div>
              <div style={{ color: 'var(--green)' }}>
                {events.length === 0 ? '暂无异常事件，点击「立即检测」开始分析' : '无匹配事件'}
              </div>
            </div>
          ) : (
            <div className="table-wrap">
              <table>
                <thead>
                  <tr><th>类型</th><th>资产 IP</th><th>描述</th><th>原始值</th><th>新值</th><th>危害</th><th>状态</th><th>检测时间</th><th>操作</th></tr>
                </thead>
                <tbody>
                  {filtered.map(ev => (
                    <tr key={ev.id} style={{ background: ev.severity === '高' ? 'rgba(239,68,68,.03)' : '' }}>
                      <td>
                        <span style={{ fontSize: 14, marginRight: 4 }}>{typeIcon(ev.anomaly_type)}</span>
                        <span style={{ fontSize: 11, color: 'var(--text3)' }}>{typeName(ev.anomaly_type)}</span>
                      </td>
                      <td className="mono text-cyan" style={{ fontSize: 12 }}>{ev.ip_address}</td>
                      <td style={{ maxWidth: 200, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', fontSize: 12 }}>{ev.description}</td>
                      <td><span className="mono" style={{ fontSize: 11, color: 'var(--text3)' }}>{ev.old_value || '—'}</span></td>
                      <td><span className="mono" style={{ fontSize: 11, color: 'var(--cyan)' }}>{ev.new_value || '—'}</span></td>
                      <td>{sevBadge(ev.severity)}</td>
                      <td>
                        <select className="form-select" style={{ padding: '2px 5px', fontSize: 11, width: 'auto' }}
                          value={ev.status || '未处理'}
                          onChange={e => updateStatus(ev.id, e.target.value)}>
                          {['未处理', '已确认', '忽略'].map(s => <option key={s} value={s}>{s}</option>)}
                        </select>
                      </td>
                      <td className="text-dimmer" style={{ fontSize: 11 }}>{ev.detected_at}</td>
                      <td>
                        <button className="btn btn-ghost" style={{ padding: '2px 8px', fontSize: 11, color: 'var(--red)' }}
                          onClick={() => deleteOne(ev.id)}>删除</button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* ── Tab: 高危端口资产 ─────────────────────────────────── */}
      {tabActive === 'highRisk' && (
        <div className="card">
          <div className="card-header">
            <span className="card-title">🚨 高危端口资产（{highRisk.length}）</span>
            <span style={{ fontSize: 12, color: 'var(--text3)' }}>点击行查看详情 · SSH/RDP/Redis/MongoDB 等高风险端口</span>
          </div>
          {!initDone ? (
            <div className="empty-state"><span className="spinner"></span></div>
          ) : highRisk.length === 0 ? (
            <div className="empty-state">
              <div className="empty-icon">✓</div>
              <div style={{ color: 'var(--green)' }}>未发现高危端口暴露</div>
            </div>
          ) : (
            <div className="table-wrap">
              <table>
                <thead>
                  <tr><th>IP 地址</th><th>风险等级</th><th>高危端口</th><th>全部端口</th><th>最后在线</th></tr>
                </thead>
                <tbody>
                  {highRisk.map((asset, i) => (
                    <tr key={i} style={{ cursor: 'pointer' }}
                      onClick={() => setAssetDetail(asset)}
                      onMouseEnter={e => e.currentTarget.style.background = 'var(--card2)'}
                      onMouseLeave={e => e.currentTarget.style.background = ''}>
                      <td className="mono text-cyan">{asset.ip_address}</td>
                      <td>
                        <span style={{ fontWeight: 600, fontSize: 12, color: asset.risk_level === '高' ? 'var(--red)' : 'var(--text3)' }}>
                          {asset.risk_level || '未知'}
                        </span>
                      </td>
                      <td>
                        <div style={{ display: 'flex', flexWrap: 'wrap', gap: 4 }}>
                          {(asset.high_risk_ports || []).map(p => (
                            <span key={p.port} title={p.service} className="badge badge-red">{p.port}</span>
                          ))}
                        </div>
                      </td>
                      <td className="mono" style={{ fontSize: 11, color: 'var(--text2)', maxWidth: 200, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                        {asset.all_ports}
                      </td>
                      <td className="text-dimmer" style={{ fontSize: 11 }}>{asset.last_seen}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* ── Tab: 快照对比 ─────────────────────────────────────── */}
      {tabActive === 'snapshot' && (
        <div className="card">
          <div className="card-header"><span className="card-title">📊 资产快照对比</span></div>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr auto', gap: 12, alignItems: 'end', marginBottom: 16 }}>
            <div className="form-group" style={{ marginBottom: 0 }}>
              <label className="form-label">时间点 A（较早）</label>
              <select className="form-select" value={snapA} onChange={e => setSnapA(e.target.value)}>
                <option value="">请选择</option>
                {snapTimes.map(t => <option key={t} value={t}>{t}</option>)}
              </select>
            </div>
            <div className="form-group" style={{ marginBottom: 0 }}>
              <label className="form-label">时间点 B（较新）</label>
              <select className="form-select" value={snapB} onChange={e => setSnapB(e.target.value)}>
                <option value="">请选择</option>
                {snapTimes.map(t => <option key={t} value={t}>{t}</option>)}
              </select>
            </div>
            <button className="btn btn-primary" style={{ padding: '8px 20px', marginBottom: 14 }}
              onClick={doCompare} disabled={comparing}>
              {comparing ? <><span className="spinner"></span> 对比中...</> : '对比'}
            </button>
          </div>

          {snapTimes.length === 0 && !comparing && (
            <div style={{ fontSize: 13, color: 'var(--text3)', padding: '8px 0', lineHeight: 1.8 }}>
              💡 暂无快照数据。每次资产扫描完成后系统会自动保存快照，也可在<b>资产管理</b>页面手动触发保存。
            </div>
          )}

          {compareRes && (
            <div style={{ marginTop: 8 }}>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: 12, marginBottom: 20 }}>
                {[
                  { l: '新增资产', v: compareRes.added?.length || 0, c: 'var(--green)' },
                  { l: '消失资产', v: compareRes.removed?.length || 0, c: 'var(--orange)' },
                  { l: '端口变化', v: compareRes.changed?.length || 0, c: 'var(--cyan)' },
                ].map(s => (
                  <div key={s.l} style={{ textAlign: 'center', padding: '14px', background: 'var(--card2)', borderRadius: 10 }}>
                    <div style={{ fontSize: 30, fontFamily: 'Rajdhani', fontWeight: 700, color: s.c }}>{s.v}</div>
                    <div style={{ fontSize: 12, color: 'var(--text3)', marginTop: 4 }}>{s.l}</div>
                  </div>
                ))}
              </div>

              {compareRes.added?.length > 0 && (
                <div style={{ marginBottom: 16 }}>
                  <div style={{ fontSize: 13, fontWeight: 600, color: 'var(--green)', marginBottom: 8 }}>▲ 新增资产（{compareRes.added.length}）</div>
                  <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6 }}>
                    {compareRes.added.slice(0, 20).map((ip, i) => (
                      <span key={i} className="badge badge-green" style={{ fontFamily: 'JetBrains Mono', fontSize: 12 }}>{ip}</span>
                    ))}
                    {compareRes.added.length > 20 && <span style={{ fontSize: 12, color: 'var(--text3)' }}>...还有 {compareRes.added.length - 20} 个</span>}
                  </div>
                </div>
              )}

              {compareRes.removed?.length > 0 && (
                <div style={{ marginBottom: 16 }}>
                  <div style={{ fontSize: 13, fontWeight: 600, color: 'var(--orange)', marginBottom: 8 }}>▼ 消失资产（{compareRes.removed.length}）</div>
                  <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6 }}>
                    {compareRes.removed.slice(0, 20).map((ip, i) => (
                      <span key={i} className="badge badge-orange" style={{ fontFamily: 'JetBrains Mono', fontSize: 12 }}>{ip}</span>
                    ))}
                    {compareRes.removed.length > 20 && <span style={{ fontSize: 12, color: 'var(--text3)' }}>...还有 {compareRes.removed.length - 20} 个</span>}
                  </div>
                </div>
              )}

              {(!compareRes.added?.length && !compareRes.removed?.length) && (
                <div style={{ textAlign: 'center', padding: '24px', color: 'var(--green)', fontSize: 14 }}>
                  ✓ 两个时间点资产无变化
                </div>
              )}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
