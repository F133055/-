// pages/Assets.js — 无自动刷新，静默更新不白屏
function AssetsPage() {
  const [assets,      setAssets]      = useState([]);
  const [total,       setTotal]       = useState(0);
  const [initDone,    setInitDone]    = useState(false);
  const [refreshing,  setRefreshing]  = useState(false);
  const [scanTargets, setScanTargets] = useState('');
  const [scanning,    setScanning]    = useState(false);
  const [scanResult,  setScanResult]  = useState('');
  const [selected,    setSelected]    = useState([]);
  const [search,      setSearch]      = useState('');
  // 端口输入：'default'=默认常见端口，'custom'=自定义
  const [portMode,    setPortMode]    = useState('default');
  const [customPorts, setCustomPorts] = useState('');

  const DEFAULT_PORTS = [22, 53, 80, 135, 443, 3306, 6379, 8848];
  const DEFAULT_PORTS_LABEL = '22(SSH), 53(DNS), 80(HTTP), 135, 443(HTTPS), 3306(MySQL), 6379(Redis), 8848(Nacos)';

  // 解析端口输入：支持 "22,80,443" 和 "1-1000" 混合格式，上限1000个端口
  const parsePorts = (input) => {
    const parts = input.split(/[,\s]+/).filter(Boolean);
    const result = new Set();
    for (const p of parts) {
      if (p.includes('-')) {
        const [a, b] = p.split('-').map(Number);
        if (!isNaN(a) && !isNaN(b) && a >= 1 && b <= 65535 && a <= b) {
          if (b - a > 2000) { alert(`端口范围 ${p} 超过2000个，请缩小范围`); return null; }
          for (let i = a; i <= b; i++) result.add(i);
        }
      } else {
        const n = parseInt(p);
        if (!isNaN(n) && n >= 1 && n <= 65535) result.add(n);
      }
    }
    return result.size > 0 ? [...result].sort((a, b) => a - b) : null;
  };

  // 静默加载：不清空已有数据，无白屏
  const loadAssets = useCallback(async (isManual = false) => {
    if (isManual) setRefreshing(true);
    const r = await api.get('/api/assets/?limit=500');
    if (r?.data) { setAssets(r.data); setTotal(r.total || r.data.length); }
    setInitDone(true);
    if (isManual) setRefreshing(false);
  }, []);

  // 挂载时加载，之后每 30s 静默刷新
  useEffect(() => {
    loadAssets(false);
    const t = setInterval(() => loadAssets(false), 30000);
    return () => clearInterval(t);
  }, []);

  const startScan = async () => {
    const ips = scanTargets.split(/[\n,\s]+/).filter(Boolean);
    if (!ips.length) return;

    // 解析端口列表
    let ports = DEFAULT_PORTS;
    if (portMode === 'custom') {
      if (!customPorts.trim()) { alert('请输入自定义端口'); return; }
      const parsed = parsePorts(customPorts);
      if (!parsed) return;
      ports = parsed;
    }

    setScanning(true); setScanResult('');
    const r = await api.post('/api/scan/asset', { targets: ips, ports });
    setScanning(false);
    if (r?.task_id) {
      setScanResult(`✓ 任务已下发 (${r.task_id.slice(0,8)}...)，扫描端口共 ${ports.length} 个，完成后点击刷新查看结果`);
    } else {
      setScanResult('✗ 任务下发失败：' + (r?.detail || JSON.stringify(r)));
    }
  };

  const deleteAsset = async (id) => {
    if (!confirm('确认删除此资产？')) return;
    await api.delete(`/api/assets/${id}`);
    setAssets(prev => prev.filter(a => a.id !== id));
    setTotal(t => t - 1);
  };

  const batchDelete = async () => {
    if (!selected.length) return;
    if (!confirm(`确认删除所选 ${selected.length} 个资产？`)) return;
    const r = await api.post('/api/assets/batch-delete', { ids: selected });
    if (r?.code === 200) {
      setAssets(prev => prev.filter(a => !selected.includes(a.id)));
      setTotal(t => t - selected.length);
      setSelected([]);
    } else {
      alert('删除失败：' + (r?.detail || JSON.stringify(r)));
    }
  };

  const riskBadge = (risk) => {
    const m = {'高':'badge-red','中':'badge-orange','低':'badge-green','未知':'badge-gray'};
    return <span className={`badge ${m[risk]||'badge-gray'}`}>{risk||'未知'}</span>;
  };
  const statusBadge = s => s==='ONLINE'
    ? <span className="badge badge-green">在线</span>
    : <span className="badge badge-gray">离线</span>;

  const filtered = assets.filter(a =>
    !search || a.ip_address.includes(search) || (a.hostname||'').includes(search)
  );
  const allSelected = filtered.length > 0 && filtered.every(a => selected.includes(a.id));

  return (
    <div>
      <QSBanner/>
      <div className="flex-between mb-16">
        <div>
          <div style={{fontSize:22,fontFamily:'Rajdhani',fontWeight:700,letterSpacing:1}}>资产管理</div>
          <div style={{fontSize:12,color:'var(--text3)',marginTop:2}}>共 {total} 个资产</div>
        </div>
        <button className="btn btn-ghost" onClick={()=>loadAssets(true)} disabled={refreshing}>
          {refreshing ? <span className="spinner" style={{width:13,height:13}}></span> : icons.refresh} 刷新
        </button>
      </div>

      <div className="grid-2 section-gap">
        <div className="card">
          <div className="card-header"><span className="card-title">发起资产扫描</span></div>
          <div className="form-group">
            <label className="form-label">目标 IP / 域名 / URL（每行一个）</label>
            <textarea className="form-textarea" value={scanTargets}
              onChange={e=>setScanTargets(e.target.value)}
              placeholder={"192.168.1.1\n192.168.1.0/24\nhttps://example.com"} rows={4}/>
          </div>
          {/* 端口配置 */}
          <div className="form-group">
            <label className="form-label">扫描端口</label>
            <div style={{display:'flex',gap:8,marginBottom:6}}>
              <label style={{display:'flex',alignItems:'center',gap:5,fontSize:13,cursor:'pointer'}}>
                <input type="radio" checked={portMode==='default'} onChange={()=>setPortMode('default')}/>
                <span>默认端口（8个常用）</span>
              </label>
              <label style={{display:'flex',alignItems:'center',gap:5,fontSize:13,cursor:'pointer'}}>
                <input type="radio" checked={portMode==='custom'} onChange={()=>setPortMode('custom')}/>
                <span>自定义端口</span>
              </label>
            </div>
            {portMode==='default' ? (
              <div style={{fontSize:11,color:'var(--text3)',fontFamily:'monospace',background:'var(--bg)',
                padding:'6px 10px',borderRadius:6,lineHeight:1.8}}>
                {DEFAULT_PORTS_LABEL}
              </div>
            ) : (
              <div>
                <input className="form-input" value={customPorts} onChange={e=>setCustomPorts(e.target.value)}
                  placeholder="例：22,80,443,8080-8090,3000-3010"
                  style={{width:'100%',fontFamily:'monospace',fontSize:13}}/>
                <div style={{fontSize:11,color:'var(--text3)',marginTop:4}}>
                  支持逗号分隔（22,80,443）和连字符范围（1-1000），单次范围不超过2000个端口
                </div>
              </div>
            )}
          </div>
          {scanResult && <div className={`alert ${scanResult.startsWith('✓')?'alert-success':'alert-error'}`}>{scanResult}</div>}
          <button className="btn btn-primary" onClick={startScan} disabled={scanning}>
            {scanning ? <><span className="spinner"></span> 扫描中...</> : `${icons.scan} 开始扫描`}
          </button>
        </div>
        <div className="card">
          <div className="card-header"><span className="card-title">扫描说明</span></div>
          <div style={{fontSize:13,color:'var(--text2)',lineHeight:1.8}}>
            <div>📡 <b>支持格式</b>：IP / 域名 / CIDR / https:// URL</div>
            <div style={{marginTop:8}}>⚡ <b>多线程扫描</b>：50 并发线程</div>
            <div style={{marginTop:8}}>💾 <b>自动去重</b>：同IP重复扫描只更新，不重复写入</div>
            <div style={{marginTop:8}}>🔄 <b>状态追踪</b>：自动维护 online/offline 状态</div>
          </div>
        </div>
      </div>

      <div className="card">
        <div className="card-header">
          <span className="card-title">资产列表</span>
          <div className="flex gap-8">
            <input className="form-input" style={{width:180,padding:'5px 10px',fontSize:12}}
              value={search} onChange={e=>setSearch(e.target.value)}
              placeholder="搜索 IP / 主机名..."/>
            {selected.length > 0 && (
              <button className="btn btn-danger" style={{padding:'4px 10px',fontSize:12}} onClick={batchDelete}>
                删除所选 ({selected.length})
              </button>
            )}
          </div>
        </div>
        {!initDone ? (
          <div className="empty-state"><span className="spinner"></span></div>
        ) : filtered.length===0 ? (
          <div className="empty-state"><div className="empty-icon">⬡</div><div>暂无资产，请发起扫描</div></div>
        ) : (
          <div className="table-wrap"><table>
            <thead><tr>
              <th><input type="checkbox" checked={allSelected}
                onChange={e=>setSelected(e.target.checked ? filtered.map(a=>a.id) : [])}/></th>
              <th>IP 地址</th><th>开放端口</th><th>状态</th><th>风险等级</th>
              <th>首次发现</th><th>最后在线</th><th>操作</th>
            </tr></thead>
            <tbody>{filtered.map(a=>(
              <tr key={a.id}>
                <td><input type="checkbox" checked={selected.includes(a.id)}
                  onChange={e=>setSelected(s=>e.target.checked?[...s,a.id]:s.filter(i=>i!==a.id))}/></td>
                <td className="mono text-cyan">{a.ip_address}</td>
                <td className="mono" style={{fontSize:11,color:'var(--text2)',maxWidth:180,overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap'}}>{a.open_ports||'—'}</td>
                <td>{statusBadge(a.status)}</td>
                <td>{riskBadge(a.risk_level)}</td>
                <td className="text-dimmer" style={{fontSize:11}}>{a.first_seen||'—'}</td>
                <td className="text-dimmer" style={{fontSize:11}}>{a.last_seen||'—'}</td>
                <td><button className="btn btn-danger" style={{padding:'3px 8px',fontSize:11}} onClick={()=>deleteAsset(a.id)}>删除</button></td>
              </tr>
            ))}</tbody>
          </table></div>
        )}
      </div>
    </div>
  );
}
