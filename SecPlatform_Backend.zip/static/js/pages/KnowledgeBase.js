// pages/KnowledgeBase.js - 安全知识库页面
function KnowledgeBasePage() {
  const [docs, setDocs]       = useState([]);
  const [loading, setLoading] = useState(false);
  const [search, setSearch]   = useState('');
  const [catFilter, setCat]   = useState('全部');
  const [showAdd, setShowAdd] = useState(false);
  const [selected, setSelected] = useState(null);
  const [aiQuery, setAiQuery] = useState('');
  const [aiResp, setAiResp]   = useState('');
  const [aiLoading, setAiLoading] = useState(false);
  const [form, setForm]       = useState({ title:'', category:'安全规范', content:'', tags:'' });
  const [saving, setSaving]   = useState(false);
  const [msg, setMsg]         = useState('');

  const CATEGORIES = ['全部','安全规范','安全文档','安全事件','漏洞知识','处置指南'];

  const load = async () => {
    setLoading(true);
    const r = await api.get('/api/knowledge/');
    if (r?.data) setDocs(r.data);
    setLoading(false);
  };

  useEffect(() => { load(); }, []);

  const filtered = docs.filter(d => {
    const matchCat  = catFilter === '全部' || d.category === catFilter;
    const matchText = !search || d.title.includes(search) || (d.tags||'').includes(search) || (d.content||'').includes(search);
    return matchCat && matchText;
  });

  const save = async () => {
    if (!form.title.trim() || !form.content.trim()) {
      setMsg('✗ 标题和内容不能为空'); setTimeout(()=>setMsg(''),3000); return;
    }
    setSaving(true);
    const r = await api.post('/api/knowledge/', form);
    setSaving(false);
    if (r?.code === 200) {
      setMsg('✓ 保存成功'); setShowAdd(false); setForm({ title:'', category:'安全规范', content:'', tags:'' }); load();
    } else {
      setMsg('✗ ' + (r?.detail || '保存失败'));
    }
    setTimeout(()=>setMsg(''),3000);
  };

  const del = async (id) => {
    if (!confirm('确认删除？')) return;
    await api.delete(`/api/knowledge/${id}`);
    if (selected?.id === id) setSelected(null);
    load();
  };

  const askAI = async () => {
    if (!aiQuery.trim()) return;
    setAiLoading(true); setAiResp('');
    const r = await api.post('/api/knowledge/query', { question: aiQuery });
    setAiResp(r?.answer || '暂无相关知识，请补充知识库内容。');
    setAiLoading(false);
  };

  const catColors = { '安全规范':'var(--cyan)', '安全文档':'var(--blue)', '安全事件':'var(--red)', '漏洞知识':'var(--orange)', '处置指南':'var(--green)' };

  return (
    <div>
      <div className="mb-16" style={{display:'flex',justifyContent:'space-between',alignItems:'flex-start'}}>
        <div>
          <div style={{fontSize:22,fontFamily:'Rajdhani',fontWeight:700,letterSpacing:1}}>安全知识库</div>
          <div style={{fontSize:12,color:'var(--text3)',marginTop:2}}>统一管理安全文档、规范与事件记录，支持 AI 检索</div>
        </div>
        <button className="btn btn-primary" onClick={()=>setShowAdd(true)}>+ 新增文档</button>
      </div>

      {/* AI 检索框 */}
      <div className="card section-gap" style={{background:'linear-gradient(135deg,rgba(0,229,255,.04),rgba(0,229,255,.01))'}}>
        <div className="card-header">
          <span className="card-title">🤖 AI 智能检索</span>
          <span style={{fontSize:11,color:'var(--text3)'}}>基于知识库内容进行语义问答</span>
        </div>
        <div style={{display:'flex',gap:8}}>
          <input className="form-input" style={{flex:1}} value={aiQuery}
            onChange={e=>setAiQuery(e.target.value)}
            onKeyDown={e=>e.key==='Enter'&&askAI()}
            placeholder="输入安全问题，如：Redis未授权访问如何修复？"/>
          <button className="btn btn-primary" onClick={askAI} disabled={aiLoading} style={{minWidth:88}}>
            {aiLoading ? <><span className="spinner"></span> 检索中</> : '🔍 检索'}
          </button>
        </div>
        {aiResp && (
          <div style={{marginTop:12,padding:'12px 16px',background:'var(--card2)',borderRadius:8,border:'1px solid var(--border)',fontSize:13,lineHeight:1.8,color:'var(--text)',whiteSpace:'pre-wrap'}}>
            <div style={{fontSize:11,color:'var(--cyan)',marginBottom:6}}>▸ AI 回答</div>
            {aiResp}
          </div>
        )}
      </div>

      <div style={{display:'grid',gridTemplateColumns:'220px 1fr',gap:16,marginTop:16}}>
        {/* 左侧分类 + 列表 */}
        <div>
          <div className="card" style={{marginBottom:12}}>
            <div style={{padding:'4px 0'}}>
              {CATEGORIES.map(c=>(
                <div key={c} onClick={()=>setCat(c)}
                  style={{padding:'8px 12px',borderRadius:6,cursor:'pointer',fontSize:13,
                    background:catFilter===c?'rgba(0,229,255,.1)':'transparent',
                    color:catFilter===c?'var(--cyan)':'var(--text2)',
                    borderLeft:catFilter===c?'2px solid var(--cyan)':'2px solid transparent',
                    marginBottom:2,transition:'all .15s'}}>
                  {c}
                  <span style={{float:'right',fontSize:11,color:'var(--text3)'}}>
                    {c==='全部' ? docs.length : docs.filter(d=>d.category===c).length}
                  </span>
                </div>
              ))}
            </div>
          </div>
          <input className="form-input" value={search} onChange={e=>setSearch(e.target.value)}
            placeholder="🔎 搜索标题/标签" style={{width:'100%',boxSizing:'border-box'}}/>
        </div>

        {/* 右侧内容 */}
        <div>
          {selected ? (
            <div className="card">
              <div className="card-header">
                <div>
                  <span className="card-title">{selected.title}</span>
                  <span style={{marginLeft:10,fontSize:11,padding:'2px 8px',borderRadius:4,
                    background:'rgba(0,229,255,.1)',color:catColors[selected.category]||'var(--cyan)'}}>
                    {selected.category}
                  </span>
                </div>
                <div style={{display:'flex',gap:8}}>
                  <button className="btn btn-ghost" onClick={()=>del(selected.id)}>🗑 删除</button>
                  <button className="btn btn-ghost" onClick={()=>setSelected(null)}>← 返回</button>
                </div>
              </div>
              {selected.tags && (
                <div style={{marginBottom:12,display:'flex',gap:6,flexWrap:'wrap'}}>
                  {selected.tags.split(',').map(t=>t.trim()).filter(Boolean).map(t=>(
                    <span key={t} style={{fontSize:11,padding:'2px 8px',borderRadius:10,
                      background:'var(--card2)',color:'var(--text3)',border:'1px solid var(--border)'}}>#{t}</span>
                  ))}
                </div>
              )}
              <div style={{fontSize:13,lineHeight:1.9,color:'var(--text)',whiteSpace:'pre-wrap',
                padding:'12px',background:'var(--card2)',borderRadius:8,maxHeight:500,overflowY:'auto'}}>
                {selected.content}
              </div>
              <div style={{fontSize:11,color:'var(--text3)',marginTop:8}}>
                创建时间：{selected.created_at ? new Date(selected.created_at).toLocaleString('zh-CN') : '-'}
              </div>
            </div>
          ) : (
            <div>
              {loading && <div style={{textAlign:'center',padding:40,color:'var(--text3)'}}>加载中…</div>}
              {!loading && filtered.length === 0 && (
                <div style={{textAlign:'center',padding:60,color:'var(--text3)'}}>
                  <div style={{fontSize:36,marginBottom:8}}>📚</div>
                  <div>暂无文档，点击「新增文档」开始构建知识库</div>
                </div>
              )}
              <div style={{display:'flex',flexDirection:'column',gap:10}}>
                {filtered.map(doc=>(
                  <div key={doc.id} className="card" style={{cursor:'pointer',transition:'border-color .15s'}}
                    onClick={()=>setSelected(doc)}
                    onMouseEnter={e=>e.currentTarget.style.borderColor='var(--cyan)'}
                    onMouseLeave={e=>e.currentTarget.style.borderColor=''}>
                    <div style={{display:'flex',justifyContent:'space-between',alignItems:'flex-start'}}>
                      <div style={{flex:1}}>
                        <div style={{fontWeight:600,fontSize:14,marginBottom:4}}>{doc.title}</div>
                        <div style={{fontSize:12,color:'var(--text3)',overflow:'hidden',
                          display:'-webkit-box',WebkitLineClamp:2,WebkitBoxOrient:'vertical'}}>
                          {doc.content?.slice(0,120)}…
                        </div>
                        {doc.tags && (
                          <div style={{marginTop:6,display:'flex',gap:4,flexWrap:'wrap'}}>
                            {doc.tags.split(',').slice(0,4).map(t=>t.trim()).filter(Boolean).map(t=>(
                              <span key={t} style={{fontSize:10,padding:'1px 6px',borderRadius:8,
                                background:'var(--card2)',color:'var(--text3)'}}>#{t}</span>
                            ))}
                          </div>
                        )}
                      </div>
                      <div style={{marginLeft:12,textAlign:'right',flexShrink:0}}>
                        <span style={{fontSize:11,padding:'2px 8px',borderRadius:4,
                          background:'rgba(0,229,255,.08)',color:catColors[doc.category]||'var(--cyan)'}}>
                          {doc.category}
                        </span>
                        <div style={{fontSize:10,color:'var(--text3)',marginTop:4}}>
                          {doc.created_at ? new Date(doc.created_at).toLocaleDateString('zh-CN') : ''}
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* 新增弹窗 */}
      {/* 新增弹窗 - Modal Portal */}
      <Modal show={showAdd} onClose={()=>setShowAdd(false)} title="📝 新增文档" width={600}>
            <div className="form-group">
              <label className="form-label">标题 *</label>
              <input className="form-input" value={form.title} onChange={e=>setForm(f=>({...f,title:e.target.value}))} placeholder="文档标题"/>
            </div>
            <div className="form-group">
              <label className="form-label">分类</label>
              <select className="form-input" value={form.category} onChange={e=>setForm(f=>({...f,category:e.target.value}))}>
                {CATEGORIES.filter(c=>c!=='全部').map(c=><option key={c}>{c}</option>)}
              </select>
            </div>
            <div className="form-group">
              <label className="form-label">内容 *</label>
              <textarea className="form-input" rows={10} value={form.content}
                onChange={e=>setForm(f=>({...f,content:e.target.value}))}
                placeholder="支持纯文本，可记录安全规范、漏洞详情、处置步骤等..."
                style={{resize:'vertical',fontFamily:'JetBrains Mono',fontSize:13}}/>
            </div>
            <div className="form-group">
              <label className="form-label">标签（逗号分隔）</label>
              <input className="form-input" value={form.tags} onChange={e=>setForm(f=>({...f,tags:e.target.value}))} placeholder="Redis, 未授权访问, 高危"/>
            </div>
            {msg && <div className={`alert ${msg.startsWith('✓')?'alert-success':'alert-error'}`}>{msg}</div>}
            <div className="flex gap-8">
              <button className="btn btn-primary" onClick={save} disabled={saving}>
                {saving ? <><span className="spinner"></span> 保存中</> : '保存'}
              </button>
              <button className="btn btn-ghost" onClick={()=>setShowAdd(false)}>取消</button>
            </div>
      </Modal>
    </div>
  );
}
