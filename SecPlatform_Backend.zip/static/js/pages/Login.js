// pages/Login.js
// 登录页 - 记住账号/密码（类似QQ），有token时5秒倒计时后自动登录

function LoginPage({ onLogin, autoLoginUser }) {
  const [savedAccounts] = useState(() => {
    try { return JSON.parse(localStorage.getItem('sec_accounts') || '[]'); } catch { return []; }
  });
  const lastUser    = localStorage.getItem('sec_last_user') || '';
  const lastAccount = savedAccounts.find(a => a.username === lastUser);

  const [username,    setUsername]    = useState(lastUser);
  const [password,    setPassword]    = useState(lastAccount?.rememberPwd ? lastAccount.password : '');
  const [rememberPwd, setRememberPwd] = useState(!!lastAccount?.rememberPwd);
  const [showPwd,     setShowPwd]     = useState(false);
  const [showDropdown,setShowDropdown]= useState(false);
  const [loading,     setLoading]     = useState(false);
  const [error,       setError]       = useState('');
  const [countdown,   setCountdown]   = useState(0);      // 0 = 不显示
  const [validating,  setValidating]  = useState(false);  // 正在验证 token

  // 有已保存的 token，验证有效性后开始倒计时
  useEffect(() => {
    if (!autoLoginUser) return;

    let cancelled = false;
    setValidating(true);

    // 用健康检查接口验证 token（带鉴权）
    api.get('/api/assets/stats/summary').then(r => {
      if (cancelled) return;
      setValidating(false);
      if (r === null) {
        // 401 or 网络错误，api.js 已清除 token 并 reload，这里不会执行到
        return;
      }
      // token 有效，开始倒计时
      let count = 8;
      setCountdown(count);
      const timer = setInterval(() => {
        if (cancelled) { clearInterval(timer); return; }
        count--;
        setCountdown(count);
        if (count <= 0) {
          clearInterval(timer);
          onLogin(autoLoginUser);
        }
      }, 1000);
      return () => clearInterval(timer);
    });

    return () => { cancelled = true; };
  }, [autoLoginUser]);

  const saveAccount = (uname, pwd, remPwd) => {
    let accounts = [];
    try { accounts = JSON.parse(localStorage.getItem('sec_accounts') || '[]'); } catch {}
    const idx = accounts.findIndex(a => a.username === uname);
    const entry = { username: uname, rememberPwd: remPwd, password: remPwd ? pwd : '' };
    if (idx >= 0) accounts[idx] = entry; else accounts.unshift(entry);
    localStorage.setItem('sec_accounts', JSON.stringify(accounts.slice(0, 5)));
    localStorage.setItem('sec_last_user', uname);
  };

  const handleLogin = async () => {
    if (!username || !password) { setError('请输入用户名和密码'); return; }
    setLoading(true); setError('');
    const data = await api.login(username, password);
    setLoading(false);
    if (data?.access_token) {
      api.setToken(data.access_token);
      saveAccount(username, password, rememberPwd);
      onLogin(username);
    } else {
      setError(data?.detail || '用户名或密码错误');
    }
  };

  const cancelAutoLogin = () => {
    setCountdown(0);
    api.clearToken();
  };

  const selectAccount = (acc) => {
    setUsername(acc.username);
    setPassword(acc.rememberPwd ? acc.password : '');
    setRememberPwd(acc.rememberPwd);
    setShowDropdown(false);
  };

  const removeAccount = (e, uname) => {
    e.stopPropagation();
    let accounts = [];
    try { accounts = JSON.parse(localStorage.getItem('sec_accounts') || '[]'); } catch {}
    localStorage.setItem('sec_accounts', JSON.stringify(accounts.filter(a => a.username !== uname)));
    if (uname === username) { setUsername(''); setPassword(''); }
    window.location.reload();
  };

  return (
    <div className="login-page" onClick={() => setShowDropdown(false)}>
      <div className="login-card">
        {/* Logo */}
        <div className="login-logo">
          <div className="big">SECPLATFORM</div>
          <div className="sub">安全专项扫描与智能分析平台</div>
        </div>

        {/* 自动登录倒计时横幅 */}
        {(validating || countdown > 0) && (
          <div style={{
            background:'rgba(0,229,255,.06)',
            border:'1px solid rgba(0,229,255,.3)',
            borderRadius:10, padding:'18px 20px', marginBottom:16,
            textAlign:'center',
          }}>
            {validating ? (
              <div style={{color:'var(--text2)',fontSize:13,display:'flex',alignItems:'center',justifyContent:'center',gap:8}}>
                <span className="spinner"></span> 正在验证登录状态...
              </div>
            ) : (
              <>
                <div style={{fontSize:11,color:'var(--text3)',letterSpacing:1,marginBottom:6,textTransform:'uppercase'}}>检测到已登录账号</div>
                <div style={{
                  fontSize:42, fontFamily:'Rajdhani', fontWeight:700,
                  color:'var(--cyan)', lineHeight:1, marginBottom:2,
                }}>{countdown}</div>
                <div style={{fontSize:13,color:'var(--text2)',margin:'6px 0'}}>
                  秒后自动登录为 <strong style={{color:'var(--cyan)'}}>{autoLoginUser}</strong>
                </div>
                <div style={{width:'100%',height:3,background:'var(--border)',borderRadius:2,margin:'10px 0 12px',overflow:'hidden'}}>
                  <div style={{height:'100%',background:'var(--cyan)',borderRadius:2,transition:'width 1s linear',width:`${(countdown/8)*100}%`}}></div>
                </div>
                <button
                  className="btn btn-ghost"
                  style={{padding:'5px 16px',fontSize:12}}
                  onClick={cancelAutoLogin}
                >切换账号 / 手动登录</button>
              </>
            )}
          </div>
        )}

        {/* 登录表单 */}
        <div className="card">
          {error && <div className="alert alert-error" style={{marginBottom:12}}>{error}</div>}

          {/* 用户名 + 账号选择器 */}
          <div className="form-group">
            <label className="form-label">用户名</label>
            <div style={{position:'relative'}} onClick={e => e.stopPropagation()}>
              <div style={{display:'flex',gap:6}}>
                <input
                  className="form-input"
                  value={username}
                  onChange={e => setUsername(e.target.value)}
                  onKeyDown={e => e.key === 'Enter' && handleLogin()}
                  placeholder="请输入用户名"
                  style={{flex:1}}
                />
                {savedAccounts.length > 0 && (
                  <button
                    className="btn btn-ghost"
                    style={{padding:'6px 10px',fontSize:14,flexShrink:0}}
                    onClick={() => setShowDropdown(v => !v)}
                    title="选择已保存账号"
                  >▾</button>
                )}
              </div>

              {/* 账号下拉 */}
              {showDropdown && savedAccounts.length > 0 && (
                <div style={{
                  position:'absolute', top:'calc(100% + 4px)', left:0, right:0, zIndex:99,
                  background:'var(--card)', border:'1px solid var(--border)',
                  borderRadius:8, boxShadow:'0 8px 24px rgba(0,0,0,.5)', overflow:'hidden',
                }}>
                  {savedAccounts.map(acc => (
                    <div
                      key={acc.username}
                      onClick={() => selectAccount(acc)}
                      style={{
                        display:'flex', alignItems:'center', gap:10,
                        padding:'10px 14px', cursor:'pointer',
                        borderBottom:'1px solid var(--border)',
                      }}
                      onMouseEnter={e => e.currentTarget.style.background = 'var(--card2)'}
                      onMouseLeave={e => e.currentTarget.style.background = ''}
                    >
                      <div style={{
                        width:30, height:30, borderRadius:'50%', flexShrink:0,
                        background:'linear-gradient(135deg,var(--cyan),var(--blue))',
                        display:'flex', alignItems:'center', justifyContent:'center',
                        fontSize:13, fontWeight:700, color:'#000',
                      }}>{acc.username[0]?.toUpperCase()}</div>
                      <div style={{flex:1, minWidth:0}}>
                        <div style={{fontSize:13, fontWeight:500}}>{acc.username}</div>
                        <div style={{fontSize:11, color:'var(--text3)'}}>
                          {acc.rememberPwd ? '✓ 已记住密码' : '未记住密码'}
                        </div>
                      </div>
                      <button
                        onClick={e => removeAccount(e, acc.username)}
                        title="移除此账号"
                        style={{background:'none',border:'none',cursor:'pointer',color:'var(--text3)',fontSize:13,padding:'2px 5px'}}
                      >✕</button>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* 密码 */}
          <div className="form-group">
            <label className="form-label">密码</label>
            <div style={{position:'relative'}}>
              <input
                className="form-input"
                type={showPwd ? 'text' : 'password'}
                value={password}
                onChange={e => setPassword(e.target.value)}
                onKeyDown={e => e.key === 'Enter' && handleLogin()}
                placeholder="请输入密码"
                style={{paddingRight:40}}
              />
              <span
                onClick={() => setShowPwd(v => !v)}
                style={{
                  position:'absolute', right:12, top:'50%', transform:'translateY(-50%)',
                  cursor:'pointer', color:'var(--text3)', fontSize:15, userSelect:'none',
                }}
              >{showPwd ? '🙈' : '👁'}</span>
            </div>
          </div>

          {/* 记住密码 */}
          <div style={{display:'flex',alignItems:'center',gap:8,marginBottom:16}}>
            <label style={{display:'flex',alignItems:'center',gap:6,cursor:'pointer',fontSize:13,color:'var(--text2)'}}>
              <input type="checkbox" checked={rememberPwd} onChange={e => setRememberPwd(e.target.checked)} />
              记住密码
            </label>
            <span style={{fontSize:11,color:'var(--text3)'}}>（账号名始终保存）</span>
          </div>

          <button
            className="btn btn-primary"
            style={{width:'100%',justifyContent:'center',padding:'10px',fontSize:14}}
            onClick={handleLogin}
            disabled={loading}
          >
            {loading ? <><span className="spinner"></span> 登录中...</> : '登 录'}
          </button>

          <div style={{textAlign:'center',marginTop:12,fontSize:11,color:'var(--text3)'}}>
            新用户请联系管理员 · 账号在 .env 文件中配置
          </div>
        </div>
      </div>
    </div>
  );
}
