// pages/Scans.js — 无自动刷新，worker状态只在首次加载
function DictUpload({ type, label }) {
  const [file,      setFile]      = useState(null);
  const [msg,       setMsg]       = useState('');
  const [uploading, setUploading] = useState(false);
  const [dictInfo,  setDictInfo]  = useState(null);

  useEffect(() => {
    api.get('/api/scan/dict/status').then(r => {
      if (r?.data) setDictInfo(r.data[type]);
    });
  }, [type]);

  const upload = async () => {
    if (!file) return;
    setUploading(true); setMsg('');
    const fd = new FormData();
    fd.append('dict_type', type);
    fd.append('file', file);
    try {
      const r = await fetch('/api/scan/upload/dict', {
        method:'POST', headers:{Authorization:`Bearer ${api.token}`}, body:fd
      });
      const data = await r.json();
      if (data.code===200) { setMsg(`✓ ${data.message}`); setDictInfo({exists:true,lines:data.line_count}); setFile(null); }
      else setMsg(`✗ ${data.detail||'失败'}`);
    } catch(e) { setMsg('✗ 上传失败'); }
    setUploading(false);
  };

  return (
    <div style={{border:'1px solid var(--border)',borderRadius:8,padding:12}}>
      <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:8}}>
        <span className="form-label" style={{marginBottom:0}}>{label}</span>
        {dictInfo?.exists
          ? <span style={{fontSize:11,color:'var(--green)',background:'rgba(34,197,94,0.1)',padding:'2px 8px',borderRadius:10}}>✓ 已存在 {dictInfo.lines} 行</span>
          : <span style={{fontSize:11,color:'var(--text3)'}}>未上传</span>
        }
      </div>
      <div style={{display:'flex',gap:8,alignItems:'center'}}>
        <input type="file" accept=".txt" onChange={e=>setFile(e.target.files[0])} style={{fontSize:12,color:'var(--text2)',flex:1}}/>
        <button className="btn btn-ghost" style={{padding:'5px 10px',fontSize:12,whiteSpace:'nowrap'}} onClick={upload} disabled={!file||uploading}>
          {uploading?<span className="spinner"></span>:'上传'}
        </button>
      </div>
      {msg && <div style={{fontSize:11,marginTop:6,color:msg.startsWith('✓')?'var(--green)':'var(--red)'}}>{msg}</div>}
    </div>
  );
}

function ScansPage() {
  const [weakTargets, setWeakTargets] = useState('');
  const [weakService, setWeakService] = useState('ssh');
  const [scanning,    setScanning]    = useState(false);
  const [scanMsg,     setScanMsg]     = useState('');
  const [workerOk,    setWorkerOk]    = useState(null);
  const [checking,    setChecking]    = useState(false);

  // Worker只在首次加载检查一次，之后手动检查
  useEffect(() => {
    api.get('/api/health/worker').then(r => setWorkerOk(r?.running === true));
  }, []);

  const checkWorker = async () => {
    setChecking(true);
    const r = await api.get('/api/health/worker');
    setWorkerOk(r?.running === true);
    setChecking(false);
  };

  const startWeakpass = async () => {
    const ips = weakTargets.split(/[\n,\s]+/).filter(Boolean);
    if (!ips.length) { setScanMsg('✗ 请输入目标IP'); return; }
    setScanning(true); setScanMsg('');
    const r = await api.post('/api/scan/weakness', { targets: ips, service: weakService });
    setScanning(false);
    if (r?.task_ids?.length) {
      setScanMsg(`✓ 已下发 ${r.task_ids.length} 个任务，请前往「历史任务」页查看进度`);
    } else {
      setScanMsg(`✗ 下发失败: ${r?.detail || r?.message || JSON.stringify(r)}`);
    }
  };

  const SERVICES = ['ssh','mysql','redis','ftp','postgresql','telnet','mongodb','mssql','oracle','dm','web'];
  const SERVICE_LABELS = {
    ssh:'SSH', mysql:'MySQL', redis:'Redis', ftp:'FTP',
    postgresql:'PostgreSQL', telnet:'Telnet', mongodb:'MongoDB',
    mssql:'SQL Server', oracle:'Oracle', dm:'达梦(DM)', web:'Web系统'
  };

  return (
    <div>
      <div className="flex-between mb-16">
        <div>
          <div style={{fontSize:22,fontFamily:'Rajdhani',fontWeight:700,letterSpacing:1}}>弱口令检测</div>
          <div style={{fontSize:12,color:'var(--text3)',marginTop:2}}>支持 SSH / MySQL / Redis 等多种服务弱密码检测</div>
        </div>
        <button className="btn btn-ghost" onClick={checkWorker} disabled={checking}>
          {checking ? <span className="spinner" style={{width:13,height:13}}></span> : icons.refresh} 检查Worker状态
        </button>
      </div>

      {workerOk===false && (
        <div className="alert alert-error" style={{marginBottom:16}}>
          <div style={{fontWeight:600,marginBottom:4}}>⚠️ Celery Worker 未运行！任务将一直等待。</div>
          <div style={{fontSize:12,opacity:0.85}}>
            使用 <strong>start.bat</strong> 启动（已内置 Celery）。或手动运行：<br/>
            <code style={{background:'rgba(0,0,0,0.3)',padding:'2px 8px',borderRadius:3,fontFamily:'monospace'}}>
              python -m celery -A celery_app worker --pool=solo --loglevel=info
            </code>
          </div>
        </div>
      )}
      {workerOk===true && (
        <div className="alert alert-success" style={{marginBottom:16}}>✓ Celery Worker 运行正常</div>
      )}

      <div className="card section-gap">
        <div className="card-header"><span className="card-title">弱口令检测</span></div>
        <div style={{display:'grid',gridTemplateColumns:'1fr 180px',gap:16,alignItems:'end'}}>
          <div className="form-group" style={{marginBottom:0}}>
            <label className="form-label">目标 IP（每行一个）</label>
            <textarea className="form-textarea" value={weakTargets}
              onChange={e=>setWeakTargets(e.target.value)}
              placeholder={"192.168.1.1\n10.0.0.1"} rows={3}/>
          </div>
          <div>
            <div className="form-group" style={{marginBottom:8}}>
              <label className="form-label">服务类型</label>
              <select className="form-select" value={weakService} onChange={e=>setWeakService(e.target.value)}>
                {SERVICES.map(s=><option key={s} value={s}>{SERVICE_LABELS[s]||s.toUpperCase()}</option>)}
              </select>
            </div>
            <button className="btn btn-primary" style={{width:'100%',justifyContent:'center'}} onClick={startWeakpass} disabled={scanning}>
              {scanning?<><span className="spinner"></span> 下发中...</>:'🔑 开始检测'}
            </button>
          </div>
        </div>
        {scanMsg && <div className={`alert ${scanMsg.startsWith('✓')?'alert-success':'alert-error'} mt-16`}>{scanMsg}</div>}
      </div>

      <div className="card section-gap">
        <div className="card-header"><span className="card-title">📖 爆破字典管理</span></div>
        <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:16}}>
          <DictUpload type="users" label="用户名字典 (users.txt)"/>
          <DictUpload type="pass"  label="密码字典 (pass.txt)"/>
        </div>
      </div>

      <div className="card" style={{background:'rgba(0,229,255,0.03)',border:'1px solid rgba(0,229,255,0.12)'}}>
        <div style={{display:'flex',alignItems:'center',gap:10,padding:'12px 16px',fontSize:13,color:'var(--text2)'}}>
          <span style={{fontSize:18,opacity:0.7}}>▷</span>
          <span>完整任务历史请前往侧边栏 <strong style={{color:'var(--cyan)'}}>「历史任务」</strong> 页面——支持按类型/状态过滤，可点击查看详情、删除任务记录。</span>
        </div>
      </div>
    </div>
  );
}
