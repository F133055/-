// pages/Reports.js
function ReportsPage() {
  const [reports,    setReports]    = useState([]);
  const [initDone,   setInitDone]   = useState(false);
  const [refreshing, setRefreshing] = useState(false);
  const [generating, setGenerating] = useState('');   // 'daily'|'weekly'|''
  const [msg,        setMsg]        = useState('');
  const [preview,    setPreview]    = useState(null); // {id,html}
  const [deleting,   setDeleting]   = useState(null);
  const [selected,   setSelected]   = useState([]);
  const [batchDel,   setBatchDel]   = useState(false);

  // 异常检测面板
  const [anomalies,  setAnomalies]  = useState(null);
  const [anomLoading,setAnomLoading]= useState(false);

  // 资产变化对比
  const [comparison, setComparison] = useState(null);
  const [compDays,   setCompDays]   = useState(1);
  const [compLoading,setCompLoading]= useState(false);

  const load = useCallback(async (isManual = false) => {
    if (isManual) setRefreshing(true);
    const r = await api.get('/api/reports/');
    if (r?.data) setReports(r.data);
    setInitDone(true);
    if (isManual) { setRefreshing(false); setSelected([]); }
  }, []);

  useEffect(() => { load(false); }, []);

  const genReport = async (type) => {
    setGenerating(type); setMsg('');
    const url = type === 'daily' ? '/api/reports/generate/daily' : '/api/reports/generate/weekly';
    const r = await api.post(url, {});
    setGenerating('');
    if (r?.report_id) {
      setMsg(`✓ ${type === 'daily' ? '日报' : '周报'}生成成功 (ID: ${r.report_id})`);
      load(false);
    } else {
      setMsg('✗ 生成失败：' + (r?.detail || ''));
    }
  };

  const loadAnomalies = async () => {
    setAnomLoading(true);
    const r = await api.get('/api/reports/anomaly');
    if (r?.data != null) setAnomalies(r.data);
    setAnomLoading(false);
  };

  const loadComparison = async () => {
    setCompLoading(true);
    const r = await api.get('/api/reports/asset-comparison?days=' + compDays);
    if (r?.data) setComparison(r.data);
    setCompLoading(false);
  };

  const viewReport = async (id) => {
    const r = await fetch(`/api/reports/${id}`, { headers: { Authorization: `Bearer ${api.token}` } });
    const html = await r.text();
    setPreview({ id, html });
  };

  const deleteOne = async (id, title) => {
    if (!confirm(`确认删除报告「${title}」？`)) return;
    setDeleting(id);
    const r = await api.req('DELETE', `/api/reports/${id}`);
    setDeleting(null);
    if (r?.code === 200) {
      setMsg('✓ 报告已删除');
      setReports(prev => prev.filter(rep => rep.id !== id));
      setSelected(prev => prev.filter(i => i !== id));
    } else {
      setMsg('✗ 删除失败：' + (r?.detail || ''));
    }
  };

  const deleteBatch = async () => {
    if (!selected.length) return;
    if (!confirm(`确认删除所选 ${selected.length} 份报告？`)) return;
    setBatchDel(true); setMsg('');
    let ok = 0;
    for (const id of selected) {
      const r = await api.req('DELETE', `/api/reports/${id}`);
      if (r?.code === 200) ok++;
    }
    setBatchDel(false);
    setMsg(`✓ 已删除 ${ok} 份报告`);
    setReports(prev => prev.filter(rep => !selected.includes(rep.id)));
    setSelected([]);
  };

  const typeLabel = { daily: '日报', weekly: '周报', custom: '专项' };
  const allSelected  = reports.length > 0 && reports.every(r => selected.includes(r.id));
  const someSelected = selected.length > 0;
  const toggleOne    = (id) => setSelected(prev => prev.includes(id) ? prev.filter(i => i !== id) : [...prev, id]);

  const levelBadge = (l) => {
    const m = { 高: 'badge-red', 中: 'badge-orange', 低: 'badge-green' };
    return <span className={`badge ${m[l] || 'badge-gray'}`}>{l}</span>;
  };

  return (
    <div>
      {/* 报告预览全屏 */}
      {preview && (
        <div style={{ position:'fixed', inset:0, background:'rgba(0,0,0,.88)', zIndex:500, display:'flex', flexDirection:'column' }}>
          <div style={{ padding:'10px 20px', background:'var(--surface)', borderBottom:'1px solid var(--border)', display:'flex', alignItems:'center', justifyContent:'space-between', flexShrink:0 }}>
            <div style={{ fontSize:14, fontWeight:600 }}>📄 报告预览</div>
            <div style={{ display:'flex', gap:8 }}>
              <button className="btn btn-ghost" style={{ fontSize:12 }}
                onClick={() => { const w = window.open('','_blank'); w.document.write(preview.html); w.document.close(); }}>
                ↗ 新标签打开
              </button>
              <button className="btn btn-ghost" style={{ color:'var(--red)', fontSize:12 }} onClick={() => setPreview(null)}>✕ 关闭</button>
            </div>
          </div>
          <iframe srcDoc={preview.html} style={{ flex:1, border:'none', background:'white' }} title="报告预览"/>
        </div>
      )}

      <div className="flex-between mb-16">
        <div>
          <div style={{ fontSize:22, fontFamily:'Rajdhani', fontWeight:700, letterSpacing:1 }}>安全报告</div>
          <div style={{ fontSize:12, color:'var(--text3)', marginTop:2 }}>自动报告生成 · 资产变化分析 · 异常检测</div>
        </div>
        <div style={{ display:'flex', gap:8 }}>
          <button className="btn btn-primary" onClick={() => genReport('daily')} disabled={!!generating}>
            {generating === 'daily' ? <><span className="spinner"></span> 生成中...</> : '▤ 生成日报'}
          </button>
          <button className="btn btn-ghost" onClick={() => genReport('weekly')} disabled={!!generating}>
            {generating === 'weekly' ? <><span className="spinner"></span> 生成中...</> : '📅 生成周报'}
          </button>
          <button className="btn btn-ghost" onClick={() => load(true)} disabled={refreshing}>
            {refreshing ? <span className="spinner" style={{ width:13, height:13 }}></span> : icons.refresh}
          </button>
        </div>
      </div>

      {msg && <div className={`alert ${msg.startsWith('✓') ? 'alert-success' : 'alert-error'}`} style={{ marginBottom:16 }}>{msg}</div>}

      {/* 分析工具区 */}
      <div className="grid-2 section-gap">
        {/* 异常检测 */}
        <div className="card">
          <div className="card-header">
            <span className="card-title">⚠ 异常检测</span>
            <button className="btn btn-ghost" style={{ padding:'3px 10px', fontSize:11 }}
              onClick={loadAnomalies} disabled={anomLoading}>
              {anomLoading ? <span className="spinner" style={{ width:11, height:11 }}></span> : '开始检测'}
            </button>
          </div>
          {anomalies === null ? (
            <div style={{ fontSize:13, color:'var(--text3)', padding:'8px 0' }}>
              点击「开始检测」分析新上线资产、高危端口暴露、资产离线等异常情况
            </div>
          ) : anomLoading ? (
            <div className="empty-state"><span className="spinner"></span></div>
          ) : anomalies.length === 0 ? (
            <div className="empty-state"><div className="empty-icon">✓</div><div style={{ color:'var(--green)' }}>未发现异常</div></div>
          ) : (
            <div style={{ maxHeight:260, overflowY:'auto' }}>
              {anomalies.slice(0, 25).map((a, i) => (
                <div key={i} style={{ padding:'7px 0', borderBottom:'1px solid var(--border)', display:'flex', justifyContent:'space-between', alignItems:'flex-start', gap:8 }}>
                  <div style={{ flex:1, minWidth:0 }}>
                    <div style={{ display:'flex', alignItems:'center', gap:6, marginBottom:3 }}>
                      {levelBadge(a.level)}
                      <span style={{ fontSize:13, color:'var(--text)' }}>{a.title}</span>
                    </div>
                    <div style={{ fontSize:11, color:'var(--text3)' }}>{a.detail}</div>
                  </div>
                  <span style={{ fontSize:10, color:'var(--text3)', flexShrink:0 }}>{a.time}</span>
                </div>
              ))}
              {anomalies.length > 25 && (
                <div style={{ fontSize:11, color:'var(--text3)', textAlign:'center', padding:'8px 0' }}>
                  ...共 {anomalies.length} 条，仅显示前25条
                </div>
              )}
            </div>
          )}
        </div>

        {/* 资产变化对比 */}
        <div className="card">
          <div className="card-header">
            <span className="card-title">📊 资产变化对比</span>
          </div>
          <div style={{ display:'flex', gap:8, marginBottom:12, alignItems:'center' }}>
            <select className="form-select" style={{ width:130 }} value={compDays}
              onChange={e => setCompDays(Number(e.target.value))}>
              <option value={1}>最近 1 天</option>
              <option value={3}>最近 3 天</option>
              <option value={7}>最近 7 天</option>
              <option value={30}>最近 30 天</option>
            </select>
            <button className="btn btn-ghost" style={{ padding:'5px 14px', fontSize:12 }}
              onClick={loadComparison} disabled={compLoading}>
              {compLoading ? <span className="spinner" style={{ width:11, height:11 }}></span> : '分析'}
            </button>
          </div>

          {comparison === null ? (
            <div style={{ fontSize:13, color:'var(--text3)' }}>选择时间范围后点击「分析」查看资产变化</div>
          ) : (
            <div>
              {/* 数字摘要 */}
              <div style={{ display:'grid', gridTemplateColumns:'repeat(3,1fr)', gap:8, marginBottom:14 }}>
                {[
                  { l:'在线资产', v: comparison.total_online,  c:'var(--cyan)'   },
                  { l:'新增资产', v: comparison.total_new,     c:'var(--green)'  },
                  { l:'离线资产', v: comparison.total_offline, c:'var(--orange)' },
                ].map(s => (
                  <div key={s.l} style={{ textAlign:'center', padding:'10px 6px', background:'var(--card2)', borderRadius:6 }}>
                    <div style={{ fontSize:22, fontFamily:'Rajdhani', fontWeight:700, color:s.c }}>{s.v}</div>
                    <div style={{ fontSize:11, color:'var(--text3)', marginTop:2 }}>{s.l}</div>
                  </div>
                ))}
              </div>

              {comparison.new_assets.length > 0 && (
                <div style={{ marginBottom:10 }}>
                  <div style={{ fontSize:12, color:'var(--green)', fontWeight:600, marginBottom:5 }}>▲ 新增资产（{comparison.total_new}）</div>
                  {comparison.new_assets.slice(0, 5).map((a, i) => (
                    <div key={i} style={{ fontSize:12, display:'flex', justifyContent:'space-between', padding:'3px 0', borderBottom:'1px solid var(--border)' }}>
                      <span className="mono text-cyan">{a.ip}</span>
                      <span style={{ color:'var(--text3)', fontSize:11 }}>{a.ports}</span>
                    </div>
                  ))}
                  {comparison.new_assets.length > 5 && <div style={{ fontSize:11, color:'var(--text3)', marginTop:4 }}>...还有 {comparison.new_assets.length - 5} 个</div>}
                </div>
              )}

              {comparison.went_offline.length > 0 && (
                <div>
                  <div style={{ fontSize:12, color:'var(--orange)', fontWeight:600, marginBottom:5 }}>▼ 离线资产（{comparison.total_offline}）</div>
                  {comparison.went_offline.slice(0, 5).map((a, i) => (
                    <div key={i} style={{ fontSize:12, display:'flex', justifyContent:'space-between', padding:'3px 0', borderBottom:'1px solid var(--border)' }}>
                      <span className="mono" style={{ color:'var(--orange)' }}>{a.ip}</span>
                      <span style={{ color:'var(--text3)', fontSize:11 }}>最后: {a.last_seen}</span>
                    </div>
                  ))}
                </div>
              )}

              {comparison.new_assets.length === 0 && comparison.went_offline.length === 0 && (
                <div style={{ fontSize:13, color:'var(--green)', textAlign:'center', padding:'8px' }}>此周期内无资产变化</div>
              )}
            </div>
          )}
        </div>
      </div>

      {/* 报告列表 */}
      <div className="card">
        <div className="card-header">
          <span className="card-title">报告列表</span>
          <div style={{ display:'flex', gap:8, alignItems:'center' }}>
            {someSelected && (
              <button className="btn btn-ghost"
                style={{ padding:'3px 10px', fontSize:12, color:'var(--red)', borderColor:'rgba(239,68,68,.3)' }}
                disabled={batchDel} onClick={deleteBatch}>
                {batchDel
                  ? <><span className="spinner" style={{ width:10, height:10 }}></span> 删除中...</>
                  : `🗑 删除所选 (${selected.length})`
                }
              </button>
            )}
          </div>
        </div>

        {!initDone ? (
          <div className="empty-state"><span className="spinner"></span></div>
        ) : reports.length === 0 ? (
          <div className="empty-state">
            <div className="empty-icon">▤</div>
            <div>暂无报告，点击「生成日报」或「生成周报」创建第一份</div>
          </div>
        ) : (
          <div className="table-wrap">
            <table>
              <thead>
                <tr>
                  <th style={{ width:36 }}>
                    <input type="checkbox" checked={allSelected}
                      onChange={() => setSelected(allSelected ? [] : reports.map(r => r.id))}/>
                  </th>
                  <th>报告标题</th><th>类型</th><th>生成人</th><th>生成时间</th><th>操作</th>
                </tr>
              </thead>
              <tbody>
                {reports.map(r => (
                  <tr key={r.id} style={{ background: selected.includes(r.id) ? 'rgba(0,229,255,.04)' : '' }}>
                    <td><input type="checkbox" checked={selected.includes(r.id)} onChange={() => toggleOne(r.id)}/></td>
                    <td style={{ fontWeight:500 }}>{r.title}</td>
                    <td><span className="badge badge-cyan">{typeLabel[r.type] || r.type}</span></td>
                    <td className="text-dimmer">{r.created_by || '系统'}</td>
                    <td className="text-dimmer">{r.created_at}</td>
                    <td>
                      <div style={{ display:'flex', gap:6 }}>
                        <button className="btn btn-ghost" style={{ padding:'3px 8px', fontSize:11 }}
                          onClick={() => viewReport(r.id)}>预览</button>
                        <button className="btn btn-ghost"
                          style={{ padding:'3px 8px', fontSize:11, color:'var(--red)' }}
                          disabled={deleting === r.id}
                          onClick={() => deleteOne(r.id, r.title)}>
                          {deleting === r.id
                            ? <span className="spinner" style={{ width:10, height:10 }}></span>
                            : '删除'}
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
