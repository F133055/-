// App.js
const NAV = [
  { id:'dashboard',     label:'仪表盘',    icon:'◈', section:'概览' },
  { id:'assets',        label:'资产管理',  icon:'⬡', section:'核心功能' },
  { id:'vulns',         label:'漏洞管理',  icon:'⚠' },
  { id:'scans',         label:'弱口令检测',icon:'◎' },
  { id:'quickscan',     label:'综合扫描',  icon:'⊙' },
  { id:'history',       label:'历史任务',  icon:'▷' },
  { id:'scheduler',     label:'定时任务',  icon:'⏰' },
  { id:'fofa',          label:'FOFA 探测', icon:'◉', section:'情报收集' },
  { id:'threat-intel',  label:'威胁情报',  icon:'🛡' },
  { id:'github-scan',   label:'信息收集',  icon:'🔍' },
  { id:'reports',       label:'安全报告',  icon:'▤', section:'分析输出' },
  { id:'anomaly',       label:'异常检测',  icon:'🚨' },
  { id:'knowledge',     label:'知识库',    icon:'📚' },
  { id:'ai-security',   label:'AI安全检测', icon:'🤖' },
  { id:'agent',          label:'AI 分析师',   icon:'💬' },
  { id:'devices',       label:'设备监控',  icon:'🖥' },
  { id:'policy',        label:'策略审核',  icon:'🔏' },
  { id:'notify',        label:'消息通知',  icon:'◆', section:'系统' },
  { id:'settings',      label:'系统设置',  icon:'⚙' },
  { id:'logs',          label:'系统日志',  icon:'📋' },
];

const PAGE_TITLES = {
  dashboard:'仪表盘',      assets:'资产管理',      vulns:'漏洞管理',
  scans:'弱口令检测',      quickscan:'综合扫描',   history:'历史任务',
  scheduler:'定时任务',    fofa:'FOFA 探测',        'threat-intel':'威胁情报',
  'github-scan':'信息收集', anomaly:'异常检测',     reports:'安全报告',
  knowledge:'安全知识库',  'ai-security':'AI安全检测', agent:'AI 智能分析师',
  devices:'设备监控',      policy:'策略审核',       notify:'消息通知',
  settings:'系统设置',     logs:'系统日志',
};

// ── 时钟：独立组件，只让自己每秒更新，不影响父级 ─────────────
function Clock() {
  const [time, setTime] = React.useState(
    new Date().toLocaleTimeString('zh-CN', {hour12:false})
  );
  React.useEffect(() => {
    const t = setInterval(
      () => setTime(new Date().toLocaleTimeString('zh-CN', {hour12:false})),
      1000
    );
    return () => clearInterval(t);
  }, []);
  return <span style={{fontSize:11,color:'var(--text3)',fontFamily:'JetBrains Mono'}}>{time}</span>;
}

// ── QS进度徽章：独立组件，只在综合扫描时更新，不影响App ───────
function QSProgressBadge({ onNavigate, currentPage }) {
  const [qsState, setQsState] = React.useState(() => ({...window.QS.state}));
  React.useEffect(() => {
    const h = e => setQsState({...e.detail});
    window.addEventListener('qs-update', h);
    return () => window.removeEventListener('qs-update', h);
  }, []);
  if (!qsState.running || currentPage === 'quickscan') return null;
  const total = Object.keys(qsState.taskMap).length;
  const done  = Object.values(qsState.taskMap)
    .filter(t => t.status==='SUCCESS'||t.status==='FAILURE'||t.status==='ERROR').length;
  return (
    <span onClick={() => onNavigate('quickscan')}
      style={{fontSize:12,color:'var(--cyan)',cursor:'pointer',
        background:'rgba(0,229,255,.08)',border:'1px solid rgba(0,229,255,.2)',
        padding:'3px 10px',borderRadius:6,display:'flex',alignItems:'center',gap:5}}>
      <span className="spinner" style={{width:10,height:10}}></span>
      综合扫描 {done}/{total}
    </span>
  );
}

// ── 侧边栏QS数字徽章：独立组件 ───────────────────────────────
function NavQSBadge() {
  const [qsState, setQsState] = React.useState(() => ({...window.QS.state}));
  React.useEffect(() => {
    const h = e => setQsState({...e.detail});
    window.addEventListener('qs-update', h);
    return () => window.removeEventListener('qs-update', h);
  }, []);
  if (!qsState.running) return null;
  const total = Object.keys(qsState.taskMap).length;
  const done  = Object.values(qsState.taskMap)
    .filter(t => t.status==='SUCCESS'||t.status==='FAILURE'||t.status==='ERROR').length;
  return (
    <span className="nav-badge"
      style={{background:'var(--cyan)',color:'#000',fontFamily:'monospace'}}>
      {done}/{total}
    </span>
  );
}

// ── 页面容器：所有页面同时挂载，用 display:none 切换 ──────────
const PageContainer = React.memo(function PageContainer({ currentPage, onNavigate }) {
  return (
    <div>
      <div style={{display: currentPage==='dashboard'    ? 'block' : 'none'}}><DashboardPage onNavigate={onNavigate}/></div>
      <div style={{display: currentPage==='assets'       ? 'block' : 'none'}}><AssetsPage/></div>
      <div style={{display: currentPage==='vulns'        ? 'block' : 'none'}}><VulnsPage/></div>
      <div style={{display: currentPage==='scans'        ? 'block' : 'none'}}><ScansPage/></div>
      <div style={{display: currentPage==='quickscan'    ? 'block' : 'none'}}><QuickScanPage/></div>
      <div style={{display: currentPage==='history'      ? 'block' : 'none'}}><TaskHistoryPage/></div>
      <div style={{display: currentPage==='scheduler'    ? 'block' : 'none'}}><SchedulerPage/></div>
      <div style={{display: currentPage==='fofa'         ? 'block' : 'none'}}><FOFAPage/></div>
      <div style={{display: currentPage==='threat-intel' ? 'block' : 'none'}}><ThreatIntelPage/></div>
      <div style={{display: currentPage==='github-scan'  ? 'block' : 'none'}}><GithubScanPage/></div>
      <div style={{display: currentPage==='reports'      ? 'block' : 'none'}}><ReportsPage/></div>
      <div style={{display: currentPage==='anomaly'      ? 'block' : 'none'}}><AnomalyDetectPage/></div>
      <div style={{display: currentPage==='knowledge'    ? 'block' : 'none'}}><KnowledgeBasePage/></div>
      <div style={{display: currentPage==='ai-security'  ? 'block' : 'none'}}><AISecurityPage/></div>
      <div style={{display: currentPage==='agent'          ? 'block' : 'none'}}><AgentPage/></div>
      <div style={{display: currentPage==='devices'      ? 'block' : 'none'}}><DeviceMonitorPage/></div>
      <div style={{display: currentPage==='policy'       ? 'block' : 'none'}}><PolicyAuditPage/></div>
      <div style={{display: currentPage==='notify'       ? 'block' : 'none'}}><NotifyPage/></div>
      <div style={{display: currentPage==='settings'     ? 'block' : 'none'}}><SettingsPage/></div>
      <div style={{display: currentPage==='logs'         ? 'block' : 'none'}}><LogsPage/></div>
    </div>
  );
});

// ── 主 App：只管路由和登录状态，不监听 qs-update ────────────
function App() {
  // Allow internal navigation events (e.g. from Agent page)
  const savedUser = localStorage.getItem('sec_last_user') || '';
  const hasToken  = !!api.token;

  const [authed,   setAuthed]    = useState(false);
  const [username, setUsername]  = useState(savedUser);
  const [page,     setPage]      = useState('dashboard');
  const [theme,    setThemeLocal]= useState(localStorage.getItem('sec_theme') || 'dark');
  const [showNew,  setShowNew]   = useState(() => !localStorage.getItem('sec_quickscan_seen'));

  useEffect(() => { applyTheme(theme); }, []);

  useEffect(() => {
    const h = e => setThemeLocal(e.detail);
    window.addEventListener('themechange', h);
    return () => window.removeEventListener('themechange', h);
  }, []);

  useEffect(() => {
    const h = () => { window.QS.stopPolling(); setAuthed(false); setUsername(''); };
    window.addEventListener('auth-expired', h);
    return () => window.removeEventListener('auth-expired', h);
  }, []);

  const handleLogin = useCallback((u) => { setUsername(u); setAuthed(true); }, []);

  const handleLogout = useCallback(() => {
    api.clearToken();
    window.QS.stopPolling();
    setAuthed(false);
    setUsername('');
  }, []);

  const handleNav = useCallback((id) => {
    setPage(id);
    if (id === 'quickscan' && showNew) {
      localStorage.setItem('sec_quickscan_seen', '1');
      setShowNew(false);
    }
  }, [showNew]);

  if (!authed) {
    return <LoginPage onLogin={handleLogin} autoLoginUser={hasToken && savedUser ? savedUser : null}/>;
  }

  const cycleTheme = () => {
    const ids  = THEMES.map(t => t.id);
    const next = ids[(ids.indexOf(theme) + 1) % ids.length];
    setThemeLocal(next); applyTheme(next);
    window.dispatchEvent(new CustomEvent('themechange', { detail: next }));
  };
  const curTheme = THEMES.find(t => t.id === theme) || THEMES[0];

  let lastSection = '';

  return (
    <div>
      <div className="sidebar">
        <div className="sidebar-logo">
          <div className="logo-text">SecPlatform</div>
          <div className="logo-sub">安全专项扫描与智能分析</div>
        </div>
        <nav className="sidebar-nav">
          {NAV.map(item => {
            const showSection = item.section && item.section !== lastSection;
            if (item.section) lastSection = item.section;
            return (
              <div key={item.id}>
                {showSection && <div className="nav-section">{item.section}</div>}
                <div className={`nav-item${page===item.id?' active':''}`}
                  onClick={() => handleNav(item.id)}>
                  <span className="icon">{item.icon}</span>
                  <span>{item.label}</span>
                  {item.id==='quickscan' && showNew && page!=='quickscan' && (
                    <span className="nav-badge">NEW</span>
                  )}
                  {item.id==='quickscan' && <NavQSBadge/>}
                </div>
              </div>
            );
          })}
        </nav>
        <div className="sidebar-footer">
          <div className="user-info">
            <div className="user-avatar">{username[0]?.toUpperCase()||'A'}</div>
            <div style={{flex:1,minWidth:0}}>
              <div className="user-name">{username}</div>
              <div className="user-role">管理员</div>
            </div>
            <button onClick={handleLogout} title="退出登录"
              style={{background:'none',border:'none',cursor:'pointer',color:'var(--text3)',fontSize:14,padding:'2px 4px'}}>⏎</button>
          </div>
        </div>
      </div>

      <div className="main">
        <div className="topbar">
          <span className="page-title">{PAGE_TITLES[page]}</span>
          <div className="topbar-right">
            <QSProgressBadge onNavigate={handleNav} currentPage={page}/>
            <button onClick={cycleTheme} title="切换主题"
              style={{background:'var(--card)',border:'1px solid var(--border)',borderRadius:6,
                padding:'3px 10px',cursor:'pointer',color:'var(--text2)',fontSize:12,
                display:'flex',alignItems:'center',gap:5,lineHeight:1.8}}>
              {curTheme.icon} {curTheme.label}
            </button>
            <div className="status-dot"></div>
            <Clock/>
          </div>
        </div>
        <div className="content">
          <PageContainer currentPage={page} onNavigate={handleNav}/>
        </div>
      </div>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<App/>);
