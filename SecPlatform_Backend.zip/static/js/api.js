// api.js - API客户端 + 全局常量 + window.QS 综合扫描状态管理器
const { useState, useEffect, useCallback, useRef } = React;

// ── API 客户端 ────────────────────────────────────────────────
const api = {
  token: localStorage.getItem('sec_token') || '',
  setToken(t)   { this.token = t; localStorage.setItem('sec_token', t); },
  clearToken()  { this.token = ''; localStorage.removeItem('sec_token'); },

  async req(method, path, body = null, isForm = false) {
    const headers = { 'Authorization': `Bearer ${this.token}` };
    if (!isForm) headers['Content-Type'] = 'application/json';
    const opts = { method, headers };
    if (body) opts.body = isForm ? body : JSON.stringify(body);
    try {
      const r = await fetch(path, opts);
      if (r.status === 401) { this.clearToken(); window.dispatchEvent(new CustomEvent("auth-expired")); return null; }
      const ct = r.headers.get('content-type') || '';
      if (ct.includes('application/json')) return await r.json();
      return await r.text();
    } catch (e) { console.error('API Error:', e); return null; }
  },

  get:    (path)             => api.req('GET',    path),
  post:   (path, body, isForm) => api.req('POST', path, body, isForm),
  patch:  (path, body)       => api.req('PATCH',  path, body),
  delete: (path)             => api.req('DELETE', path),

  async login(username, password) {
    const fd = new FormData();
    fd.append('username', username);
    fd.append('password', password);
    const r = await fetch('/api/auth/login', { method: 'POST', body: fd });
    return await r.json();
  },
};

// ── 全局图标 / 主题常量 ────────────────────────────────────────
const icons = {
  dashboard:'◈', assets:'⬡', vuln:'⚠', scan:'◎', fofa:'◉',
  report:'▤', notify:'◆', settings:'⚙', logout:'⏎',
  quickscan:'⊙', refresh:'↻', plus:'+', trash:'✕',
};

const THEMES = [
  { id:'dark',  label:'深夜模式', icon:'🌙', desc:'经典深色赛博风格' },
  { id:'light', label:'白天模式', icon:'☀️',  desc:'清爽亮色，日间使用' },
  { id:'green', label:'护眼模式', icon:'🌿', desc:'深绿色调，减少疲劳' },
];

function applyTheme(t) {
  document.documentElement.setAttribute('data-theme', t);
  localStorage.setItem('sec_theme', t);
}

// ── window.QS：综合扫描全局状态管理器 ────────────────────────
// 完全独立于 React，切换页面、组件销毁均不影响轮询和状态
// 组件通过监听 'qs-update' CustomEvent 获取最新状态
window.QS = {
  state: {
    taskMap:        {},    // { checkId: { status, task_ids[], results[], done_count, error } }
    running:        false,
    targets:        '',
    selectedChecks: null,  // null = 使用默认值
  },
  _interval: null,

  // 广播状态更新事件，所有监听的组件会自动重渲染
  _emit() {
    window.dispatchEvent(new CustomEvent('qs-update', { detail: this.state }));
  },

  // 提取任务ID（兼容 task_id 和 task_ids 两种返回格式）
  _extractIds(r) {
    if (!r) return [];
    if (r.task_ids && r.task_ids.length) return r.task_ids;
    if (r.task_id) return [r.task_id];
    return [];
  },

  // 重置状态，开始新扫描
  reset(selectedChecks) {
    const map = {};
    selectedChecks.forEach(id => {
      map[id] = { status: 'PENDING', task_ids: [], results: [], done_count: 0, error: null };
    });
    this.state.taskMap = map;
    this.state.running = true;
    this._emit();
  },

  // 更新某个检测项的派发结果
  setDispatched(checkId, r) {
    const ids = this._extractIds(r);
    this.state.taskMap[checkId] = {
      status:    ids.length ? 'PENDING' : 'ERROR',
      task_ids:  ids,
      results:   [],
      done_count: 0,
      error:     ids.length ? null : (r?.detail || r?.message || '下发失败'),
    };
    this._emit();
  },

  // 标记某个检测项派发失败
  setError(checkId, msg) {
    this.state.taskMap[checkId] = {
      status: 'ERROR', task_ids: [], results: [], done_count: 0, error: msg,
    };
    this._emit();
  },

  // 启动轮询（幂等，已在跑则先清除再重启）
  startPolling() {
    if (this._interval) clearInterval(this._interval);
    this._interval = setInterval(() => this._poll(), 3000);
  },

  // 停止轮询（清空结果时调用）
  stopPolling() {
    if (this._interval) { clearInterval(this._interval); this._interval = null; }
    this.state.running = false;
    this.state.taskMap = {};
    this._emit();
  },

  // 核心轮询逻辑 —— 完全独立于任何 React 组件
  async _poll() {
    const map = this.state.taskMap;
    let anyPending = false;

    for (const [checkId, info] of Object.entries(map)) {
      // 已终态，跳过
      if (info.status === 'SUCCESS' || info.status === 'FAILURE' || info.status === 'ERROR') continue;
      if (!info.task_ids || !info.task_ids.length) continue;
      anyPending = true;

      const total = info.task_ids.length;
      const results = [];
      let doneCnt = 0;
      let failCnt = 0;

      // 轮询该检测项下所有子任务
      for (const tid of info.task_ids) {
        try {
          const r = await api.get(`/api/scan/task/${tid}`);
          if (!r) continue;
          if (r.status === 'SUCCESS') {
            doneCnt++;
            if (r.result && Object.keys(r.result).length) results.push(r.result);
          } else if (r.status === 'FAILURE' || r.status === 'FAILED') {
            doneCnt++;
            failCnt++;
          }
          // PENDING/STARTED: 不计入 done
        } catch (e) { /* 网络失败，下次重试 */ }
      }

      if (doneCnt === total) {
        // 全部完成
        map[checkId] = {
          ...info,
          status:    failCnt === total ? 'FAILURE' : 'SUCCESS',
          results,
          done_count: doneCnt,
        };
      } else if (doneCnt > 0) {
        // 部分完成
        map[checkId] = { ...info, status: 'RUNNING', done_count: doneCnt, results };
      } else {
        // 还没有完成的
        map[checkId] = { ...info, status: info.status === 'PENDING' ? 'RUNNING' : info.status };
      }
    }

    if (!anyPending) {
      // 所有任务均终态，停止轮询
      clearInterval(this._interval);
      this._interval = null;
      this.state.running = false;
    }

    this._emit();
  },
};

// ── QSBanner：综合扫描进度横幅，独立组件不影响父级重渲染 ────
// 在 Assets/Vulns/Scans 等页面顶部使用
function QSBanner() {
  const [qs, setQs] = React.useState(() => ({...window.QS.state}));
  React.useEffect(() => {
    const h = e => setQs({...e.detail});
    window.addEventListener('qs-update', h);
    return () => window.removeEventListener('qs-update', h);
  }, []);
  if (!qs.running) return null;
  const total = Object.keys(qs.taskMap).length;
  const done  = Object.values(qs.taskMap).filter(t => ['SUCCESS','FAILURE','ERROR'].includes(t.status)).length;
  return (
    <div style={{marginBottom:14,padding:'9px 14px',borderRadius:8,
      background:'rgba(0,229,255,0.05)',border:'1px solid rgba(0,229,255,.2)',
      display:'flex',alignItems:'center',gap:10,fontSize:13}}>
      <span className="spinner" style={{width:12,height:12,flexShrink:0}}></span>
      <span style={{color:'var(--cyan)'}}>综合扫描进行中 ({done}/{total})，完成后点刷新查看最新数据。</span>
    </div>
  );
}

// ══════════════════════════════════════════════════════════════════
// Modal Portal — renders to document.body to escape overflow/transform
// constraints. Use: <Modal show={bool} onClose={fn} title="...">body</Modal>
// ══════════════════════════════════════════════════════════════════
function Modal({ show, onClose, title, width = 560, children }) {
  if (!show) return null;
  const overlayStyle = {
    position: 'fixed', inset: 0, zIndex: 9999,
    background: 'rgba(0,0,0,0.7)',
    backdropFilter: 'blur(6px)',
    WebkitBackdropFilter: 'blur(6px)',
    display: 'flex', alignItems: 'center', justifyContent: 'center',
    padding: 20,
  };
  const dialogStyle = {
    width: width, maxWidth: '95vw', maxHeight: '90vh', overflowY: 'auto',
    background: 'var(--card)', border: '1px solid var(--border2)',
    borderRadius: 12, padding: 24,
    boxShadow: '0 32px 80px rgba(0,0,0,0.65)',
    animation: 'modal-in .18s cubic-bezier(.2,.8,.2,1)',
    position: 'relative',
  };
  return ReactDOM.createPortal(
    <div style={overlayStyle} onClick={onClose}>
      <div style={dialogStyle} onClick={e => e.stopPropagation()}>
        <div className="modal-header">
          <span className="modal-title">{title}</span>
          <button className="modal-close" onClick={onClose}>✕</button>
        </div>
        {children}
      </div>
    </div>,
    document.body
  );
}
