"""通知推送路由"""
import logging
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from pydantic import BaseModel
from typing import Optional

from db import models, crud
from routers.auth import verify_token, User

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api/notify", tags=["5. 通知"])


class NotifyConfigRequest(BaseModel):
    channel: str
    name: str
    webhook_url: Optional[str] = None
    api_key: Optional[str] = None
    enabled: bool = True


class TestNotifyRequest(BaseModel):
    channel: str
    webhook_url: Optional[str] = None
    api_key: Optional[str] = None


@router.get("/configs", summary="获取通知配置")
async def get_configs(db: Session = Depends(models.get_db), user: User = Depends(verify_token)):
    configs = crud.get_notify_configs(db)
    return {
        "code": 200,
        "data": [
            {
                "id": c.id,
                "channel": c.channel,
                "name": c.name,
                "webhook_url": c.webhook_url,
                "enabled": c.enabled,
            }
            for c in configs
        ]
    }


@router.post("/configs", summary="保存通知配置")
async def save_config(
    req: NotifyConfigRequest,
    db: Session = Depends(models.get_db),
    user: User = Depends(verify_token)
):
    try:
        config = crud.save_notify_config(db, req.channel, req.name, req.webhook_url, req.api_key)
        return {"code": 200, "message": "配置保存成功", "id": config.id}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/test", summary="测试通知")
async def test_notify(req: TestNotifyRequest, user: User = Depends(verify_token)):
    from core.notifier import send_notification
    success = send_notification(
        req.channel,
        req.webhook_url,
        req.api_key,
        title="🧪 SecPlatform 测试通知",
        content=f"通知渠道 **{req.channel}** 连接测试成功！\n来自：{user.username}"
    )
    if success:
        return {"code": 200, "message": "测试通知发送成功"}
    else:
        raise HTTPException(status_code=400, detail="通知发送失败，请检查配置")
