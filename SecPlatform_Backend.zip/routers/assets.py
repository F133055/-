"""
资产管理路由模块 - routers/assets.py
==================================

负责处理资产相关的 CRUD 操作
- 查询资产列表
- 获取资产详情
- 删除资产
- 批量删除
- 资产统计
"""

import logging
from typing import List, Optional

from fastapi import APIRouter, HTTPException, Depends, status
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session
from sqlalchemy import func

from db import models, crud
from db.models import Asset
from routers.auth import verify_token, verify_admin, User

logger = logging.getLogger(__name__)

# 路由器定义
router = APIRouter(
    prefix="/api/assets",
    tags=["2. 资产"]
)

# 数据模型
class AssetInfo(BaseModel):
    """资产信息响应模型"""
    id: int = Field(..., title="资产 ID")
    ip_address: str = Field(..., title="IP 地址")
    open_ports: str = Field(default="", title="开放端口")
    status: str = Field(default="ONLINE", title="资产状态")
    vuln_info: str = Field(default="未检测", title="漏洞信息")
    
    class Config:
        from_attributes = True


class AssetStats(BaseModel):
    """资产统计信息"""
    total_assets: int = Field(..., title="资产总数")
    online_assets: int = Field(..., title="在线资产")
    offline_assets: int = Field(..., title="离线资产")
    vulnerable_assets: int = Field(..., title="有漏洞的资产")
    weak_password_assets: int = Field(..., title="弱密码资产")


class BatchDeleteRequest(BaseModel):
    """批量删除请求"""
    ids: List[int] = Field(..., min_items=1, title="要删除的资产 ID 列表")


class AssetUpdateRequest(BaseModel):
    """资产更新请求"""
    status: Optional[str] = Field(None, title="资产状态")
    vuln_info: Optional[str] = Field(None, title="漏洞信息")


# 路由端点

@router.get(
    "/",
    summary="📊 获取资产列表",
    description="获取所有已发现的资产及其详细信息",
    response_model=dict
)
async def get_assets(
    db: Session = Depends(models.get_db),
    user: User = Depends(verify_token),
    skip: int = 0,
    limit: int = 100,
    status_filter: Optional[str] = None
):

    try:
        # 限制 limit 的最大值
        limit = min(limit, 1000)
        
        # 构建查询
        query = db.query(Asset)
        
        # 应用状态过滤
        if status_filter:
            if status_filter not in ["ONLINE", "OFFLINE"]:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail="无效的状态过滤值，必须是 ONLINE 或 OFFLINE"
                )
            query = query.filter(Asset.status == status_filter)
        
        # 获取总数
        total = query.count()
        
        # 执行分页查询
        assets = query.offset(skip).limit(limit).all()
        
        logger.info(f"👤 用户 {user.username} 查询资产列表: 总计 {total} 个，本次返回 {len(assets)} 个")
        
        return {
            "code": 200,
            "total": total,
            "skip": skip,
            "limit": limit,
            "status_filter": status_filter,
            "data": [
                {
                    "id": asset.id,
                    "ip_address": asset.ip_address,
                    "open_ports": asset.open_ports or "",
                    "status": asset.status,
                    "vuln_info": asset.vuln_info or "未检测",
                    "risk_level": asset.risk_level or "未知",
                    "first_seen": asset.first_seen.strftime("%Y-%m-%d %H:%M") if asset.first_seen else "—",
                    "last_seen": asset.last_seen.strftime("%Y-%m-%d %H:%M") if asset.last_seen else "—",
                    "hostname": asset.hostname or "",
                    "source": asset.source or "scan",
                }
                for asset in assets
            ]
        }
    
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"❌ 查询资产列表失败: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"查询失败: {str(e)}"
        )


@router.get(
    "/{asset_id}",
    summary="🔍 获取资产详情",
    description="获取指定资产的详细信息"
)
async def get_asset_detail(
    asset_id: int,
    db: Session = Depends(models.get_db),
    user: User = Depends(verify_token)
):

    try:
        asset = db.query(Asset).filter(Asset.id == asset_id).first()
        
        if not asset:
            logger.warning(f"⚠️  资产不存在: ID {asset_id}")
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"资产 ID {asset_id} 不存在"
            )
        
        logger.info(f"👤 用户 {user.username} 查询资产详情: {asset.ip_address}")
        
        return {
            "code": 200,
            "data": {
                "id": asset.id,
                "ip_address": asset.ip_address,
                "open_ports": asset.open_ports or "",
                "status": asset.status,
                "vuln_info": asset.vuln_info or "未检测",
                "risk_level": asset.risk_level or "未知",
                "first_seen": asset.first_seen.strftime("%Y-%m-%d %H:%M") if asset.first_seen else "—",
                "last_seen": asset.last_seen.strftime("%Y-%m-%d %H:%M") if asset.last_seen else "—",
                "hostname": asset.hostname or "",
                "source": asset.source or "scan",
            }
        }
    
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"❌ 查询资产详情失败: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"查询失败: {str(e)}"
        )


@router.delete(
    "/{asset_id}",
    summary="🗑️ 删除单个资产",
    description="删除指定的资产记录"
)
async def delete_asset(
    asset_id: int,
    db: Session = Depends(models.get_db),
    user: User = Depends(verify_admin)  # 需要 admin 权限
):

    try:
        asset = db.query(Asset).filter(Asset.id == asset_id).first()
        
        if not asset:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"资产 ID {asset_id} 不存在"
            )
        
        ip_address = asset.ip_address
        # 先删关联漏洞
        from db.models import Vulnerability
        db.query(Vulnerability).filter(Vulnerability.asset_id == asset_id).delete(synchronize_session=False)
        db.delete(asset)
        db.commit()
        
        logger.info(f"👤 用户 {user.username} 删除了资产: {ip_address} (ID {asset_id})")
        
        return {
            "code": 200,
            "message": "资产已删除",
            "deleted_id": asset_id,
            "deleted_ip": ip_address
        }
    
    except HTTPException:
        raise
    except Exception as e:
        db.rollback()
        logger.error(f"❌ 删除资产失败: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"删除失败: {str(e)}"
        )


@router.post(
    "/batch-delete",
    summary="🗑️ 批量删除资产",
    description="一次删除多个资产"
)
async def batch_delete_assets(
    request: BatchDeleteRequest,
    db: Session = Depends(models.get_db),
    user: User = Depends(verify_admin)  # ✨ 需要 admin 权限
):

    try:
        if not request.ids:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="ID 列表不能为空"
            )
        
        # 先删除关联漏洞（batch bulk-delete 不触发 ORM cascade）
        from db.models import Vulnerability
        db.query(Vulnerability).filter(Vulnerability.asset_id.in_(request.ids)).delete(
            synchronize_session=False
        )
        # 再删除资产
        deleted_count = db.query(Asset).filter(Asset.id.in_(request.ids)).delete(
            synchronize_session=False
        )
        db.commit()
        
        logger.info(f"👤 用户 {user.username} 批量删除了 {deleted_count} 个资产")
        
        return {
            "code": 200,
            "message": f"成功删除 {deleted_count} 个资产",
            "deleted_count": deleted_count,
            "requested_count": len(request.ids)
        }
    
    except HTTPException:
        raise
    except Exception as e:
        db.rollback()
        logger.error(f"❌ 批量删除资产失败: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"批量删除失败: {str(e)}"
        )


@router.patch(
    "/{asset_id}",
    summary="✏️ 更新资产信息",
    description="修改资产的状态或漏洞信息"
)
async def update_asset(
    asset_id: int,
    request: AssetUpdateRequest,
    db: Session = Depends(models.get_db),
    user: User = Depends(verify_admin)
):

    try:
        asset = db.query(Asset).filter(Asset.id == asset_id).first()
        
        if not asset:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"资产 ID {asset_id} 不存在"
            )
        
        # 更新字段
        if request.status is not None:
            asset.status = request.status
        if request.vuln_info is not None:
            asset.vuln_info = request.vuln_info
        
        db.commit()
        logger.info(f"👤 用户 {user.username} 更新了资产 {asset.ip_address}")
        
        return {
            "code": 200,
            "message": "资产已更新",
            "data": {
                "id": asset.id,
                "ip_address": asset.ip_address,
                "status": asset.status,
                "vuln_info": asset.vuln_info
            }
        }
    
    except HTTPException:
        raise
    except Exception as e:
        db.rollback()
        logger.error(f"❌ 更新资产失败: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"更新失败: {str(e)}"
        )


@router.get(
    "/stats/summary",
    summary="📈 资产统计",
    description="获取资产的统计信息"
)
async def get_asset_stats(
    db: Session = Depends(models.get_db),
    user: User = Depends(verify_token)
):

    try:
        from db.models import Vulnerability
        total = db.query(func.count(Asset.id)).scalar() or 0
        online = db.query(func.count(Asset.id)).filter(Asset.status == "ONLINE").scalar() or 0
        offline = db.query(func.count(Asset.id)).filter(Asset.status == "OFFLINE").scalar() or 0
        high_risk = db.query(func.count(Asset.id)).filter(Asset.risk_level == "高").scalar() or 0
        vuln_total = db.query(func.count(Vulnerability.id)).scalar() or 0
        vuln_high = db.query(func.count(Vulnerability.id)).filter(Vulnerability.severity == "高", Vulnerability.status.notin_(["误报","已修复"])).scalar() or 0
        
        logger.info(f"👤 用户 {user.username} 查询资产统计")
        
        return {
            "code": 200,
            "data": {
                "total_assets": total,
                "online_assets": online,
                "offline_assets": offline,
                "high_risk_assets": high_risk,
                "total_vulnerabilities": vuln_total,
                "high_vulnerabilities": vuln_high,
            }
        }
    
    except Exception as e:
        logger.error(f"❌ 获取资产统计失败: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"获取统计失败: {str(e)}"
        )


@router.get(
    "/analysis/high-risk-ports",
    summary="🚨 高危端口资产分析",
    description="列出所有存在高危端口的在线资产（独立分析接口）"
)
async def high_risk_port_analysis(
    db: Session = Depends(models.get_db),
    user: User = Depends(verify_token),
):
    """
    高危端口定义（独立于报告模块）：
    22/SSH  23/Telnet  3389/RDP  6379/Redis  27017/MongoDB
    9200/ES  2375/Docker  445/SMB  8848/Nacos  61616/ActiveMQ 等
    """
    from core.anomaly_detector import get_high_risk_port_assets
    try:
        assets = get_high_risk_port_assets(db)
        # 按高危端口数量 + IP 排序
        return {
            "code": 200,
            "total": len(assets),
            "data": assets,
        }
    except Exception as e:
        logger.error(f"高危端口分析失败: {e}")
        raise HTTPException(500, f"分析失败: {str(e)}")


@router.post(
    "/snapshot/save",
    summary="📸 手动保存资产快照",
    description="立即将当前所有 ONLINE 资产保存为一份快照（用于后续对比）"
)
async def save_snapshot(
    db: Session = Depends(models.get_db),
    user: User = Depends(verify_admin),
):
    try:
        count = crud.save_asset_snapshot(db)
        return {"code": 200, "message": f"快照已保存，共 {count} 条", "count": count}
    except Exception as e:
        logger.error(f"保存快照失败: {e}")
        raise HTTPException(500, f"保存失败: {str(e)}")


@router.get(
    "/snapshot/list",
    summary="📋 快照时间点列表",
    description="获取所有已保存的资产快照时间点"
)
async def list_snapshots(
    limit: int = 30,
    db: Session = Depends(models.get_db),
    user: User = Depends(verify_token),
):
    try:
        times = crud.get_snapshot_times(db, limit=limit)
        return {"code": 200, "data": times}
    except Exception as e:
        logger.error(f"获取快照列表失败: {e}")
        raise HTTPException(500, f"获取失败: {str(e)}")


@router.get(
    "/snapshot/compare",
    summary="🔍 快照对比",
    description="对比两个时间点的资产差异，返回新增/消失/变化资产"
)
async def compare_snapshots(
    time_a: str,
    time_b: str,
    db: Session = Depends(models.get_db),
    user: User = Depends(verify_token),
):
    try:
        result = crud.compare_snapshots(db, time_a=time_a, time_b=time_b)
        return {"code": 200, "data": result}
    except Exception as e:
        logger.error(f"快照对比失败: {e}")
        raise HTTPException(500, f"对比失败: {str(e)}")


@router.get(
    "/stats/trend",
    summary="📈 资产与漏洞趋势数据（近7天）",
)
async def asset_trend(
    db: Session = Depends(models.get_db),
    user: User  = Depends(verify_token),
):
    """
    返回近7天每天的资产、漏洞、高危漏洞、弱密码数量，用于趋势折线图。
    若无精确历史数据，则以当前值生成平滑模拟趋势。
    """
    from datetime import datetime, timedelta
    from sqlalchemy import func, cast, Date
    try:
        today = datetime.utcnow().date()
        days  = 7

        # ── 尝试从快照获取每天资产数 ──────────────────────────────
        asset_by_day = {}
        try:
            rows = (
                db.query(
                    cast(models.AssetSnapshot.snapshot_at, Date).label("day"),
                    func.count(models.AssetSnapshot.ip_address.distinct()).label("cnt"),
                )
                .filter(models.AssetSnapshot.snapshot_at >= today - timedelta(days=days))
                .group_by("day")
                .all()
            )
            asset_by_day = {str(r.day): r.cnt for r in rows}
        except Exception:
            pass

        # ── 漏洞按创建时间统计 ────────────────────────────────────
        vuln_by_day  = {}
        high_by_day  = {}
        try:
            from db.models import Vulnerability
            v_rows = (
                db.query(
                    cast(Vulnerability.discovered_at, Date).label("day"),
                    func.count().label("cnt"),
                )
                .filter(Vulnerability.discovered_at >= today - timedelta(days=days))
                .group_by("day")
                .all()
            )
            vuln_by_day = {str(r.day): r.cnt for r in v_rows}

            h_rows = (
                db.query(
                    cast(Vulnerability.discovered_at, Date).label("day"),
                    func.count().label("cnt"),
                )
                .filter(
                    Vulnerability.discovered_at >= today - timedelta(days=days),
                    Vulnerability.severity.in_(["严重", "高"]),
                )
                .group_by("day")
                .all()
            )
            high_by_day = {str(r.day): r.cnt for r in h_rows}
        except Exception:
            pass

        # ── 弱密码（scan_tasks 中 type=weakpass 且成功） ─────────
        weak_by_day = {}
        try:
            w_rows = (
                db.query(
                    cast(models.ScanTask.created_at, Date).label("day"),
                    func.count().label("cnt"),
                )
                .filter(
                    models.ScanTask.task_type == "weakpass",
                    models.ScanTask.status    == "SUCCESS",
                    models.ScanTask.created_at >= today - timedelta(days=days),
                )
                .group_by("day")
                .all()
            )
            weak_by_day = {str(r.day): r.cnt for r in w_rows}
        except Exception:
            pass

        # ── 构建7天序列（缺失用0或前一天值填充） ─────────────────
        def build_series(day_map: dict, base_val: int = 0) -> list:
            series = []
            prev = base_val
            for i in range(days - 1, -1, -1):
                d = str(today - timedelta(days=i))
                v = day_map.get(d, None)
                if v is None:
                    v = prev  # 用前一天值填充（资产类适用）
                prev = v
                series.append(v)
            return series

        # 当前总量作为基准
        total_assets = db.query(func.count()).select_from(models.Asset).scalar() or 0
        total_vulns  = db.query(func.count()).select_from(models.Vulnerability).scalar() or 0

        return {
            "code": 200,
            "data": {
                "assets":    build_series(asset_by_day, total_assets),
                "vulns":     build_series(vuln_by_day,  total_vulns),
                "high_vulns":build_series(high_by_day,  0),
                "weakpass":  build_series(weak_by_day,  0),
            }
        }
    except Exception as e:
        logger.error(f"趋势数据获取失败: {e}")
        raise HTTPException(500, f"趋势数据获取失败: {str(e)}")
