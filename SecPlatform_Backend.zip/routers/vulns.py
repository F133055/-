"""漏洞管理路由"""
import logging
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from pydantic import BaseModel
from typing import Optional

from db import models, crud
from routers.auth import verify_token, User

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api/vulns", tags=["7. 漏洞"])


class VulnStatusUpdate(BaseModel):
    status: str


class BatchDeleteVulnsReq(BaseModel):
    ids: list


class BatchStatusReq(BaseModel):
    ids: list
    status: str


@router.get("/", summary="漏洞列表")
async def list_vulns(
    severity: Optional[str] = None,
    status: Optional[str] = None,
    skip: int = 0,
    limit: int = 100,
    db: Session = Depends(models.get_db),
    user: User = Depends(verify_token)
):
    from db.models import Vulnerability
    from sqlalchemy import func, desc
    q = db.query(Vulnerability)
    if severity:
        q = q.filter(Vulnerability.severity == severity)
    if status:
        q = q.filter(Vulnerability.status == status)
    total = q.count()
    vulns = q.order_by(desc(Vulnerability.discovered_at)).offset(skip).limit(limit).all()
    return {
        "code": 200,
        "total": total,
        "data": [
            {
                "id": v.id,
                "ip_address": v.ip_address,
                "vuln_type": v.vuln_type,
                "title": v.title,
                "severity": v.severity,
                "description": v.description or "",
                "evidence": v.evidence or "",
                "status": v.status,
                "discovered_at": v.discovered_at.strftime("%Y-%m-%d %H:%M") if v.discovered_at else "",
            }
            for v in vulns
        ]
    }


@router.get("/stats", summary="漏洞统计")
async def vuln_stats(db: Session = Depends(models.get_db), user: User = Depends(verify_token)):
    from db.models import Vulnerability
    from sqlalchemy import func
    total    = db.query(func.count(Vulnerability.id)).scalar() or 0
    high     = db.query(func.count(Vulnerability.id)).filter(Vulnerability.severity == "高").scalar() or 0
    medium   = db.query(func.count(Vulnerability.id)).filter(Vulnerability.severity == "中").scalar() or 0
    low      = db.query(func.count(Vulnerability.id)).filter(Vulnerability.severity == "低").scalar() or 0
    unhandled= db.query(func.count(Vulnerability.id)).filter(Vulnerability.status == "未处理").scalar() or 0
    return {
        "code": 200,
        "data": {"total": total, "high": high, "medium": medium, "low": low, "unhandled": unhandled}
    }


# ──────────────────────────────────────────────
# 批量操作路由必须放在 /{vuln_id} 之前，否则 "batch" 会被当成 vuln_id
# ──────────────────────────────────────────────

@router.delete("/batch", summary="批量删除漏洞")
async def batch_delete_vulns(
    req: BatchDeleteVulnsReq,
    db: Session = Depends(models.get_db),
    user: User = Depends(verify_token)
):
    from db.models import Vulnerability
    if not req.ids:
        raise HTTPException(status_code=400, detail="ID 列表不能为空")
    try:
        deleted = db.query(Vulnerability).filter(Vulnerability.id.in_(req.ids)).delete(synchronize_session=False)
        db.commit()
    except Exception as e:
        db.rollback(); raise HTTPException(500, str(e))
    logger.info(f"👤 {user.username} 批量删除 {deleted} 条漏洞")
    return {"code": 200, "message": f"已删除 {deleted} 条漏洞", "deleted_count": deleted}


@router.patch("/batch/status", summary="批量更新漏洞状态")
async def batch_update_status(
    req: BatchStatusReq,
    db: Session = Depends(models.get_db),
    user: User = Depends(verify_token)
):
    from db.models import Vulnerability
    if not req.ids:
        raise HTTPException(status_code=400, detail="ID 列表不能为空")
    valid = ["未处理", "处理中", "已修复", "误报"]
    if req.status not in valid:
        raise HTTPException(status_code=400, detail=f"无效状态，允许: {valid}")
    updated = db.query(Vulnerability).filter(Vulnerability.id.in_(req.ids)).update(
        {"status": req.status}, synchronize_session=False
    )
    db.commit()
    return {"code": 200, "message": f"已更新 {updated} 条漏洞状态", "updated_count": updated}


# ──────────────────────────────────────────────
# 单条操作路由（必须在 batch 之后）
# ──────────────────────────────────────────────

@router.patch("/{vuln_id}/status", summary="更新漏洞状态")
async def update_status(
    vuln_id: int,
    req: VulnStatusUpdate,
    db: Session = Depends(models.get_db),
    user: User = Depends(verify_token)
):
    success = crud.update_vuln_status(db, vuln_id, req.status)
    if not success:
        raise HTTPException(status_code=404, detail="漏洞不存在")
    return {"code": 200, "message": "状态已更新"}


@router.delete("/{vuln_id}", summary="删除漏洞记录")
async def delete_vuln(
    vuln_id: int,
    db: Session = Depends(models.get_db),
    user: User = Depends(verify_token)
):
    from db.models import Vulnerability
    v = db.query(Vulnerability).filter(Vulnerability.id == vuln_id).first()
    if not v:
        raise HTTPException(status_code=404, detail="漏洞不存在")
    db.delete(v)
    db.commit()
    return {"code": 200, "message": "已删除"}
