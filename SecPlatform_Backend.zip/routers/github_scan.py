"""
GitHub/Gitee 信息泄露扫描路由 - routers/github_scan.py
=======================================================
接口列表：
  POST /api/github-scan/start          启动扫描任务
  GET  /api/github-scan/results        查询扫描结果列表
  GET  /api/github-scan/stats          统计信息
  PATCH /api/github-scan/{id}/status   更新处理状态
  DELETE /api/github-scan/{id}         删除记录
  GET  /api/github-scan/config-check   检查 Token 配置状态

.env 配置项：
  GITHUB_TOKEN=ghp_xxxxxxxxxxxx
  GITEE_TOKEN=xxxxxxxx（可选）
"""

import logging
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, BackgroundTasks
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session
from sqlalchemy import func, desc

from db import models, crud
from db.models import GithubLeakResult
from routers.auth import verify_token, User
from core.config import settings

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api/github-scan", tags=["9. 信息收集"])


# ── Pydantic Models ────────────────────────────────────────────

class ScanStartReq(BaseModel):
    keyword: str = Field(..., min_length=2, description="搜索关键字（如公司名、域名、项目名）")
    platform: str = Field(default="github", description="平台：github / gitee / all")
    max_results: int = Field(default=30, ge=5, le=100)

class StatusUpdateReq(BaseModel):
    status: str = Field(..., description="状态：未处理 / 已确认 / 忽略")


# ── 路由端点 ───────────────────────────────────────────────────

@router.get("/config-check", summary="检查 Token 配置状态")
async def config_check(user: User = Depends(verify_token)):
    github_token = getattr(settings, "GITHUB_TOKEN", None)
    gitee_token  = getattr(settings, "GITEE_TOKEN", None)
    return {
        "code": 200,
        "data": {
            "github_configured": bool(github_token),
            "gitee_configured": bool(gitee_token),
            "hint": "请在 .env 中配置 GITHUB_TOKEN=ghp_xxx 后重启服务" if not github_token else "已配置",
        }
    }


@router.post("/start", summary="启动信息泄露扫描任务")
async def start_scan(
    req: ScanStartReq,
    background_tasks: BackgroundTasks,
    db: Session = Depends(models.get_db),
    user: User = Depends(verify_token),
):
    github_token = getattr(settings, "GITHUB_TOKEN", None)
    gitee_token  = getattr(settings, "GITEE_TOKEN", None)

    if req.platform in ("github", "all") and not github_token:
        raise HTTPException(400, "GITHUB_TOKEN 未配置，请在 .env 中添加 GITHUB_TOKEN=ghp_xxxx 后重启服务")

    background_tasks.add_task(
        _do_scan, req.keyword, req.platform, req.max_results,
        github_token, gitee_token, db
    )
    return {
        "code": 200,
        "message": f"扫描任务已提交，关键字: {req.keyword}，平台: {req.platform}",
        "data": {"keyword": req.keyword, "platform": req.platform},
    }


@router.get("/results", summary="信息泄露结果列表")
async def list_results(
    keyword: Optional[str] = None,
    platform: Optional[str] = None,
    status: Optional[str] = None,
    skip: int = 0,
    limit: int = 100,
    db: Session = Depends(models.get_db),
    user: User = Depends(verify_token),
):
    items = crud.get_github_leaks(db, keyword=keyword, platform=platform,
                                   status=status, limit=limit + skip)
    items = items[skip:skip + limit]
    total = db.query(func.count(GithubLeakResult.id)).scalar() or 0
    return {
        "code": 200,
        "total": total,
        "data": [_fmt_result(r) for r in items],
    }


@router.get("/stats", summary="信息泄露统计")
async def get_stats(
    db: Session = Depends(models.get_db),
    user: User = Depends(verify_token),
):
    total     = db.query(func.count(GithubLeakResult.id)).scalar() or 0
    high      = db.query(func.count(GithubLeakResult.id)).filter(GithubLeakResult.severity == "高").scalar() or 0
    unhandled = db.query(func.count(GithubLeakResult.id)).filter(GithubLeakResult.status == "未处理").scalar() or 0
    keywords  = db.query(func.count(func.distinct(GithubLeakResult.keyword))).scalar() or 0
    return {
        "code": 200,
        "data": {
            "total": total, "high_severity": high,
            "unhandled": unhandled, "keywords_scanned": keywords,
        }
    }


@router.patch("/{item_id}/status", summary="更新处理状态")
async def update_status(
    item_id: int,
    req: StatusUpdateReq,
    db: Session = Depends(models.get_db),
    user: User = Depends(verify_token),
):
    item = db.query(GithubLeakResult).filter(GithubLeakResult.id == item_id).first()
    if not item:
        raise HTTPException(404, "记录不存在")
    item.status = req.status
    db.commit()
    return {"code": 200, "message": "已更新"}


@router.delete("/{item_id}", summary="删除记录")
async def delete_result(
    item_id: int,
    db: Session = Depends(models.get_db),
    user: User = Depends(verify_token),
):
    item = db.query(GithubLeakResult).filter(GithubLeakResult.id == item_id).first()
    if not item:
        raise HTTPException(404, "记录不存在")
    db.delete(item)
    db.commit()
    return {"code": 200, "message": "已删除"}


# ── 后台任务 ──────────────────────────────────────────────────

def _do_scan(keyword: str, platform: str, max_results: int,
             github_token: str, gitee_token: str, db: Session):
    from core.github_scanner import scan_by_keyword
    try:
        logger.info(f"[信息收集] 开始扫描 keyword={keyword} platform={platform}")
        results = scan_by_keyword(
            keyword=keyword, platform=platform,
            github_token=github_token, gitee_token=gitee_token,
            max_results=max_results,
        )
        saved = 0
        for r in results:
            if "error" in r:
                logger.warning(f"[信息收集] 扫描警告: {r['error']}")
                continue
            crud.save_github_leak(
                db,
                keyword=keyword,
                platform=r.get("platform", platform),
                repo_name=r.get("repo_name", ""),
                repo_url=r.get("repo_url", ""),
                file_path=r.get("file_path", ""),
                leak_type=r.get("leak_type", "unknown"),
                matched_text=r.get("matched_text", ""),
                severity=r.get("severity", "高"),
            )
            saved += 1

        # 高危告警推送
        if saved > 0:
            try:
                from core.notifier import notify_scan_complete
                notify_scan_complete(db, "GitHub信息收集", {
                    "关键字": keyword,
                    "平台": platform,
                    "发现泄露": f"{saved} 条",
                })
            except Exception:
                pass

        logger.info(f"[信息收集] 完成，keyword={keyword}，写入 {saved} 条")
    except Exception as e:
        logger.error(f"[信息收集] 扫描异常: {e}", exc_info=True)


# ── 私有辅助 ──────────────────────────────────────────────────

def _fmt_result(r: GithubLeakResult) -> dict:
    return {
        "id": r.id,
        "keyword": r.keyword,
        "platform": r.platform,
        "repo_name": r.repo_name,
        "repo_url": r.repo_url,
        "file_path": r.file_path,
        "leak_type": r.leak_type,
        "matched_text": r.matched_text,
        "severity": r.severity,
        "status": r.status,
        "discovered_at": r.discovered_at.strftime("%Y-%m-%d %H:%M:%S") if r.discovered_at else "",
    }
