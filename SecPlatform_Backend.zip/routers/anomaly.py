"""
异常检测路由模块 - routers/anomaly.py
======================================
接口列表：
  POST /api/anomaly/run-detection      手动触发异常检测
  GET  /api/anomaly/events             异常事件列表
  GET  /api/anomaly/stats              统计信息
  GET  /api/anomaly/high-risk-ports    高危端口资产列表
  GET  /api/anomaly/snapshot-times     获取历史快照时间点
  POST /api/anomaly/compare-snapshots  对比两个快照时间点
  PATCH /api/anomaly/{id}/status       更新事件处理状态
  DELETE /api/anomaly/{id}             删除事件记录
"""

import logging
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session
from sqlalchemy import func

from db import models, crud
from db.models import AnomalyEvent
from routers.auth import verify_token, User

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api/anomaly", tags=["10. 异常检测"])


# ── Pydantic Models ────────────────────────────────────────────

class CompareReq(BaseModel):
    time_a: str = Field(..., description="较早时间，格式 YYYY-MM-DD HH:MM:SS")
    time_b: str = Field(..., description="较新时间，格式 YYYY-MM-DD HH:MM:SS")

class StatusUpdateReq(BaseModel):
    status: str = Field(..., description="状态：未处理 / 已确认 / 忽略")


# ── 路由端点 ───────────────────────────────────────────────────

@router.post("/run-detection", summary="手动触发异常检测")
async def run_detection(
    db: Session = Depends(models.get_db),
    user: User = Depends(verify_token),
):
    from core.anomaly_detector import run_anomaly_detection
    result = run_anomaly_detection(db)

    # 如有高危事件，触发通知
    high_count = result.get("summary", {}).get("new_high_risk_ports", 0)
    if high_count > 0:
        try:
            from core.notifier import notify_scan_complete
            notify_scan_complete(db, "异常检测", {
                "新增高危端口": f"{high_count} 处",
                "新增资产": result["summary"].get("new_assets", 0),
                "消失资产": result["summary"].get("disappeared", 0),
            })
        except Exception:
            pass

    return {"code": 200, "data": result}


@router.get("/events", summary="异常事件列表")
async def list_events(
    ip: Optional[str] = None,
    status: Optional[str] = None,
    severity: Optional[str] = None,
    skip: int = 0,
    limit: int = 100,
    db: Session = Depends(models.get_db),
    user: User = Depends(verify_token),
):
    items = crud.get_anomaly_events(db, ip=ip, status=status,
                                    severity=severity, limit=limit + skip)
    items = items[skip:skip + limit]
    total = db.query(func.count(AnomalyEvent.id)).scalar() or 0
    return {
        "code": 200,
        "total": total,
        "data": [_fmt_event(e) for e in items],
    }


@router.get("/stats", summary="异常检测统计")
async def get_stats(
    db: Session = Depends(models.get_db),
    user: User = Depends(verify_token),
):
    from core.anomaly_detector import get_anomaly_stats
    stats = get_anomaly_stats(db)
    return {"code": 200, "data": stats}


@router.get("/high-risk-ports", summary="高危端口资产列表")
async def high_risk_ports(
    db: Session = Depends(models.get_db),
    user: User = Depends(verify_token),
):
    from core.anomaly_detector import get_high_risk_port_assets
    assets = get_high_risk_port_assets(db)
    return {
        "code": 200,
        "total": len(assets),
        "data": assets,
    }


@router.get("/snapshot-times", summary="获取历史快照时间点")
async def get_snapshot_times(
    limit: int = 30,
    db: Session = Depends(models.get_db),
    user: User = Depends(verify_token),
):
    times = crud.get_snapshot_times(db, limit=limit)
    return {"code": 200, "data": times}


@router.post("/compare-snapshots", summary="对比两个时间点的资产快照")
async def compare_snapshots(
    req: CompareReq,
    db: Session = Depends(models.get_db),
    user: User = Depends(verify_token),
):
    result = crud.compare_snapshots(db, req.time_a, req.time_b)
    if "error" in result:
        raise HTTPException(400, result["error"])
    return {"code": 200, "data": result}


@router.patch("/{event_id}/status", summary="更新事件处理状态")
async def update_status(
    event_id: int,
    req: StatusUpdateReq,
    db: Session = Depends(models.get_db),
    user: User = Depends(verify_token),
):
    ok = crud.update_anomaly_status(db, event_id, req.status)
    if not ok:
        raise HTTPException(404, "事件不存在")
    return {"code": 200, "message": "已更新"}


@router.delete("/{event_id}", summary="删除异常事件")
async def delete_event(
    event_id: int,
    db: Session = Depends(models.get_db),
    user: User = Depends(verify_token),
):
    event = db.query(AnomalyEvent).filter(AnomalyEvent.id == event_id).first()
    if not event:
        raise HTTPException(404, "事件不存在")
    db.delete(event)
    db.commit()
    return {"code": 200, "message": "已删除"}


# ── 私有辅助 ──────────────────────────────────────────────────

def _fmt_event(e: AnomalyEvent) -> dict:
    return {
        "id": e.id,
        "ip_address": e.ip_address,
        "anomaly_type": e.anomaly_type,
        "severity": e.severity,
        "description": e.description,
        "old_value": e.old_value,
        "new_value": e.new_value,
        "status": e.status,
        "detected_at": e.detected_at.strftime("%Y-%m-%d %H:%M:%S") if e.detected_at else "",
    }
