"""防火墙策略审核路由"""
import logging
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from pydantic import BaseModel
from typing import Optional

from db import models
from db.models import FirewallPolicy, PolicyAuditResult
from routers.auth import verify_token, User

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api/policy", tags=["策略审核"])

HIGH_RISK_PORTS = {21,22,23,25,110,135,137,139,445,1433,1521,3306,3389,5432,6379,7001,8080,27017,50070}

RISK_RULES = [
    {"id":"r1","name":"允许全端口访问","severity":"高",
     "check": lambda p: p.action=="ALLOW" and (not p.dst_port or p.dst_port.lower() in ("any","all","0-65535","*")),
     "desc": lambda p: f"策略「{p.name}」允许目标所有端口，攻击面极大",
     "suggestion": "按业务精确指定目标端口，最小化开放范围"},
    {"id":"r2","name":"高危端口对外开放","severity":"高",
     "check": lambda p: (p.action=="ALLOW" and
         any(int(pt) in HIGH_RISK_PORTS for pt in _parse_ports(p.dst_port)) and
         (not p.dst_ip or p.dst_ip.lower() in ("any","0.0.0.0/0","*"))),
     "desc": lambda p: f"策略「{p.name}」允许高危端口（22/3389/6379等）对任意目标开放",
     "suggestion": "高危端口仅对明确IP段开放，并启用多因素认证"},
    {"id":"r3","name":"源地址过于宽泛","severity":"中",
     "check": lambda p: (p.action=="ALLOW" and p.src_ip and
         (any(p.src_ip.endswith(s) for s in ("/8","/9","/10","/11","/12")) or
          p.src_ip.lower() in ("any","0.0.0.0/0","*"))),
     "desc": lambda p: f"策略「{p.name}」源地址范围过大（{p.src_ip}），存在横向移动风险",
     "suggestion": "精细化配置源地址段，避免大段IP授权"},
    {"id":"r4","name":"策略缺少备注说明","severity":"低",
     "check": lambda p: not p.description or len(p.description.strip()) < 5,
     "desc": lambda p: f"策略「{p.name}」无业务说明，难以评估必要性",
     "suggestion": "为每条策略添加业务说明、负责人和创建时间"},
]


def _parse_ports(port_str: str) -> list:
    if not port_str or port_str.lower() in ("any","all","*"): return []
    ports = []
    for part in port_str.replace(" ","").split(","):
        if "-" in part:
            try:
                s,e = part.split("-",1); ports.extend(range(int(s), min(int(e)+1,int(s)+100)))
            except Exception: pass
        else:
            try: ports.append(int(part))
            except Exception: pass
    return ports


def _audit_policy(policy) -> list:
    findings = []
    for rule in RISK_RULES:
        try:
            if rule["check"](policy):
                findings.append({"risk_id":rule["id"],"risk_name":rule["name"],
                    "severity":rule["severity"],"description":rule["desc"](policy),"suggestion":rule["suggestion"]})
        except Exception as e:
            logger.warning(f"规则 {rule['id']} 执行异常: {e}")
    return findings


def _p2d(p) -> dict:
    return {"id":p.id,"name":p.name,"device_name":p.device_name,"src_ip":p.src_ip,
            "dst_ip":p.dst_ip,"dst_port":p.dst_port,"protocol":p.protocol,"action":p.action,
            "description":p.description,"created_at":p.created_at.isoformat() if p.created_at else None}


class PolicyCreate(BaseModel):
    name:        str
    device_name: Optional[str] = None
    src_ip:      Optional[str] = None
    dst_ip:      Optional[str] = None
    dst_port:    Optional[str] = None
    protocol:    str = "TCP"
    action:      str = "ALLOW"
    description: Optional[str] = None


@router.get("/", summary="策略列表")
async def list_policies(db: Session=Depends(models.get_db), user: User=Depends(verify_token)):
    ps = db.query(FirewallPolicy).order_by(FirewallPolicy.created_at.desc()).all()
    return {"code":200,"total":len(ps),"data":[_p2d(p) for p in ps]}


@router.post("/", summary="导入策略")
async def create_policy(body: PolicyCreate, db: Session=Depends(models.get_db), user: User=Depends(verify_token)):
    p = FirewallPolicy(**body.model_dump(), created_by=user.username)
    db.add(p); db.commit(); db.refresh(p)
    return {"code":200,"message":"策略添加成功","id":p.id}


@router.post("/audit-all", summary="全量审核")
async def audit_all(db: Session=Depends(models.get_db), user: User=Depends(verify_token)):
    policies = db.query(FirewallPolicy).all()
    db.query(PolicyAuditResult).delete(); db.commit()
    total = 0
    for p in policies:
        for f in _audit_policy(p):
            db.add(PolicyAuditResult(policy_id=p.id, policy_name=p.name, **{k:f[k] for k in f}))
            total += 1
    db.commit()
    return {"code":200,"message":f"审核完成，发现 {total} 条风险","findings":total}


@router.post("/{policy_id}/audit", summary="单策略审核")
async def audit_policy_single(policy_id: int, db: Session=Depends(models.get_db), user: User=Depends(verify_token)):
    p = db.query(FirewallPolicy).filter(FirewallPolicy.id==policy_id).first()
    if not p: raise HTTPException(status_code=404, detail="策略不存在")
    db.query(PolicyAuditResult).filter(PolicyAuditResult.policy_id==policy_id).delete(); db.commit()
    findings = _audit_policy(p)
    for f in findings:
        db.add(PolicyAuditResult(policy_id=p.id, policy_name=p.name, **{k:f[k] for k in f}))
    db.commit()
    return {"code":200,"findings":len(findings),"data":findings}


@router.get("/results", summary="审核结果列表")
async def list_results(db: Session=Depends(models.get_db), user: User=Depends(verify_token)):
    rs = db.query(PolicyAuditResult).order_by(PolicyAuditResult.created_at.desc()).all()
    return {"code":200,"total":len(rs),"data":[
        {"id":r.id,"policy_id":r.policy_id,"policy_name":r.policy_name,"risk_id":r.risk_id,
         "risk_name":r.risk_name,"severity":r.severity,"description":r.description,"suggestion":r.suggestion,
         "created_at":r.created_at.isoformat() if r.created_at else None} for r in rs]}


@router.delete("/{policy_id}", summary="删除策略")
async def delete_policy(policy_id: int, db: Session=Depends(models.get_db), user: User=Depends(verify_token)):
    p = db.query(FirewallPolicy).filter(FirewallPolicy.id==policy_id).first()
    if not p: raise HTTPException(status_code=404, detail="策略不存在")
    db.query(PolicyAuditResult).filter(PolicyAuditResult.policy_id==policy_id).delete()
    db.delete(p); db.commit()
    return {"code":200,"message":"删除成功"}
