"""
系统健康检查路由 - routers/health.py
===================================

负责系统状态监控和诊断
- 数据库连接状态
- Redis 连接状态
- Celery 任务队列状态
- 系统资源使用情况
"""

import logging
import os
import psutil  # pip install psutil
from datetime import datetime
from typing import Dict, Any

from fastapi import APIRouter, HTTPException, status, Depends
from sqlalchemy import text

from db import models
from routers.auth import verify_token, User

logger = logging.getLogger(__name__)

# ========================================
# 路由器定义
# ========================================
router = APIRouter(
    prefix="/api/health",
    tags=["3. 系统"]
)

# ========================================
# 健康检查函数
# ========================================

def check_database() -> Dict[str, Any]:
    """检查数据库连接状态"""
    try:
        is_connected, msg = models.check_db_connection()
        return {
            "status": "healthy" if is_connected else "unhealthy",
            "message": msg,
            "timestamp": datetime.utcnow().isoformat()
        }
    except Exception as e:
        return {
            "status": "unhealthy",
            "message": f"数据库检查异常: {str(e)}",
            "timestamp": datetime.utcnow().isoformat()
        }


def check_redis() -> Dict[str, Any]:
    """检查 Redis 连接状态"""
    try:
        import redis
        from core.config import settings
        
        r = redis.Redis(
            host=settings.REDIS_HOST,
            port=settings.REDIS_PORT,
            db=settings.REDIS_DB,
            socket_connect_timeout=3
        )
        r.ping()
        
        # 获取 Redis 信息
        info = r.info()
        return {
            "status": "healthy",
            "message": "连接正常",
            "used_memory_mb": round(info.get("used_memory", 0) / 1024 / 1024, 2),
            "connected_clients": info.get("connected_clients", 0),
            "timestamp": datetime.utcnow().isoformat()
        }
    except Exception as e:
        return {
            "status": "unhealthy",
            "message": f"Redis 连接失败: {str(e)}",
            "timestamp": datetime.utcnow().isoformat()
        }


def check_celery() -> Dict[str, Any]:
    """检查 Celery 任务队列状态"""
    try:
        from celery_app import celery_app
        
        # 尝试连接 Celery broker
        with celery_app.connection() as conn:
            conn.connect()
        
        return {
            "status": "healthy",
            "message": "任务队列连接正常",
            "broker": celery_app.conf.broker_url,
            "timestamp": datetime.utcnow().isoformat()
        }
    except Exception as e:
        return {
            "status": "unhealthy",
            "message": f"Celery 连接失败: {str(e)}",
            "timestamp": datetime.utcnow().isoformat()
        }


def check_system_resources() -> Dict[str, Any]:
    """检查系统资源使用情况"""
    try:
        # CPU 使用率
        cpu_percent = psutil.cpu_percent(interval=1)
        
        # 内存使用
        memory = psutil.virtual_memory()
        
        # 磁盘使用
        disk = psutil.disk_usage("/")
        
        # 进程数
        process_count = len(psutil.pids())
        
        # 当前进程信息
        current_process = psutil.Process(os.getpid())
        process_memory = current_process.memory_info().rss / 1024 / 1024  # MB
        
        return {
            "status": "healthy",
            "cpu_percent": cpu_percent,
            "memory_percent": memory.percent,
            "memory_used_gb": round(memory.used / 1024 / 1024 / 1024, 2),
            "memory_available_gb": round(memory.available / 1024 / 1024 / 1024, 2),
            "disk_percent": disk.percent,
            "disk_used_gb": round(disk.used / 1024 / 1024 / 1024, 2),
            "disk_free_gb": round(disk.free / 1024 / 1024 / 1024, 2),
            "process_count": process_count,
            "current_process_memory_mb": round(process_memory, 2),
            "timestamp": datetime.utcnow().isoformat()
        }
    except Exception as e:
        return {
            "status": "unknown",
            "message": f"资源检查异常: {str(e)}",
            "timestamp": datetime.utcnow().isoformat()
        }


# ========================================
# 路由端点
# ========================================

@router.get(
    "/",
    summary="🏥 系统健康检查",
    description="获取系统整体健康状态"
)
async def health_check():
    """
    快速健康检查
    
    这是一个不需要认证的端点，用于监控系统状态
    
    返回示例（健康）：
    ```json
    {
        "status": "healthy",
        "service": "SecPlatform",
        "timestamp": "2024-01-15T10:30:45.123456"
    }
    ```
    """
    return {
        "status": "healthy",
        "service": "SecPlatform",
        "timestamp": datetime.utcnow().isoformat()
    }


@router.get(
    "/detailed",
    summary="🔍 详细健康检查",
    description="获取系统各组件的详细健康状态（需要认证）"
)
async def detailed_health_check(user: User = Depends(verify_token)):
    """
    详细的系统健康检查
    
    检查项：
    - 数据库连接
    - Redis 连接
    - Celery 任务队列
    - 系统资源（CPU/内存/磁盘）
    
    返回示例：
    ```json
    {
        "timestamp": "2024-01-15T10:30:45.123456",
        "overall_status": "healthy",
        "components": {
            "database": {
                "status": "healthy",
                "message": "连接正常"
            },
            "redis": {
                "status": "healthy",
                "used_memory_mb": 25.5,
                "connected_clients": 4
            },
            "celery": {
                "status": "healthy",
                "message": "任务队列连接正常"
            },
            "system": {
                "cpu_percent": 25.3,
                "memory_percent": 45.2,
                "disk_percent": 60.1
            }
        }
    }
    ```
    """
    try:
        logger.info(f"👤 用户 {user.username} 请求详细健康检查")
        
        # 执行所有检查
        database_status = check_database()
        redis_status = check_redis()
        celery_status = check_celery()
        system_status = check_system_resources()
        
        # 判断整体状态
        unhealthy_count = sum([
            database_status["status"] == "unhealthy",
            redis_status["status"] == "unhealthy",
            celery_status["status"] == "unhealthy"
        ])
        
        overall_status = "unhealthy" if unhealthy_count >= 2 else "degraded" if unhealthy_count == 1 else "healthy"
        
        return {
            "timestamp": datetime.utcnow().isoformat(),
            "overall_status": overall_status,
            "components": {
                "database": database_status,
                "redis": redis_status,
                "celery": celery_status,
                "system": system_status
            }
        }
    
    except Exception as e:
        logger.error(f"❌ 健康检查异常: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"健康检查失败: {str(e)}"
        )


@router.get(
    "/database",
    summary="🗄️ 数据库状态",
    description="检查数据库连接状态"
)
async def database_health(user: User = Depends(verify_token)):
    """数据库状态检查"""
    status_info = check_database()
    
    if status_info["status"] != "healthy":
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail=status_info["message"]
        )
    
    return status_info


@router.get(
    "/redis",
    summary="⚡ Redis 状态",
    description="检查 Redis 连接和性能"
)
async def redis_health(user: User = Depends(verify_token)):
    """Redis 状态检查"""
    status_info = check_redis()
    
    if status_info["status"] != "healthy":
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail=status_info["message"]
        )
    
    return status_info


@router.get(
    "/celery",
    summary="📋 Celery 队列状态",
    description="检查 Celery 任务队列连接"
)
async def celery_health(user: User = Depends(verify_token)):
    """Celery 状态检查"""
    status_info = check_celery()
    
    if status_info["status"] != "healthy":
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail=status_info["message"]
        )
    
    return status_info


@router.get(
    "/resources",
    summary="💻 系统资源使用",
    description="获取 CPU、内存、磁盘使用情况"
)
async def system_resources(user: User = Depends(verify_token)):
    """系统资源检查"""
    return check_system_resources()


@router.get(
    "/info",
    summary="ℹ️ 系统信息",
    description="获取系统版本和配置信息"
)
async def system_info(user: User = Depends(verify_token)):
    """获取系统信息"""
    from core.config import settings
    
    return {
        "service": "SecPlatform",
        "version": "3.0.0",
        "environment": {
            "db_configured": bool(settings.DB_URL),
            "redis_host": settings.REDIS_HOST,
            "redis_port": settings.REDIS_PORT,
            "log_level": settings.LOG_LEVEL,
            "max_targets_per_scan": settings.MAX_TARGETS_PER_SCAN,
            "concurrent_workers": settings.CONCURRENT_WORKERS
        },
        "timestamp": datetime.utcnow().isoformat()
    }


@router.get("/worker", summary="🔧 Celery Worker 存活检查")
async def worker_health():
    """检查 Celery Worker 是否在线（不需要登录）"""
    try:
        from celery_app import celery_app
        # inspect 发现存活的 worker
        inspector = celery_app.control.inspect(timeout=3)
        stats = inspector.stats()
        if stats:
            worker_names = list(stats.keys())
            return {"running": True, "workers": worker_names, "count": len(worker_names)}
        else:
            return {"running": False, "workers": [], "message": "没有发现在线的 Worker"}
    except Exception as e:
        return {"running": False, "error": str(e)}
