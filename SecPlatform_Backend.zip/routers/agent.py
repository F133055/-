"""
AI 智能分析师路由 (MD 十: 智能体能力)
支持：自动分析、自动风险判断、自动报告建议
"""
import logging
from datetime import datetime
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from pydantic import BaseModel
from typing import Optional

from db import models
from db.models import AppSetting
from routers.auth import verify_token, User

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api/agent", tags=["AI智能分析"])


# ── Pydantic 模型 ──────────────────────────────────────────────
class AnalyzeRequest(BaseModel):
    query:    str
    context:  Optional[str] = None   # 额外上下文（如选中的资产/漏洞）

class SettingUpdate(BaseModel):
    llm_api_url:  Optional[str] = None
    llm_api_key:  Optional[str] = None
    llm_model:    Optional[str] = None


# ── 辅助函数 ─────────────────────────────────────────────────
def _upsert_setting(db: Session, key: str, value: str, desc: str = ""):
    row = db.query(AppSetting).filter(AppSetting.key == key).first()
    if row:
        row.value = value
    else:
        row = AppSetting(key=key, value=value, desc=desc)
        db.add(row)


def _get_setting(db: Session, key: str) -> Optional[str]:
    row = db.query(AppSetting).filter(AppSetting.key == key).first()
    return row.value if row else None


# ── LLM 配置接口 ───────────────────────────────────────────────
@router.get("/config", summary="获取 LLM 配置（Key 脱敏）")
async def get_llm_config(
    db:   Session = Depends(models.get_db),
    user: User    = Depends(verify_token),
):
    api_url = _get_setting(db, "llm_api_url") or ""
    api_key = _get_setting(db, "llm_api_key") or ""
    model   = _get_setting(db, "llm_model")   or "gpt-4o-mini"

    # 脱敏 key
    masked_key = ""
    if api_key:
        masked_key = api_key[:6] + "****" + api_key[-4:] if len(api_key) > 12 else "****"

    from core.llm_client import is_llm_configured
    return {
        "code":     200,
        "enabled":  is_llm_configured(db),
        "api_url":  api_url,
        "api_key":  masked_key,
        "model":    model,
        "has_key":  bool(api_key),
    }


@router.post("/config", summary="保存 LLM 配置")
async def save_llm_config(
    body: SettingUpdate,
    db:   Session = Depends(models.get_db),
    user: User    = Depends(verify_token),
):
    try:
        if body.llm_api_url is not None:
            _upsert_setting(db, "llm_api_url", body.llm_api_url.strip(), "LLM API 地址")
        if body.llm_api_key is not None and body.llm_api_key != "****":
            _upsert_setting(db, "llm_api_key", body.llm_api_key.strip(), "LLM API Key")
        if body.llm_model is not None:
            _upsert_setting(db, "llm_model", body.llm_model.strip(), "LLM 模型名称")
        db.commit()
        return {"code": 200, "message": "LLM 配置保存成功"}
    except Exception as e:
        db.rollback()
        logger.error(f"保存 LLM 配置失败: {e}")
        raise HTTPException(500, f"保存失败: {str(e)}")


@router.post("/test", summary="测试 LLM 连接")
async def test_llm(
    db:   Session = Depends(models.get_db),
    user: User    = Depends(verify_token),
):
    from core.llm_client import call_llm, is_llm_configured
    if not is_llm_configured(db):
        return {"code": 400, "success": False, "message": "LLM 未配置，请先填写 API Key"}

    result = call_llm("请回复：连接测试成功", db=db, max_tokens=50)
    if result:
        return {"code": 200, "success": True, "message": f"连接成功！模型回复: {result[:80]}"}
    else:
        return {"code": 500, "success": False, "message": "连接失败，请检查 API 地址和 Key"}


# ── AI 分析接口 ────────────────────────────────────────────────
@router.post("/analyze", summary="AI 安全分析")
async def ai_analyze(
    body: AnalyzeRequest,
    db:   Session = Depends(models.get_db),
    user: User    = Depends(verify_token),
):
    from core.llm_client import call_llm, is_llm_configured

    if not is_llm_configured(db):
        return {
            "code":    400,
            "answer":  "⚠️ AI 智能分析未配置。请前往「系统设置 → AI 配置」填写 LLM API Key。\n\n支持 OpenAI / 本地 Ollama / 任何兼容 OpenAI 接口的模型。",
            "enabled": False,
        }

    # 收集平台当前数据作为上下文
    context_parts = []
    try:
        from sqlalchemy import func
        total_assets  = db.query(func.count()).select_from(models.Asset).scalar() or 0
        online_assets = db.query(func.count()).select_from(models.Asset).filter(
            models.Asset.status == "online"
        ).scalar() or 0
        total_vulns   = db.query(func.count()).select_from(models.Vulnerability).scalar() or 0
        high_vulns    = db.query(func.count()).select_from(models.Vulnerability).filter(
            models.Vulnerability.severity.in_(["严重", "高"])
        ).scalar() or 0
        context_parts.append(
            f"【平台当前数据】\n"
            f"- 资产总数: {total_assets}（在线: {online_assets}）\n"
            f"- 漏洞总数: {total_vulns}（高危/严重: {high_vulns}）\n"
        )
    except Exception:
        pass

    # 最近漏洞
    try:
        recent_vulns = db.query(models.Vulnerability).order_by(
            models.Vulnerability.id.desc()
        ).limit(5).all()
        if recent_vulns:
            vlist = "\n".join(
                f"  · [{v.severity}] {v.ip_address} — {v.title}" for v in recent_vulns
            )
            context_parts.append(f"【最近漏洞（5条）】\n{vlist}")
    except Exception:
        pass

    if body.context:
        context_parts.append(f"【用户提供的上下文】\n{body.context}")

    platform_ctx = "\n\n".join(context_parts) if context_parts else "（暂无平台数据）"

    system_prompt = (
        "你是 SecPlatform 安全专项扫描与智能分析平台的 AI 安全分析师。\n"
        "你负责分析安全数据、识别风险、提供修复建议。\n"
        "回答要专业、简洁、实用，使用中文，结构清晰（可用 Markdown 格式）。\n"
        "不要过度解释，直接给出关键结论和行动建议。"
    )

    full_prompt = f"当前平台安全状态：\n\n{platform_ctx}\n\n用户问题：{body.query}"

    answer = call_llm(full_prompt, system=system_prompt, db=db, max_tokens=1500)

    if answer is None:
        return {
            "code":    500,
            "answer":  "AI 分析失败，请检查 LLM 连接配置或稍后重试。",
            "enabled": True,
        }

    return {"code": 200, "answer": answer, "enabled": True}


@router.post("/report-summary", summary="AI 生成报告摘要")
async def ai_report_summary(
    db:   Session = Depends(models.get_db),
    user: User    = Depends(verify_token),
):
    """基于当前数据，让 AI 生成一份安全状况摘要"""
    from core.llm_client import call_llm, is_llm_configured
    from sqlalchemy import func

    if not is_llm_configured(db):
        return {"code": 400, "summary": None, "message": "LLM 未配置"}

    try:
        total_assets  = db.query(func.count()).select_from(models.Asset).scalar() or 0
        online_assets = db.query(func.count()).select_from(models.Asset).filter(
            models.Asset.status == "online"
        ).scalar() or 0
        total_vulns   = db.query(func.count()).select_from(models.Vulnerability).scalar() or 0
        high_vulns    = db.query(func.count()).select_from(models.Vulnerability).filter(
            models.Vulnerability.severity.in_(["严重", "高"])
        ).scalar() or 0
        recent_vulns = db.query(models.Vulnerability).order_by(
            models.Vulnerability.id.desc()
        ).limit(10).all()
        vuln_list = "\n".join(
            f"  - [{v.severity}] {v.ip_address} {v.title} ({v.vuln_type})"
            for v in recent_vulns
        )
    except Exception as e:
        return {"code": 500, "summary": None, "message": f"数据查询失败: {e}"}

    prompt = (
        f"请基于以下安全数据生成一份专业的安全状况分析摘要（300字左右）：\n\n"
        f"资产情况：共 {total_assets} 个资产，在线 {online_assets} 个\n"
        f"漏洞情况：共 {total_vulns} 个漏洞，其中高危/严重 {high_vulns} 个\n"
        f"最近漏洞：\n{vuln_list or '暂无'}\n\n"
        f"要求：\n"
        f"1. 评估当前安全风险等级（低/中/高/严重）\n"
        f"2. 指出最紧迫的安全问题\n"
        f"3. 给出3-5条具体整改建议\n"
        f"4. 使用 Markdown 格式，简洁专业"
    )

    summary = call_llm(
        prompt,
        system="你是一位专业的网络安全工程师，擅长安全评估报告撰写。",
        db=db, max_tokens=800
    )

    return {"code": 200, "summary": summary, "generated_at": datetime.now().isoformat()}
