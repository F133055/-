"""定时扫描任务路由 v4.1 — CRUD + 立即触发，支持 interval/daily/weekly"""
import json
import logging
from datetime import datetime
from typing import Optional, List
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from pydantic import BaseModel

from db import models
from routers.auth import verify_token, User

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api/scheduler", tags=["8. 定时任务"])


# ── 请求体模型 ─────────────────────────────────────────────────
class ScheduledTaskCreate(BaseModel):
    name:           str
    task_type:      str                      # asset/vuln/weakpass/quickscan
    targets:        list
    params:         dict  = {}               # {vuln_type, service, port, checks, ports}
    schedule_type:  str   = "interval"       # interval / daily / weekly
    interval_hours: int   = 24               # schedule_type=interval 使用
    run_at_time:    Optional[str] = None     # HH:MM  daily/weekly 使用
    run_on_days:    Optional[list] = None    # [0-6] (Mon=0) weekly 使用
    enabled:        bool  = True


class ScheduledTaskUpdate(BaseModel):
    name:           Optional[str]   = None
    enabled:        Optional[bool]  = None
    schedule_type:  Optional[str]   = None
    interval_hours: Optional[int]   = None
    run_at_time:    Optional[str]   = None
    run_on_days:    Optional[list]  = None
    targets:        Optional[list]  = None
    params:         Optional[dict]  = None


def _row(t) -> dict:
    return {
        "id":             t.id,
        "name":           t.name,
        "task_type":      t.task_type,
        "targets":        json.loads(t.targets or "[]"),
        "params":         json.loads(t.params  or "{}"),
        "schedule_type":  t.schedule_type or "interval",
        "interval_hours": t.interval_hours or 24,
        "run_at_time":    t.run_at_time,
        "run_on_days":    json.loads(t.run_on_days or "[]") if t.run_on_days else [],
        "enabled":        t.enabled,
        "last_run":       t.last_run.strftime("%Y-%m-%d %H:%M")  if t.last_run   else None,
        "next_run":       t.next_run.strftime("%Y-%m-%d %H:%M")  if t.next_run   else None,
        "last_status":    t.last_status,
        "run_count":      t.run_count or 0,
        "created_by":     t.created_by,
        "created_at":     t.created_at.strftime("%Y-%m-%d %H:%M") if t.created_at else "",
    }


def _build_next_run(req: ScheduledTaskCreate) -> datetime:
    """根据调度配置计算首次运行时间"""
    from core.task_scheduler import calc_next_run

    class _T:
        schedule_type  = req.schedule_type
        interval_hours = req.interval_hours
        run_at_time    = req.run_at_time or "08:00"
        run_on_days    = json.dumps(req.run_on_days) if req.run_on_days else "[0]"

    return calc_next_run(_T())


# ── CRUD ──────────────────────────────────────────────────────
@router.get("/", summary="定时任务列表")
async def list_tasks(db: Session = Depends(models.get_db),
                     user: User  = Depends(verify_token)):
    from db.models import ScheduledTask
    tasks = db.query(ScheduledTask).order_by(ScheduledTask.created_at.desc()).all()
    return {"code": 200, "data": [_row(t) for t in tasks]}


@router.post("/", summary="创建定时任务")
async def create_task(req: ScheduledTaskCreate,
                      db: Session = Depends(models.get_db),
                      user: User  = Depends(verify_token)):
    from db.models import ScheduledTask
    t = ScheduledTask(
        name           = req.name,
        task_type      = req.task_type,
        targets        = json.dumps(req.targets,  ensure_ascii=False),
        params         = json.dumps(req.params,   ensure_ascii=False),
        schedule_type  = req.schedule_type,
        interval_hours = req.interval_hours,
        run_at_time    = req.run_at_time,
        run_on_days    = json.dumps(req.run_on_days) if req.run_on_days else None,
        enabled        = req.enabled,
        next_run       = _build_next_run(req),
        created_by     = user.username,
        last_status    = "pending",
    )
    db.add(t); db.commit(); db.refresh(t)
    logger.info(f"👤 {user.username} 创建定时任务: [{req.name}] type={req.task_type} schedule={req.schedule_type}")
    return {"code": 200, "message": "定时任务已创建", "data": _row(t)}


@router.patch("/{task_id}", summary="更新定时任务")
async def update_task(task_id: int,
                      req: ScheduledTaskUpdate,
                      db: Session = Depends(models.get_db),
                      user: User  = Depends(verify_token)):
    from db.models import ScheduledTask
    from core.task_scheduler import calc_next_run
    t = db.query(ScheduledTask).filter(ScheduledTask.id == task_id).first()
    if not t:
        raise HTTPException(status_code=404, detail="任务不存在")
    if req.name           is not None: t.name           = req.name
    if req.enabled        is not None: t.enabled        = req.enabled
    if req.schedule_type  is not None: t.schedule_type  = req.schedule_type
    if req.interval_hours is not None: t.interval_hours = req.interval_hours
    if req.run_at_time    is not None: t.run_at_time    = req.run_at_time
    if req.run_on_days    is not None: t.run_on_days    = json.dumps(req.run_on_days)
    if req.targets        is not None: t.targets        = json.dumps(req.targets, ensure_ascii=False)
    if req.params         is not None: t.params         = json.dumps(req.params,  ensure_ascii=False)
    # 重新计算下次运行时间
    t.next_run = calc_next_run(t)
    db.commit()
    return {"code": 200, "message": "已更新", "data": _row(t)}


@router.delete("/{task_id}", summary="删除定时任务")
async def delete_task(task_id: int,
                      db: Session = Depends(models.get_db),
                      user: User  = Depends(verify_token)):
    from db.models import ScheduledTask
    t = db.query(ScheduledTask).filter(ScheduledTask.id == task_id).first()
    if not t:
        raise HTTPException(status_code=404, detail="任务不存在")
    db.delete(t); db.commit()
    logger.info(f"👤 {user.username} 删除定时任务: [{t.name}]")
    return {"code": 200, "message": "已删除"}


@router.post("/{task_id}/run", summary="立即执行一次")
async def run_now(task_id: int,
                  db: Session = Depends(models.get_db),
                  user: User  = Depends(verify_token)):
    from db.models import ScheduledTask
    from core.task_scheduler import dispatch_task, calc_next_run
    t = db.query(ScheduledTask).filter(ScheduledTask.id == task_id).first()
    if not t:
        raise HTTPException(status_code=404, detail="任务不存在")
    ok = dispatch_task(t)
    t.last_run    = datetime.utcnow()
    t.next_run    = calc_next_run(t)
    t.last_status = "ok" if ok else "error"
    t.run_count   = (t.run_count or 0) + 1
    db.commit()
    logger.info(f"👤 {user.username} 手动触发定时任务 [{t.name}], ok={ok}")
    return {"code": 200, "message": "任务已触发" if ok else "触发失败", "dispatched": ok}
