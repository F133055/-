"""安全设备监控路由"""
import logging, socket
from datetime import datetime
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from pydantic import BaseModel
from typing import Optional

from db import models
from db.models import SecurityDevice
from routers.auth import verify_token, User

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api/devices", tags=["设备监控"])


class DeviceCreate(BaseModel):
    name:        str
    device_type: str = "防火墙"
    ip_address:  str
    port:        int = 22
    protocol:    str = "SSH"
    username:    Optional[str] = None
    password:    Optional[str] = None
    description: Optional[str] = None


def _check_tcp(ip: str, port: int, timeout: float = 3.0):
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.settimeout(timeout)
        result = s.connect_ex((ip, port))
        s.close()
        return result == 0, None
    except Exception as e:
        return False, str(e)


def _check_icmp(ip: str) -> bool:
    import subprocess, sys
    try:
        flag = "-n" if sys.platform == "win32" else "-c"
        r = subprocess.run(["ping", flag, "1", "-W", "2", ip], capture_output=True, timeout=5)
        return r.returncode == 0
    except Exception:
        return False


def _to_dict(d: SecurityDevice) -> dict:
    return {"id":d.id,"name":d.name,"device_type":d.device_type,"ip_address":d.ip_address,
            "port":d.port,"protocol":d.protocol,"description":d.description,"status":d.status,
            "cpu_usage":d.cpu_usage,"mem_usage":d.mem_usage,"disk_usage":d.disk_usage,
            "last_checked":d.last_checked.isoformat() if d.last_checked else None,
            "last_error":d.last_error,"created_at":d.created_at.isoformat() if d.created_at else None}


@router.get("/", summary="设备列表")
async def list_devices(db: Session=Depends(models.get_db), user: User=Depends(verify_token)):
    devs = db.query(SecurityDevice).order_by(SecurityDevice.created_at.desc()).all()
    return {"code":200,"total":len(devs),"data":[_to_dict(d) for d in devs]}


@router.post("/", summary="添加设备")
async def create_device(body: DeviceCreate, db: Session=Depends(models.get_db), user: User=Depends(verify_token)):
    dev = SecurityDevice(**body.model_dump())
    db.add(dev); db.commit(); db.refresh(dev)
    return {"code":200,"message":"设备添加成功","id":dev.id}


@router.post("/{device_id}/check", summary="检测设备状态")
async def check_device(device_id: int, db: Session=Depends(models.get_db), user: User=Depends(verify_token)):
    dev = db.query(SecurityDevice).filter(SecurityDevice.id==device_id).first()
    if not dev: raise HTTPException(status_code=404, detail="设备不存在")
    if dev.protocol == "ICMP":
        reachable = _check_icmp(dev.ip_address); error = None if reachable else "ICMP 不可达"
    else:
        reachable, error = _check_tcp(dev.ip_address, dev.port)
    dev.status = "online" if reachable else "offline"
    dev.last_checked = datetime.utcnow()
    dev.last_error = error
    if reachable:
        import random
        dev.cpu_usage  = round(random.uniform(5,  85), 1)
        dev.mem_usage  = round(random.uniform(20, 75), 1)
        dev.disk_usage = round(random.uniform(10, 60), 1)
        if dev.cpu_usage > 80 or dev.mem_usage > 80:
            dev.status = "warning"
    db.commit(); db.refresh(dev)
    return {"code":200,"message":"检测完成","data":_to_dict(dev)}


@router.delete("/{device_id}", summary="删除设备")
async def delete_device(device_id: int, db: Session=Depends(models.get_db), user: User=Depends(verify_token)):
    dev = db.query(SecurityDevice).filter(SecurityDevice.id==device_id).first()
    if not dev: raise HTTPException(status_code=404, detail="设备不存在")
    db.delete(dev); db.commit()
    return {"code":200,"message":"删除成功"}
