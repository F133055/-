"""
扫描路由模块 - routers/scan.py  (v4 修订版)
============================================
保留原有全部功能，新增：
  - POST /api/scan/weakpass   (弱口令，同 /weakness，新前端使用)
  - GET  /api/scan/tasks      (任务历史列表)
"""

import logging
import re
import uuid
from typing import List

from fastapi import APIRouter, HTTPException, Depends, status, BackgroundTasks
from fastapi import UploadFile, File, Form
from pydantic import BaseModel, Field, field_validator
from sqlalchemy.orm import Session
from celery.result import AsyncResult

from core import core_scanner, vuln_scanner
from core.config import settings
from db import models, crud
from routers.auth import verify_token, User
from celery_app import (
    celery_app,
    async_weakpass_task,
    async_asset_scan_task,
    async_vuln_scan_task
)

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/scan", tags=["1. 扫描"])

# ── IP 验证 ────────────────────────────────────────────────────
IP_PATTERN       = re.compile(r'^((25[0-5]|2[0-4]\d|[01]?\d\d?)\.){3}(25[0-5]|2[0-4]\d|[01]?\d\d?)$')
DOMAIN_PATTERN   = re.compile(r'^(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z0-9][a-z0-9-]{0,61}[a-z0-9]$')
IP_RANGE_PATTERN = re.compile(r'^((25[0-5]|2[0-4]\d|[01]?\d\d?)\.){3}(25[0-5]|2[0-4]\d|[01]?\d\d?)/([0-9]|[1-2][0-9]|3[0-2])$')

def sanitize_target(t: str) -> str:
    """去除协议前缀，提取纯 IP/域名，支持 http:// https:// 等"""
    t = t.strip()
    # 去除协议
    for prefix in ("https://", "http://", "ftp://"):
        if t.lower().startswith(prefix):
            t = t[len(prefix):]
            break
    # 去除路径、端口后的内容（保留 IP/域名 部分）
    t = t.split("/")[0].split("?")[0].split("#")[0]
    # 如果有端口，只取 host 部分（域名:端口 或 IP:端口）
    if t.count(":") == 1 and not t.startswith("["):
        t = t.split(":")[0]
    return t.strip()


def validate_targets(targets: List[str]) -> tuple[bool, str]:
    if not targets:
        return False, "目标列表不能为空"
    if len(targets) > settings.MAX_TARGETS_PER_SCAN:
        return False, f"单次扫描目标数不能超过 {settings.MAX_TARGETS_PER_SCAN}"
    for raw in targets:
        t = sanitize_target(raw)
        if not t:
            return False, f"无效的目标: {raw}"
        if not (IP_PATTERN.match(t) or DOMAIN_PATTERN.match(t) or IP_RANGE_PATTERN.match(t)):
            return False, f"无效的目标格式: {raw}（解析后: {t}）"
    return True, ""


# ── 数据模型 ───────────────────────────────────────────────────
class AssetScanRequest(BaseModel):
    targets: List[str] = Field(..., min_items=1)
    ports: List[int]   = Field(default=[22, 53, 80, 135, 443, 3306, 6379, 8848])
    timeout: int       = Field(default=300, ge=30, le=3600)

    @field_validator('targets')
    @classmethod
    def validate_targets_field(cls, v):
        # sanitize 后再验证，支持 https:// URL
        v = [sanitize_target(t) for t in v if sanitize_target(t)]
        ok, msg = validate_targets(v)
        if not ok:
            raise ValueError(msg)
        return v


class VulnScanRequest(BaseModel):
    targets: List[str] = Field(..., min_items=1)
    vuln_type: str     = Field(default="nacos")

    @field_validator('targets')
    @classmethod
    def validate_targets_field(cls, v):
        # sanitize 后再验证，支持 https:// URL
        v = [sanitize_target(t) for t in v if sanitize_target(t)]
        ok, msg = validate_targets(v)
        if not ok:
            raise ValueError(msg)
        return v


class WeakPassScanRequest(BaseModel):
    targets: List[str] = Field(..., min_items=1)
    service: str       = Field(default="ssh")

    @field_validator('targets')
    @classmethod
    def validate_targets_field(cls, v):
        # sanitize 后再验证，支持 https:// URL
        v = [sanitize_target(t) for t in v if sanitize_target(t)]
        ok, msg = validate_targets(v)
        if not ok:
            raise ValueError(msg)
        return v


class TaskStatusResponse(BaseModel):
    task_id:  str  = Field(...)
    status:   str  = Field(...)
    result:   dict = Field(default={})
    progress: int  = Field(default=0)


# ── 工具：安全记录任务到 DB（失败不影响主流程）────────────────
def _record_task(db: Session, task_id: str, task_type: str,
                 targets: list, params: dict, operator: str):
    try:
        from db.models import ScanTask
        import json
        t = ScanTask(
            task_id=task_id,
            task_type=task_type,
            targets=json.dumps(targets, ensure_ascii=False),
            params=json.dumps(params, ensure_ascii=False),
            operator=operator,
            status="PENDING",
        )
        db.add(t)
        db.commit()
    except Exception as e:
        db.rollback()
        logger.warning(f"记录任务到 DB 失败（不影响扫描）: {e}")


# ── 资产扫描 ───────────────────────────────────────────────────
@router.post("/asset", summary="🚀 启动资产扫描任务")
async def start_asset_scan(
    request: AssetScanRequest,
    background_tasks: BackgroundTasks,
    db: Session = Depends(models.get_db),
    user: User = Depends(verify_token)
):
    try:
        logger.info(f"👤 {user.username} 发起资产扫描: {request.targets}")
        task = async_asset_scan_task.delay(
            target_ips=request.targets,
            target_ports=request.ports
        )
        _record_task(db, task.id, "asset", request.targets,
                     {"ports": request.ports}, user.username)
        logger.info(f"✅ 任务已创建: {task.id}")
        return {"code": 202, "message": "任务已发起", "task_id": task.id,
                "task_url": f"/api/scan/task/{task.id}", "targets_count": len(request.targets)}
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"❌ 启动资产扫描失败: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"启动扫描失败: {str(e)}")


# ── 漏洞扫描 ───────────────────────────────────────────────────
@router.post("/vuln", summary="🔍 启动漏洞专项扫描")
async def start_vuln_scan(
    request: VulnScanRequest,
    db: Session = Depends(models.get_db),
    user: User = Depends(verify_token)
):
    try:
        task = async_vuln_scan_task.delay(
            target_ips=request.targets,
            vuln_type=request.vuln_type
        )
        _record_task(db, task.id, "vuln", request.targets,
                     {"vuln_type": request.vuln_type}, user.username)
        return {"code": 202, "message": "漏洞扫描任务已发起", "task_id": task.id,
                "vuln_type": request.vuln_type, "targets_count": len(request.targets)}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"启动扫描失败: {str(e)}")


# ── 弱口令（原路径 + 新路径，两个都注册）─────────────────────
async def _do_weakpass(request: WeakPassScanRequest,
                       db: Session, user: User):
    SUPPORTED = ["ssh", "mysql", "ftp", "redis", "mongodb", "postgresql", "telnet", "mssql"]
    if request.service not in SUPPORTED:
        raise HTTPException(status_code=400,
                            detail=f"不支持的服务: {request.service}，支持: {SUPPORTED}")
    task_ids = []
    for target in request.targets:
        task = async_weakpass_task.delay(ip=target, service=request.service)
        task_ids.append(task.id)

    # 记录一条汇总任务
    summary_id = str(uuid.uuid4())
    _record_task(db, summary_id, "weakpass", request.targets,
                 {"service": request.service, "sub_tasks": task_ids}, user.username)

    logger.info(f"👤 {user.username} 发起弱口令检测: {request.service}, {len(task_ids)} 个任务")
    return {"code": 202, "message": f"已发起 {len(request.targets)} 个弱口令检测任务",
            "service": request.service, "task_ids": task_ids, "total_tasks": len(task_ids)}


@router.post("/weakness", summary="🔑 弱口令检测（旧路径）")
async def start_weakpass_scan(
    request: WeakPassScanRequest,
    db: Session = Depends(models.get_db),
    user: User = Depends(verify_token)
):
    return await _do_weakpass(request, db, user)


@router.post("/weakpass", summary="🔑 弱口令检测（新路径）")
async def start_weakpass_scan_v2(
    request: WeakPassScanRequest,
    db: Session = Depends(models.get_db),
    user: User = Depends(verify_token)
):
    """新前端调用路径，内部与 /weakness 完全一致"""
    return await _do_weakpass(request, db, user)


# ── Nacos 快捷入口 ─────────────────────────────────────────────
@router.post("/nacos", summary="🔍 Nacos 专项检测（快捷入口）")
async def start_nacos_scan(
    request: VulnScanRequest,
    db: Session = Depends(models.get_db),
    user: User = Depends(verify_token)
):
    nacos_request = request.model_copy(update={"vuln_type": "nacos"})
    return await start_vuln_scan(nacos_request, db, user)


# ── 任务状态查询 ───────────────────────────────────────────────
@router.get("/task/{task_id}", summary="🕒 查询任务执行进度",
            response_model=TaskStatusResponse)
async def get_task_status(task_id: str, user: User = Depends(verify_token)):
    try:
        result = AsyncResult(task_id, app=celery_app)
        current_status = result.status
        progress = {"PENDING": 0, "STARTED": 50, "SUCCESS": 100, "FAILURE": -1}.get(current_status, 0)
        return TaskStatusResponse(
            task_id=task_id, status=current_status,
            result=result.result if result.ready() else {},
            progress=progress
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"查询失败: {str(e)}")


# ── 任务历史列表（新前端使用）─────────────────────────────────
@router.get("/tasks", summary="📋 扫描任务历史列表")
async def list_tasks(
    task_type: str = None,
    limit: int = 30,
    db: Session = Depends(models.get_db),
    user: User = Depends(verify_token)
):
    """从数据库读取任务历史记录"""
    try:
        from db.models import ScanTask
        from sqlalchemy import desc
        q = db.query(ScanTask)
        if task_type:
            q = q.filter(ScanTask.task_type == task_type)
        tasks = q.order_by(desc(ScanTask.created_at)).limit(limit).all()
        return {
            "code": 200,
            "data": [
                {
                    "id": t.id,
                    "task_id": t.task_id,
                    "task_type": t.task_type,
                    "status": t.status,
                    "operator": t.operator,
                    "params": t.params,
                    "created_at": t.created_at.strftime("%Y-%m-%d %H:%M") if t.created_at else "",
                    "finished_at": t.finished_at.strftime("%Y-%m-%d %H:%M") if t.finished_at else None,
                }
                for t in tasks
            ]
        }
    except Exception as e:
        logger.warning(f"读取任务历史失败: {e}")
        return {"code": 200, "data": []}


# ── 取消/删除任务 ─────────────────────────────────────────────
@router.delete("/task/{task_id}", summary="❌ 取消/删除任务")
async def cancel_task(task_id: str,
                      db: Session = Depends(models.get_db),
                      user: User = Depends(verify_token)):
    """取消 Celery 任务并从数据库删除记录"""
    try:
        # 尝试撤销 Celery 任务（可能已完成，失败无妨）
        try:
            celery_app.control.revoke(task_id, terminate=True)
        except Exception:
            pass
        # 从 DB 删除记录
        from db.models import ScanTask
        task = db.query(ScanTask).filter(ScanTask.task_id == task_id).first()
        if task:
            db.delete(task)
            db.commit()
            logger.info(f"👤 {user.username} 删除任务记录: {task_id[:8]}...")
            return {"code": 200, "message": "任务已删除", "task_id": task_id}
        return {"code": 200, "message": "任务不存在或已删除", "task_id": task_id}
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=f"删除失败: {str(e)}")


@router.delete("/tasks/batch", summary="❌ 批量删除任务")
async def batch_delete_tasks(
    ids: List[str],
    db: Session = Depends(models.get_db),
    user: User = Depends(verify_token)
):
    """批量删除任务记录"""
    from db.models import ScanTask
    from pydantic import BaseModel as BM
    try:
        deleted = db.query(ScanTask).filter(ScanTask.task_id.in_(ids)).delete(synchronize_session=False)
        db.commit()
        return {"code": 200, "message": f"已删除 {deleted} 条记录"}
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=f"批量删除失败: {str(e)}")


# ── 字典上传 ───────────────────────────────────────────────────
import shutil

@router.post("/upload/dict", summary="📖 上传爆破字典")
async def upload_dict(
    dict_type: str = Form(..., description="字典类型: users 或 pass"),
    file: UploadFile = File(...),
    user: User = Depends(verify_token)
):
    from pathlib import Path
    if dict_type not in ("users", "pass"):
        raise HTTPException(status_code=400, detail="dict_type 必须是 users 或 pass")
    dict_dir = Path(settings.DICT_DIR)
    dict_dir.mkdir(parents=True, exist_ok=True)
    dest = dict_dir / f"{dict_type}.txt"
    try:
        with dest.open("wb") as f:
            shutil.copyfileobj(file.file, f)
        line_count = len(dest.read_text(encoding="utf-8").splitlines())
        logger.info(f"👤 {user.username} 上传字典: {dest.name} ({line_count} 行)")
        return {"code": 200, "message": f"上传成功，共 {line_count} 行",
                "filename": dest.name, "line_count": line_count}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"上传失败: {str(e)}")


@router.get("/dict/status", summary="📖 查询字典文件状态")
async def dict_status(user: User = Depends(verify_token)):
    """检查字典文件是否存在及行数"""
    from pathlib import Path
    dict_dir = Path(settings.DICT_DIR)
    result = {}
    for name in ("users", "pass"):
        f = dict_dir / f"{name}.txt"
        if f.exists():
            try:
                lines = len(f.read_text(encoding="utf-8", errors="ignore").splitlines())
                result[name] = {"exists": True, "lines": lines, "path": str(f)}
            except Exception:
                result[name] = {"exists": True, "lines": 0}
        else:
            result[name] = {"exists": False, "lines": 0}
    return {"code": 200, "data": result}

