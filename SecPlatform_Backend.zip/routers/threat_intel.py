"""
威胁情报路由模块 - routers/threat_intel.py
==========================================
接口列表：
  GET  /api/threat-intel/list          已关联的情报列表
  GET  /api/threat-intel/stats         统计信息
  POST /api/threat-intel/query-cve     手动查询单个 CVE
  POST /api/threat-intel/correlate     对指定资产做 CVE 关联分析
  POST /api/threat-intel/batch-scan    对所有在线资产批量关联
  PATCH /api/threat-intel/{id}/status  更新情报处理状态
  DELETE /api/threat-intel/{id}        删除一条情报记录
"""

import logging
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session
from sqlalchemy import func, desc

from db import models, crud
from db.models import ThreatIntelResult, Asset
from routers.auth import verify_token, User

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api/threat-intel", tags=["8. 威胁情报"])


# ── Pydantic Models ────────────────────────────────────────────

class CveQueryReq(BaseModel):
    cve_id: str = Field(..., description="CVE 编号，如 CVE-2021-44228")

class CorrelateReq(BaseModel):
    ip: str = Field(..., description="资产 IP 地址")

class BatchScanReq(BaseModel):
    limit: int = Field(default=200, ge=1, le=1000, description="最多扫描的资产数量")

class StatusUpdateReq(BaseModel):
    status: str = Field(..., description="状态：未处理 / 已确认 / 误报")


# ── 路由端点 ───────────────────────────────────────────────────

@router.get("/list", summary="威胁情报列表")
async def list_threat_intel(
    ip: Optional[str] = None,
    severity: Optional[str] = None,
    status: Optional[str] = None,
    skip: int = 0,
    limit: int = 100,
    db: Session = Depends(models.get_db),
    user: User = Depends(verify_token),
):
    items = crud.get_threat_intel_list(db, ip=ip, severity=severity, status=status,
                                        limit=limit + skip)
    items = items[skip:skip + limit]
    total = db.query(func.count(ThreatIntelResult.id)).scalar() or 0
    return {
        "code": 200,
        "total": total,
        "data": [_fmt_intel(i) for i in items],
    }


@router.get("/stats", summary="威胁情报统计")
async def get_stats(
    db: Session = Depends(models.get_db),
    user: User = Depends(verify_token),
):
    total   = db.query(func.count(ThreatIntelResult.id)).scalar() or 0
    high    = db.query(func.count(ThreatIntelResult.id)).filter(ThreatIntelResult.severity == "高").scalar() or 0
    unhandled = db.query(func.count(ThreatIntelResult.id)).filter(ThreatIntelResult.status == "未处理").scalar() or 0
    affected_ips = db.query(func.count(func.distinct(ThreatIntelResult.ip_address))).scalar() or 0
    return {
        "code": 200,
        "data": {
            "total": total, "high_severity": high,
            "unhandled": unhandled, "affected_assets": affected_ips,
        }
    }


@router.post("/query-cve", summary="手动查询 CVE 详情")
async def query_cve(
    req: CveQueryReq,
    user: User = Depends(verify_token),
):
    from core.threat_intel import query_cve as _query
    cve_id = req.cve_id.strip().upper()
    if not cve_id.startswith("CVE-"):
        raise HTTPException(400, "CVE 编号格式错误，应为 CVE-YYYY-NNNNN")
    result = _query(cve_id)
    return {"code": 200, "data": result}


@router.post("/correlate", summary="对指定资产进行 CVE 关联分析")
async def correlate_asset(
    req: CorrelateReq,
    db: Session = Depends(models.get_db),
    user: User = Depends(verify_token),
):
    asset = db.query(Asset).filter(Asset.ip_address == req.ip).first()
    if not asset:
        raise HTTPException(404, f"资产 {req.ip} 不存在")

    from core.threat_intel import correlate_asset_cve
    cves = correlate_asset_cve(asset.ip_address, asset.open_ports or "", asset.services or "")

    saved = 0
    for cve in cves:
        crud.save_threat_intel(
            db,
            ip=asset.ip_address,
            cve_id=cve["cve_id"],
            title=cve["title"],
            cvss_score=cve.get("cvss_score"),
            severity=cve.get("severity", "未知"),
            description=cve.get("description", ""),
            published_at=cve.get("published_at"),
            source=cve.get("source", "offline_db"),
        )
        saved += 1

    return {
        "code": 200,
        "message": f"关联完成，{req.ip} 命中 {saved} 条 CVE 情报",
        "data": cves,
    }


@router.post("/batch-scan", summary="批量对所有在线资产进行 CVE 关联扫描")
async def batch_scan(
    req: BatchScanReq,
    db: Session = Depends(models.get_db),
    user: User = Depends(verify_token),
):
    from core.threat_intel import batch_correlate_assets
    assets = db.query(Asset).filter(Asset.status == "ONLINE").limit(req.limit).all()
    if not assets:
        return {"code": 200, "message": "没有在线资产", "data": {}}

    cve_map = batch_correlate_assets(assets)

    saved_total = 0
    for ip, cves in cve_map.items():
        for cve in cves:
            crud.save_threat_intel(
                db, ip=ip, cve_id=cve["cve_id"], title=cve["title"],
                cvss_score=cve.get("cvss_score"), severity=cve.get("severity", "未知"),
                description=cve.get("description", ""),
                published_at=cve.get("published_at"),
                source=cve.get("source", "offline_db"),
            )
            saved_total += 1

    return {
        "code": 200,
        "message": f"批量扫描完成，扫描 {len(assets)} 个资产，关联 {saved_total} 条 CVE 情报",
        "data": {
            "scanned_assets": len(assets),
            "affected_assets": len(cve_map),
            "total_cves": saved_total,
        }
    }


@router.patch("/{item_id}/status", summary="更新情报处理状态")
async def update_status(
    item_id: int,
    req: StatusUpdateReq,
    db: Session = Depends(models.get_db),
    user: User = Depends(verify_token),
):
    item = db.query(ThreatIntelResult).filter(ThreatIntelResult.id == item_id).first()
    if not item:
        raise HTTPException(404, "情报记录不存在")
    item.status = req.status
    db.commit()
    return {"code": 200, "message": "已更新"}


@router.delete("/{item_id}", summary="删除情报记录")
async def delete_intel(
    item_id: int,
    db: Session = Depends(models.get_db),
    user: User = Depends(verify_token),
):
    item = db.query(ThreatIntelResult).filter(ThreatIntelResult.id == item_id).first()
    if not item:
        raise HTTPException(404, "记录不存在")
    db.delete(item)
    db.commit()
    return {"code": 200, "message": "已删除"}


# ── 私有辅助 ──────────────────────────────────────────────────

def _fmt_intel(i: ThreatIntelResult) -> dict:
    return {
        "id": i.id,
        "ip_address": i.ip_address,
        "cve_id": i.cve_id,
        "cvss_score": i.cvss_score,
        "severity": i.severity,
        "title": i.title,
        "description": i.description,
        "published_at": i.published_at,
        "source": i.source,
        "status": i.status,
        "created_at": i.created_at.strftime("%Y-%m-%d %H:%M:%S") if i.created_at else "",
    }
