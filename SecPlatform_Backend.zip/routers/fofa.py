"""FOFA 互联网资产探测路由"""
import logging
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from pydantic import BaseModel
from typing import Optional

from db import models, crud
from routers.auth import verify_token, User

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api/fofa", tags=["6. FOFA"])


class FOFASearchRequest(BaseModel):
    query: str
    size: int = 50
    email: Optional[str] = None
    api_key: Optional[str] = None


@router.post("/search", summary="FOFA 资产搜索")
async def fofa_search(
    req: FOFASearchRequest,
    db: Session = Depends(models.get_db),
    user: User = Depends(verify_token)
):
    from core.fofa_client import FOFAClient
    try:
        if not req.email or not req.api_key:
            # 尝试从配置读取
            from core.config import settings
            email = getattr(settings, "FOFA_EMAIL", None)
            api_key = getattr(settings, "FOFA_API_KEY", None)
            if not email or not api_key:
                raise HTTPException(
                    status_code=400,
                    detail="FOFA API Key 未配置，请在设置中填写 FOFA 邮箱和 API Key"
                )
        else:
            email = req.email
            api_key = req.api_key

        client = FOFAClient(email, api_key)
        result = client.search(req.query, size=req.size)

        if not result["success"]:
            raise HTTPException(status_code=400, detail=result.get("error", "FOFA查询失败"))

        # 保存结果到数据库
        saved = crud.save_fofa_results(db, req.query, result["results"])
        logger.info(f"👤 {user.username} FOFA查询: '{req.query}', 返回{len(result['results'])}条, 入库{saved}条")

        return {
            "code": 200,
            "query": req.query,
            "total": result.get("total", 0),
            "returned": len(result["results"]),
            "saved": saved,
            "data": result["results"],
        }

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"FOFA查询失败: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/history", summary="FOFA 历史结果")
async def fofa_history(
    query: Optional[str] = None,
    limit: int = 100,
    db: Session = Depends(models.get_db),
    user: User = Depends(verify_token)
):
    results = crud.get_fofa_results(db, query=query, limit=limit)
    return {
        "code": 200,
        "data": [
            {
                "id": r.id,
                "query": r.query,
                "ip": r.ip,
                "port": r.port,
                "protocol": r.protocol,
                "title": r.title,
                "country": r.country,
                "city": r.city,
                "org": r.org,
                "domain": r.domain,
                "created_at": r.created_at.strftime("%Y-%m-%d %H:%M") if r.created_at else "",
            }
            for r in results
        ]
    }
