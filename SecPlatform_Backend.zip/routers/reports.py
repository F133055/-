"""安全报告路由 - 日报/周报/资产对比/异常检测"""
import logging
from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import HTMLResponse
from sqlalchemy.orm import Session
from db import models, crud
from routers.auth import verify_token, User

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api/reports", tags=["4. 报告"])


@router.post("/generate/daily", summary="生成安全日报")
async def generate_daily(db: Session = Depends(models.get_db), user: User = Depends(verify_token)):
    try:
        from core.report_generator import generate_daily_report
        data = generate_daily_report(db)
        report = crud.create_report(db, title=f'安全日报 - {data["summary"]["date"]}',
                                    report_type="daily", content=data["html"],
                                    summary=data["summary"], created_by=user.username)
        logger.info(f"👤 {user.username} 生成日报 ID={report.id}")
        return {"code": 200, "message": "日报生成成功", "report_id": report.id, "summary": data["summary"]}
    except Exception as e:
        logger.error(f"生成日报失败: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/generate/weekly", summary="生成安全周报")
async def generate_weekly(db: Session = Depends(models.get_db), user: User = Depends(verify_token)):
    try:
        from core.report_generator import generate_weekly_report
        data = generate_weekly_report(db)
        s = data["summary"]
        report = crud.create_report(db,
            title=f'安全周报 - {s["week_start"]} ~ {s["week_end"]}',
            report_type="weekly", content=data["html"],
            summary=s, created_by=user.username)
        logger.info(f"👤 {user.username} 生成周报 ID={report.id}")
        return {"code": 200, "message": "周报生成成功", "report_id": report.id, "summary": s}
    except Exception as e:
        logger.error(f"生成周报失败: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/asset-comparison", summary="资产变化对比分析")
async def asset_comparison(days: int = 1,
                           db: Session = Depends(models.get_db),
                           user: User = Depends(verify_token)):
    """对比最近N天的资产变化：新增/消失/高危端口"""
    try:
        from core.report_generator import generate_asset_comparison
        return {"code": 200, "data": generate_asset_comparison(db, days=days)}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/anomaly", summary="异常检测")
async def anomaly_detection(db: Session = Depends(models.get_db), user: User = Depends(verify_token)):
    """检测异常：新上线资产、高危端口暴露、近期离线资产"""
    try:
        from datetime import datetime, timedelta
        from db.models import Asset
        from core.report_generator import DANGEROUS_PORTS

        now = datetime.utcnow()
        anomalies = []

        # 24h 内新上线资产
        for a in db.query(Asset).filter(Asset.created_at >= now - timedelta(hours=24)).all():
            anomalies.append({
                "type": "new_asset", "level": "中",
                "title": f"新资产上线：{a.ip_address}",
                "detail": f"开放端口: {a.open_ports or '无'}",
                "time": a.created_at.strftime("%Y-%m-%d %H:%M") if a.created_at else ""
            })

        # 高危端口暴露（在线资产）
        for a in db.query(Asset).filter(Asset.status == "ONLINE").all():
            ports = [p.strip() for p in (a.open_ports or "").split(",") if p.strip()]
            for port in ports:
                if port in DANGEROUS_PORTS:
                    anomalies.append({
                        "type": "high_risk_port", "level": "高",
                        "title": f"高危端口暴露 {a.ip_address}:{port} ({DANGEROUS_PORTS[port]})",
                        "detail": f"建议检查 {DANGEROUS_PORTS[port]} 服务访问控制",
                        "time": a.last_seen.strftime("%Y-%m-%d %H:%M") if a.last_seen else ""
                    })

        # 48h 内离线资产
        for a in db.query(Asset).filter(
            Asset.status == "OFFLINE",
            Asset.last_seen >= now - timedelta(hours=48)
        ).all():
            anomalies.append({
                "type": "asset_offline", "level": "低",
                "title": f"资产离线：{a.ip_address}",
                "detail": f"最后在线: {a.last_seen.strftime('%Y-%m-%d %H:%M') if a.last_seen else '未知'}",
                "time": a.last_seen.strftime("%Y-%m-%d %H:%M") if a.last_seen else ""
            })

        # 按等级排序：高 > 中 > 低
        anomalies.sort(key=lambda x: {"高": 0, "中": 1, "低": 2}.get(x["level"], 9))
        return {"code": 200, "data": anomalies[:100], "total": len(anomalies)}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/", summary="获取报告列表")
async def list_reports(limit: int = 20,
                       db: Session = Depends(models.get_db),
                       user: User = Depends(verify_token)):
    reports = crud.get_reports(db, limit=limit)
    return {"code": 200, "data": [
        {"id": r.id, "title": r.title, "type": r.report_type,
         "created_by": r.created_by,
         "created_at": r.created_at.strftime("%Y-%m-%d %H:%M") if r.created_at else ""}
        for r in reports
    ]}


@router.get("/{report_id}", summary="查看报告详情", response_class=HTMLResponse)
async def get_report(report_id: int,
                     db: Session = Depends(models.get_db),
                     user: User = Depends(verify_token)):
    from db.models import Report
    r = db.query(Report).filter(Report.id == report_id).first()
    if not r:
        raise HTTPException(status_code=404, detail="报告不存在")
    return HTMLResponse(content=r.content or "<p>报告内容为空</p>")


@router.delete("/{report_id}", summary="删除报告")
async def delete_report(report_id: int,
                        db: Session = Depends(models.get_db),
                        user: User = Depends(verify_token)):
    from db.models import Report
    r = db.query(Report).filter(Report.id == report_id).first()
    if not r:
        raise HTTPException(status_code=404, detail="报告不存在")
    db.delete(r); db.commit()
    return {"code": 200, "message": "报告已删除"}
