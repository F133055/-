"""认证模块 - routers/auth.py（账号密码从 .env 读取）"""
import logging
from datetime import datetime, timedelta
from typing import Optional

from fastapi import APIRouter, HTTPException, Depends, status
from fastapi.security import OAuth2PasswordBearer, OAuth2PasswordRequestForm
from pydantic import BaseModel, Field
from jose import jwt, JWTError

from core.config import settings

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/auth", tags=["0. 认证"])

ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_HOURS = 24
REFRESH_TOKEN_EXPIRE_DAYS = 30

oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/api/auth/login")


# ── 从 .env 读取账号密码 ───────────────────────────────────────
def _load_users() -> dict:
    """从配置文件读取用户列表，支持动态刷新"""
    users = {}
    # 读取 admin 账号
    admin_user = getattr(settings, "ADMIN_USERNAME", "admin")
    admin_pass = getattr(settings, "ADMIN_PASSWORD", "admin@2025")
    if admin_user and admin_pass:
        users[admin_user] = admin_pass
    # 读取 test 账号
    test_user = getattr(settings, "TEST_USERNAME", None)
    test_pass = getattr(settings, "TEST_PASSWORD", None)
    if test_user and test_pass:
        users[test_user] = test_pass
    return users


# ── 数据模型 ───────────────────────────────────────────────────
class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    expires_in: int
    refresh_token: Optional[str] = None


class User(BaseModel):
    username: str
    roles: list[str] = ["user"]


# ── Token 工具 ─────────────────────────────────────────────────
def create_access_token(username: str, expires_delta: Optional[timedelta] = None) -> str:
    expire = datetime.utcnow() + (expires_delta or timedelta(hours=ACCESS_TOKEN_EXPIRE_HOURS))
    payload = {"sub": username, "exp": expire, "iat": datetime.utcnow(), "type": "access"}
    return jwt.encode(payload, settings.SECRET_KEY, algorithm=ALGORITHM)


def create_refresh_token(username: str) -> str:
    expire = datetime.utcnow() + timedelta(days=REFRESH_TOKEN_EXPIRE_DAYS)
    payload = {"sub": username, "exp": expire, "type": "refresh"}
    return jwt.encode(payload, settings.SECRET_KEY, algorithm=ALGORITHM)


async def verify_token(token: str = Depends(oauth2_scheme)) -> User:
    exc = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="令牌无效或已过期",
        headers={"WWW-Authenticate": "Bearer"},
    )
    try:
        payload = jwt.decode(token, settings.SECRET_KEY, algorithms=[ALGORITHM])
        username: str = payload.get("sub")
        token_type: str = payload.get("type", "access")
        if not username or token_type != "access":
            raise exc
    except JWTError as e:
        logger.warning(f"JWT 验证失败: {e}")
        raise exc
    return User(username=username, roles=["admin", "user"])


async def verify_admin(user: User = Depends(verify_token)) -> User:
    if "admin" not in user.roles:
        raise HTTPException(status_code=403, detail="需要管理员权限")
    return user


# ── 登录接口 ───────────────────────────────────────────────────
@router.post("/login", response_model=TokenResponse, summary="用户登录")
async def login(form_data: OAuth2PasswordRequestForm = Depends()):
    users = _load_users()
    logger.debug(f"登录尝试: {form_data.username}，当前注册用户: {list(users.keys())}")

    if form_data.username not in users or users[form_data.username] != form_data.password:
        logger.warning(f"登录失败: {form_data.username}")
        raise HTTPException(status_code=401, detail="用户名或密码错误")

    access_token = create_access_token(form_data.username)
    refresh_token = create_refresh_token(form_data.username)
    logger.info(f"✅ 用户登录成功: {form_data.username}")

    return TokenResponse(
        access_token=access_token,
        token_type="bearer",
        expires_in=ACCESS_TOKEN_EXPIRE_HOURS * 3600,
        refresh_token=refresh_token,
    )


@router.post("/refresh", response_model=TokenResponse, summary="刷新令牌")
async def refresh_token_endpoint(refresh_token: str):
    exc = HTTPException(status_code=401, detail="刷新令牌无效或已过期")
    try:
        payload = jwt.decode(refresh_token, settings.SECRET_KEY, algorithms=[ALGORITHM])
        username = payload.get("sub")
        if not username or payload.get("type") != "refresh":
            raise exc
    except JWTError:
        raise exc
    return TokenResponse(
        access_token=create_access_token(username),
        token_type="bearer",
        expires_in=ACCESS_TOKEN_EXPIRE_HOURS * 3600,
    )


@router.get("/me", response_model=User, summary="当前用户信息")
async def get_current_user(user: User = Depends(verify_token)):
    return user


@router.get("/verify", summary="验证令牌")
async def verify(user: User = Depends(verify_token)):
    return {"valid": True, "username": user.username}
