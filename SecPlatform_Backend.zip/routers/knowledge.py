"""安全知识库路由"""
import logging
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from pydantic import BaseModel
from typing import Optional

from db import models
from db.models import KnowledgeDoc
from routers.auth import verify_token, User

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api/knowledge", tags=["知识库"])


class DocCreate(BaseModel):
    title:    str
    category: str = "安全文档"
    content:  str
    tags:     Optional[str] = None

class QueryRequest(BaseModel):
    question: str


@router.get("/", summary="知识文档列表")
async def list_docs(category: Optional[str]=None, keyword: Optional[str]=None,
                    db: Session=Depends(models.get_db), user: User=Depends(verify_token)):
    q = db.query(KnowledgeDoc)
    if category:
        q = q.filter(KnowledgeDoc.category == category)
    if keyword:
        like = f"%{keyword}%"
        q = q.filter(KnowledgeDoc.title.like(like)|KnowledgeDoc.content.like(like)|KnowledgeDoc.tags.like(like))
    docs = q.order_by(KnowledgeDoc.created_at.desc()).all()
    return {"code":200,"total":len(docs),"data":[
        {"id":d.id,"title":d.title,"category":d.category,"content":d.content,"tags":d.tags,
         "created_at":d.created_at.isoformat() if d.created_at else None} for d in docs]}


@router.post("/", summary="新增知识文档")
async def create_doc(body: DocCreate, db: Session=Depends(models.get_db), user: User=Depends(verify_token)):
    doc = KnowledgeDoc(title=body.title, category=body.category,
                       content=body.content, tags=body.tags, created_by=user.username)
    db.add(doc); db.commit(); db.refresh(doc)
    return {"code":200,"message":"创建成功","id":doc.id}


@router.delete("/{doc_id}", summary="删除知识文档")
async def delete_doc(doc_id: int, db: Session=Depends(models.get_db), user: User=Depends(verify_token)):
    doc = db.query(KnowledgeDoc).filter(KnowledgeDoc.id==doc_id).first()
    if not doc: raise HTTPException(status_code=404, detail="文档不存在")
    db.delete(doc); db.commit()
    return {"code":200,"message":"删除成功"}


@router.post("/query", summary="AI 知识检索（支持真实 LLM）")
async def query_knowledge(body: QueryRequest, db: Session=Depends(models.get_db), user: User=Depends(verify_token)):
    question = body.question.strip()
    if not question: raise HTTPException(status_code=400, detail="问题不能为空")

    # ── 第一步：关键词检索相关文档 ─────────────────────────────
    keywords = [w for w in question.replace("？","").replace("?","").split() if len(w)>=2]
    keywords.append(question[:30])
    matched_ids, matched = set(), []
    for kw in keywords:
        like = f"%{kw}%"
        docs = db.query(KnowledgeDoc).filter(
            KnowledgeDoc.title.like(like)|KnowledgeDoc.content.like(like)|KnowledgeDoc.tags.like(like)
        ).limit(5).all()
        for d in docs:
            if d.id not in matched_ids:
                matched_ids.add(d.id)
                matched.append({"id":d.id,"title":d.title,"content":d.content})

    sources = [{"id":d["id"],"title":d["title"]} for d in matched[:5]]

    # ── 第二步：尝试使用 LLM 生成语义化回答 ───────────────────
    try:
        from core.llm_client import call_llm, is_llm_configured
        if is_llm_configured(db) and matched:
            context_docs = ""
            for i, doc in enumerate(matched[:4], 1):
                excerpt = doc["content"][:600]
                context_docs += f"\n【文档{i}：{doc['title']}】\n{excerpt}\n"

            prompt = (
                f"请根据以下安全知识库文档回答用户问题。\n\n"
                f"知识库内容：{context_docs}\n\n"
                f"用户问题：{question}\n\n"
                f"要求：直接回答问题，引用相关文档内容，使用 Markdown 格式，简洁专业。"
            )
            answer = call_llm(
                prompt,
                system="你是 SecPlatform 安全知识库助手，负责基于知识库内容回答安全问题。",
                db=db, max_tokens=1000
            )
            if answer:
                return {"code":200,"answer":answer,"sources":sources,"mode":"llm"}

        elif is_llm_configured(db) and not matched:
            # LLM 可用但知识库为空，直接用 LLM 回答
            answer = call_llm(
                f"请回答这个安全问题（知识库暂无相关文档）：{question}",
                system="你是一位网络安全专家，提供专业、简洁的安全建议。",
                db=db, max_tokens=800
            )
            if answer:
                return {"code":200,"answer":answer,"sources":[],"mode":"llm_direct"}
    except Exception as e:
        logger.warning(f"LLM 知识检索失败，降级到关键词模式: {e}")

    # ── 降级：关键词匹配回答 ──────────────────────────────────
    if not matched:
        return {"code":200,"answer":f"知识库中暂无与「{question}」相关的文档。\n建议：\n1. 向知识库添加相关文档\n2. 在系统设置中配置 LLM API Key 以获得 AI 智能回答","sources":[],"mode":"fallback"}
    parts = [f"📚 根据知识库检索到 {len(matched)} 条相关文档：\n"]
    for i,doc in enumerate(matched[:3],1):
        excerpt = doc["content"][:400].replace("\n"," ")
        parts.append(f"**【{i}】{doc['title']}**\n{excerpt}{'…' if len(doc['content'])>400 else ''}\n")
    return {"code":200,"answer":"\n".join(parts),"sources":sources,"mode":"keyword"}
