@echo off
setlocal enabledelayedexpansion
chcp 65001 >nul
title SecPlatform

cd /d D:\Flask_file\SecPlatform_Backend

echo ============================================
echo  SecPlatform v4.0
echo ============================================

set PYTHON=C:\Users\79916\.conda\envs\Sec_env\python.exe

echo [1/4] Rebuilding frontend (merge JS files)...
"!PYTHON!" rebuild.py
if errorlevel 1 (
    echo [ERROR] rebuild.py failed!
    pause & exit /b 1
)

echo [2/4] Checking Redis...
redis-cli ping >nul 2>&1
if errorlevel 1 (
    echo [WARN] Redis not running. Please start redis-server first.
    echo        Or let main.py auto-start it.
)

echo [3/4] Starting Celery Worker...
start "Celery Worker" cmd /k "cd /d D:\Flask_file\SecPlatform_Backend && !PYTHON! -m celery -A celery_app worker --loglevel=info --logfile=logs/celery.log --pool=solo"
ping -n 4 127.0.0.1 >nul

echo [4/4] Starting FastAPI...
echo     URL: http://127.0.0.1:8000
echo     Press Ctrl+C to stop
echo ============================================
echo.

start /b cmd /c "timeout /t 5 /nobreak >nul && start http://127.0.0.1:8000"
"!PYTHON!" -m uvicorn main:app --host 0.0.0.0 --port 8000

echo.
echo Server stopped.
pause
