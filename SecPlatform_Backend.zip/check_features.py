"""
SecPlatform 快速功能检查脚本
============================
使用方法:
    conda activate Sec_env
    python check_features.py

会自动测试所有 API 功能是否正常响应，并给出汇总报告。
"""

import sys
import json
import time
import requests

BASE_URL = "http://127.0.0.1:8000"
USERNAME = "admin"
PASSWORD = "admin@2025"

GREEN  = "\033[92m"
RED    = "\033[91m"
YELLOW = "\033[93m"
CYAN   = "\033[96m"
RESET  = "\033[0m"
BOLD   = "\033[1m"

results = []


def ok(name, detail=""):
    results.append(("✅", name, detail))
    print(f"  {GREEN}✅ {name}{RESET}" + (f"  →  {detail}" if detail else ""))


def fail(name, detail=""):
    results.append(("❌", name, detail))
    print(f"  {RED}❌ {name}{RESET}" + (f"  →  {detail}" if detail else ""))


def warn(name, detail=""):
    results.append(("⚠️ ", name, detail))
    print(f"  {YELLOW}⚠️  {name}{RESET}" + (f"  →  {detail}" if detail else ""))


def section(title):
    print(f"\n{CYAN}{BOLD}{'─'*50}{RESET}")
    print(f"{CYAN}{BOLD}  {title}{RESET}")
    print(f"{CYAN}{'─'*50}{RESET}")


# ── 登录获取 Token ─────────────────────────────────────────────
section("1. 基础连通性")

try:
    r = requests.get(f"{BASE_URL}/health", timeout=5)
    if r.status_code == 200:
        ok("服务启动", f"版本: {r.json().get('version', '?')}")
    else:
        fail("服务启动", f"HTTP {r.status_code}")
        sys.exit(1)
except Exception as e:
    fail("服务无法连接", str(e))
    print(f"\n  {RED}请先启动 SecPlatform 再运行本脚本{RESET}\n")
    sys.exit(1)

TOKEN = None
try:
    r = requests.post(
        f"{BASE_URL}/api/auth/login",
        data={"username": USERNAME, "password": PASSWORD},
        timeout=5
    )
    data = r.json()
    if data.get("access_token"):
        TOKEN = data["access_token"]
        ok("用户登录", f"用户: {USERNAME}")
    else:
        fail("用户登录", str(data))
        sys.exit(1)
except Exception as e:
    fail("用户登录", str(e))
    sys.exit(1)

H = {"Authorization": f"Bearer {TOKEN}"}


def get(path, label, check_fn=None, warn_fn=None):
    try:
        r = requests.get(f"{BASE_URL}{path}", headers=H, timeout=8)
        data = r.json() if r.headers.get("content-type", "").startswith("application/json") else {}
        if r.status_code == 200:
            detail = check_fn(data) if check_fn else f"HTTP 200"
            if warn_fn and warn_fn(data):
                warn(label, detail)
            else:
                ok(label, detail)
        else:
            fail(label, f"HTTP {r.status_code}: {r.text[:80]}")
    except Exception as e:
        fail(label, str(e)[:80])


def post(path, body, label, check_fn=None):
    try:
        r = requests.post(f"{BASE_URL}{path}", headers=H, json=body, timeout=8)
        data = r.json() if r.headers.get("content-type", "").startswith("application/json") else {}
        if r.status_code in (200, 202):
            detail = check_fn(data) if check_fn else f"HTTP {r.status_code}"
            ok(label, detail)
            return data
        else:
            fail(label, f"HTTP {r.status_code}: {data.get('detail', r.text[:60])}")
    except Exception as e:
        fail(label, str(e)[:80])
    return {}


# ── 系统健康检查 ───────────────────────────────────────────────
section("2. 系统组件")

try:
    r = requests.get(f"{BASE_URL}/api/health/", headers=H, timeout=8)
    data = r.json()
    db_stat   = data.get("database", {}).get("status", "?")
    redis_stat = data.get("redis", {}).get("status", "?")
    celery_stat = data.get("celery", {}).get("status", "?")

    (ok if db_stat == "healthy" else fail)("数据库连接", db_stat)
    (ok if redis_stat == "healthy" else warn)("Redis 连接", redis_stat)
    (ok if celery_stat == "healthy" else warn)("Celery Worker", celery_stat)
except Exception as e:
    warn("系统健康接口", str(e)[:60])

# ── 资产管理 ───────────────────────────────────────────────────
section("3. 资产管理")

get("/api/assets/", "资产列表接口",
    check_fn=lambda d: f"共 {d.get('total', d.get('count', '?'))} 条资产")

get("/api/assets/stats", "资产统计接口",
    check_fn=lambda d: f"在线: {d.get('data',{}).get('online',0)} / 离线: {d.get('data',{}).get('offline',0)}")

# ── 漏洞管理 ───────────────────────────────────────────────────
section("4. 漏洞管理")

get("/api/vulns/", "漏洞列表接口",
    check_fn=lambda d: f"共 {d.get('total', 0)} 条")

get("/api/vulns/stats", "漏洞统计接口",
    check_fn=lambda d: f"高危: {d.get('data',{}).get('high',0)} / 中危: {d.get('data',{}).get('medium',0)}")

# ── 扫描任务 ───────────────────────────────────────────────────
section("5. 扫描任务")

get("/api/scan/tasks", "任务历史接口",
    check_fn=lambda d: f"共 {len(d.get('data',[]))} 条历史记录")

get("/api/scan/dict/status", "字典文件状态",
    check_fn=lambda d: (
        f"users.txt: {d.get('data',{}).get('users',{}).get('lines',0)} 行, "
        f"pass.txt: {d.get('data',{}).get('pass',{}).get('lines',0)} 行"
    ),
    warn_fn=lambda d: not d.get("data", {}).get("users", {}).get("exists"))

# ── FOFA ───────────────────────────────────────────────────────
section("6. FOFA 互联网探测")

get("/api/fofa/history", "FOFA 历史记录接口",
    check_fn=lambda d: f"共 {len(d.get('data',[]))} 条历史")

# 检查 FOFA 配置
try:
    r = requests.post(
        f"{BASE_URL}/api/fofa/search",
        headers=H,
        json={"query": "test", "size": 1},
        timeout=8
    )
    if r.status_code == 400 and "未配置" in r.json().get("detail", ""):
        warn("FOFA 搜索功能", "API Key 未配置（在 .env 中填写 FOFA_EMAIL 和 FOFA_API_KEY）")
    elif r.status_code == 200:
        ok("FOFA 搜索功能", "API Key 有效")
    else:
        warn("FOFA 搜索功能", r.json().get("detail", "未知状态")[:60])
except Exception as e:
    fail("FOFA 搜索功能", str(e)[:60])

# ── 通知推送 ───────────────────────────────────────────────────
section("7. 通知推送")

get("/api/notify/configs", "通知配置接口",
    check_fn=lambda d: f"已配置 {len(d.get('data',[]))} 个渠道" if d.get("data") else "尚未配置任何通知渠道",
    warn_fn=lambda d: len(d.get("data", [])) == 0)

# ── 报告 ───────────────────────────────────────────────────────
section("8. 报告中心")

get("/api/reports/", "报告列表接口",
    check_fn=lambda d: f"共 {len(d.get('data',[]))} 份报告")

# ── 日志接口 ───────────────────────────────────────────────────
section("9. 日志接口")

get("/api/logs?lines=10&log_type=app", "应用日志接口",
    check_fn=lambda d: f"共 {d.get('total_lines', 0)} 行")

get("/api/logs?lines=5&log_type=celery", "Celery 日志接口",
    check_fn=lambda d: f"共 {d.get('total_lines', 0)} 行")

# ── API 文档 ───────────────────────────────────────────────────
section("10. API 文档")
try:
    r = requests.get(f"{BASE_URL}/api/docs", timeout=5)
    if r.status_code == 200:
        ok("Swagger 文档", f"{BASE_URL}/api/docs")
    else:
        warn("Swagger 文档", f"HTTP {r.status_code}")
except Exception as e:
    fail("Swagger 文档", str(e)[:60])

# ── 汇总 ───────────────────────────────────────────────────────
print(f"\n{CYAN}{'═'*50}{RESET}")
print(f"{BOLD}  检查结果汇总{RESET}")
print(f"{CYAN}{'═'*50}{RESET}")

passed = [r for r in results if r[0] == "✅"]
warned = [r for r in results if r[0] == "⚠️ "]
failed = [r for r in results if r[0] == "❌"]

print(f"  {GREEN}✅ 正常: {len(passed)} 项{RESET}")
print(f"  {YELLOW}⚠️  需配置: {len(warned)} 项{RESET}")
print(f"  {RED}❌ 异常: {len(failed)} 项{RESET}")

if warned:
    print(f"\n{YELLOW}  需要配置的项目:{RESET}")
    for _, name, detail in warned:
        print(f"    • {name}: {detail}")

if failed:
    print(f"\n{RED}  异常项目:{RESET}")
    for _, name, detail in failed:
        print(f"    • {name}: {detail}")

print(f"\n  API 文档: {CYAN}{BASE_URL}/api/docs{RESET}")
print()
