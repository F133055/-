"""Celery 分布式任务队列配置 - SecPlatform v4.0"""
import sys
import logging
from pathlib import Path

PROJECT_ROOT = Path(__file__).parent.resolve()
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from celery import Celery, signals
from celery.utils.log import get_task_logger

logger = logging.getLogger(__name__)
task_logger = get_task_logger(__name__)

celery_app = Celery(
    "sec_tasks",
    broker="redis://127.0.0.1:6379/0",
    backend="redis://127.0.0.1:6379/1",
    include=["celery_app"]
)

celery_app.conf.update(
    task_serializer="json",
    accept_content=["json"],
    result_serializer="json",
    timezone="Asia/Shanghai",
    enable_utc=False,
    task_acks_late=True,
    worker_prefetch_multiplier=1,
    task_max_retries=3,
    task_default_retry_delay=30,
)


# ── 工具：安全更新任务状态到 DB ────────────────────────────────
def _update_task_status(task_id: str, status: str, summary: dict = None):
    try:
        from db import models, crud
        if models.engine is None:
            models.init_db()
        db = next(models.get_db())
        try:
            crud.update_scan_task(db, task_id, status, summary)
            task_logger.debug(f"任务状态已更新: {task_id[:8]}... -> {status}")
        finally:
            db.close()
    except Exception as e:
        task_logger.warning(f"更新任务状态失败（不影响扫描结果）: {e}")


# ── 资产扫描任务 ───────────────────────────────────────────────
@celery_app.task(bind=True, name="celery_app.async_asset_scan_task")
def async_asset_scan_task(self, target_ips: list, target_ports: list = None) -> dict:
    task_id = self.request.id
    task_logger.info(f"[资产扫描] 开始 | 任务:{task_id[:8]} | 目标:{len(target_ips)}个 | {target_ips[:3]}")
    _update_task_status(task_id, "RUNNING")

    try:
        from core import core_scanner
        from db import crud, models

        if models.engine is None:
            models.init_db()

        if target_ports is None:
            target_ports = [22, 53, 80, 135, 443, 3306, 6379, 8848]

        task_logger.info(f"[资产扫描] 开始端口扫描，端口: {target_ports}")
        scan_results = core_scanner.scan_ports(target_ips, target_ports)
        task_logger.info(f"[资产扫描] 扫描完成，发现 {len(scan_results)} 个有响应的主机")

        db = next(models.get_db())
        try:
            if scan_results:
                crud.save_scan_results(db, scan_results)
                task_logger.info(f"[资产扫描] 已写入数据库 {len(scan_results)} 条")
            else:
                task_logger.warning(f"[资产扫描] 未发现开放端口的主机")
        finally:
            db.close()

        _update_task_status(task_id, "SUCCESS", {
            "asset_count": len(scan_results),
            "targets": target_ips[:5],
        })

        # ── 扫描完成后：自动保存快照 + 触发异常检测 ────────────
        try:
            db2 = next(models.get_db())
            try:
                snap_count = crud.save_asset_snapshot(db2)
                task_logger.info(f"[资产扫描] 已保存资产快照 {snap_count} 条")
            finally:
                db2.close()
        except Exception as snap_err:
            task_logger.warning(f"[资产扫描] 保存快照失败（不影响扫描结果）: {snap_err}")

        try:
            from core.anomaly_detector import run_anomaly_detection
            db3 = next(models.get_db())
            try:
                anomaly_result = run_anomaly_detection(db3)
                high_risk = anomaly_result.get("summary", {}).get("new_high_risk_ports", 0)
                if high_risk > 0:
                    from core.notifier import notify_scan_complete
                    notify_scan_complete(db3, "异常检测（资产扫描触发）", {
                        "新增高危端口": f"{high_risk} 处",
                        "请及时处理": "登录平台查看详情",
                    })
                task_logger.info(f"[资产扫描] 异常检测完成，新增事件 {anomaly_result.get('events_created', 0)} 条")
            finally:
                db3.close()
        except Exception as anom_err:
            task_logger.warning(f"[资产扫描] 异常检测失败（不影响扫描结果）: {anom_err}")

        task_logger.info(f"[资产扫描] 任务完成: {task_id[:8]}")
        return {"status": "success", "task_id": task_id, "discovered_assets": scan_results}

    except Exception as e:
        task_logger.error(f"[资产扫描] 任务失败: {e}", exc_info=True)
        _update_task_status(task_id, "FAILED", {"error": str(e)})
        return {"status": "failed", "task_id": task_id, "error": str(e)}


# ── 漏洞扫描任务 ───────────────────────────────────────────────
@celery_app.task(bind=True, name="celery_app.async_vuln_scan_task")
def async_vuln_scan_task(self, target_ips: list, vuln_type: str = "nacos") -> dict:
    task_id = self.request.id
    task_logger.info(f"[漏洞扫描] 开始 | 任务:{task_id[:8]} | 类型:{vuln_type} | 目标:{len(target_ips)}个")
    _update_task_status(task_id, "RUNNING")

    try:
        from db import models, crud

        if models.engine is None:
            models.init_db()

        # 尝试使用升级版 vuln_scanner，失败则回退到原版
        try:
            from core.vuln_scanner import check_vuln, get_supported_types
            use_new = True
        except ImportError:
            from core import vuln_scanner
            use_new = False

        vuln_results = {}
        vuln_count = 0

        for ip in target_ips:
            task_logger.info(f"[漏洞扫描] 检测 {ip} - {vuln_type}...")
            try:
                if use_new:
                    result = check_vuln(ip, vuln_type)
                    is_vuln = result["is_vuln"]
                    title = result["title"]
                    severity = result["severity"]
                    description = result["description"]
                else:
                    # 原版只支持 nacos
                    is_vuln = vuln_scanner.check_nacos_vuln(ip) if vuln_type == "nacos" else False
                    title = "Nacos 未授权访问"
                    severity = "高"
                    description = "Nacos /nacos/v1/auth/users 接口可未授权访问"

                vuln_results[ip] = "存在漏洞" if is_vuln else "未发现漏洞"

                if is_vuln:
                    vuln_count += 1
                    task_logger.warning(f"[漏洞扫描] {ip} 发现漏洞: {title}")
                    db = next(models.get_db())
                    try:
                        crud.save_vulnerability(
                            db, ip, vuln_type,
                            title=title,
                            severity=severity,
                            description=description,
                        )
                        crud.update_asset_vuln(db, ip, f"发现 {title}")
                    finally:
                        db.close()
                else:
                    task_logger.info(f"[漏洞扫描] {ip}: 未发现 {vuln_type} 漏洞")

            except Exception as e:
                task_logger.error(f"[漏洞扫描] {ip} 检测异常: {e}")
                vuln_results[ip] = f"检测失败: {str(e)}"

        _update_task_status(task_id, "SUCCESS", {
            "vuln_type": vuln_type,
            "checked": len(target_ips),
            "found": vuln_count,
        })
        task_logger.info(f"[漏洞扫描] 完成，发现漏洞 {vuln_count} 个")
        return {"status": "success", "task_id": task_id,
                "results": vuln_results, "vuln_count": vuln_count}

    except Exception as e:
        task_logger.error(f"[漏洞扫描] 任务失败: {e}", exc_info=True)
        _update_task_status(task_id, "FAILED", {"error": str(e)})
        return {"status": "failed", "task_id": task_id, "error": str(e)}


# ── 弱口令检测任务 ─────────────────────────────────────────────
@celery_app.task(
    bind=True,
    name="celery_app.async_weakpass_task",
    autoretry_for=(),
)
def async_weakpass_task(self, ip: str, service: str = "ssh") -> dict:
    task_id = self.request.id
    task_logger.info(f"[弱口令] 开始 | 任务:{task_id[:8]} | 目标:{ip} | 服务:{service}")
    _update_task_status(task_id, "RUNNING")

    try:
        from core import weakpass_scanner
        from db import crud, models

        if models.engine is None:
            models.init_db()

        task_logger.info(f"[弱口令] 开始爆破 {ip}:{service}...")
        brute_result = weakpass_scanner.start_brute_force(ip, service)
        task_logger.info(f"[弱口令] {ip} 结果: {brute_result}")

        db = next(models.get_db())
        try:
            crud.update_asset_vuln(db, ip, brute_result)

            if brute_result.startswith("⚠️"):
                # 发现弱口令：写入/更新漏洞记录
                crud.save_vulnerability(
                    db, ip, "weakpass",
                    title=f"{service.upper()} 弱口令",
                    severity="高",
                    description=brute_result,
                )
            else:
                # 未发现弱口令：如果数据库中存在该服务的旧漏洞记录（且仍是未处理状态），
                # 更新描述说明最新扫描未复现，帮助用户判断是否已修复
                from db.models import Vulnerability
                old_vuln = db.query(Vulnerability).filter(
                    Vulnerability.ip_address == ip,
                    Vulnerability.vuln_type == "weakpass",
                    Vulnerability.title.like(f"%{service.upper()}%")
                ).first()
                if old_vuln:
                    from datetime import datetime as _dt
                    latest_note = f"[{_dt.now().strftime('%Y-%m-%d %H:%M')} 重新扫描] {brute_result}"
                    old_vuln.description = latest_note
                    # 若原状态为"未处理"，自动建议标记为"已修复"（用户可手动改回）
                    if old_vuln.status == "未处理":
                        old_vuln.status = "已修复"
                        task_logger.info(f"[弱口令] {ip} {service.upper()} 最新扫描未复现，已自动标记为已修复")
                    db.commit()
        finally:
            db.close()

        _update_task_status(task_id, "SUCCESS", {
            "ip": ip,
            "service": service,
            "result": brute_result,
        })
        task_logger.info(f"[弱口令] 任务完成: {task_id[:8]}")
        return {"status": "success", "task_id": task_id, "ip": ip, "service": service, "result": brute_result}

    except Exception as e:
        task_logger.error(f"[弱口令] 任务失败 {ip}: {e}", exc_info=True)
        _update_task_status(task_id, "FAILED", {"ip": ip, "error": str(e)})
        return {"status": "failed", "task_id": task_id, "error": str(e)}


# ── 任务信号钩子 ───────────────────────────────────────────────
@signals.worker_ready.connect
def worker_ready_handler(**kwargs):
    task_logger.info("=" * 50)
    task_logger.info("Celery Worker 已就绪，等待任务...")
    task_logger.info("=" * 50)


@signals.task_prerun.connect
def task_prerun_handler(sender=None, task_id=None, task=None, **kwargs):
    task_logger.info(f"任务开始执行: {task.name} [{task_id[:8] if task_id else '?'}]")


@signals.task_postrun.connect
def task_postrun_handler(sender=None, task_id=None, task=None, retval=None, **kwargs):
    status = retval.get("status", "?") if isinstance(retval, dict) else "?"
    task_logger.info(f"任务执行完成: {task.name} [{task_id[:8] if task_id else '?'}] -> {status}")


@signals.task_failure.connect
def task_failure_handler(sender=None, task_id=None, exception=None, **kwargs):
    task_logger.error(f"任务执行失败: [{task_id[:8] if task_id else '?'}] {exception}")
